/**
 * 本地模拟 TMDB 服务（仅用于验证 Provider 代码路径）。
 * 真实 api.themoviedb.org 在这台机器上不可达（连接超时），
 * 所以用这个服务以**真实 TMDB 的响应结构**跑通：
 *   搜索 → 打分 → 详情 → 海报下载 → 写库 → 界面渲染
 *
 * 用法：node scripts/mock-tmdb.cjs [端口]
 */
const http = require('node:http')
const fs = require('node:fs')
const path = require('node:path')

const PORT = Number(process.argv[2] ?? 8787)
const POSTER = path.join(__dirname, '..', '.mock-poster.jpg')

/** 模拟数据库：故意让标题不完全一致，以检验打分逻辑 */
const MOVIES = [
  {
    id: 72190,
    title: '示例影片甲',
    original_title: 'Example Movie A',
    release_date: '2013-06-19',
    vote_average: 6.8,
    vote_count: 14820,
    popularity: 42.5,
    overview: '示例简介：用于校验匹配链路的假数据。',
    genres: [
      { id: 28, name: '动作' },
      { id: 27, name: '恐怖' },
      { id: 878, name: '科幻' }
    ],
    production_companies: [{ name: 'Paramount Pictures' }],
    production_countries: [{ iso_3166_1: 'US', name: 'United States of America' }],
    original_language: 'en',
    runtime: 116,
    status: 'Released',
    poster_path: '/wwz-poster.jpg',
    backdrop_path: '/demo-a-backdrop.jpg',
    external_ids: { imdb_id: 'tt0000001' }
  },
  {
    id: 25000,
    title: '示例影片乙',
    original_title: 'Example Movie B',
    release_date: '2009-08-18',
    vote_average: 5.1,
    vote_count: 62,
    popularity: 3.2,
    overview: '示例简介：用于校验匹配链路的假数据。',
    genres: [{ id: 878, name: '科幻' }],
    production_companies: [{ name: 'Example Studio' }],
    production_countries: [{ iso_3166_1: 'CN', name: 'China' }],
    original_language: 'zh',
    runtime: 102,
    status: 'Released',
    poster_path: '/demo-b-poster.jpg',
    backdrop_path: '',
    external_ids: { imdb_id: 'tt0000002' }
  }
]

function send(res, status, body, type = 'application/json') {
  res.writeHead(status, { 'content-type': type, 'access-control-allow-origin': '*' })
  res.end(body)
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://127.0.0.1:${PORT}`)
  const auth = req.headers.authorization ?? ''
  const route = url.pathname

  if (route.startsWith('/3/')) {
    // 校验 Bearer：TMDB 就是靠它鉴权，模拟服务同样要求
    if (!/^Bearer .{20,}$/.test(auth)) {
      return send(res, 401, JSON.stringify({ status_message: 'Invalid API key', status_code: 7 }))
    }
  }

  if (route === '/3/search/movie' || route === '/3/search/tv') {
    const query = (url.searchParams.get('query') ?? '').trim()
    const yearParam = url.searchParams.get('primary_release_year') ?? url.searchParams.get('first_air_date_year')
    const year = yearParam ? Number(yearParam) : 0
    const results = MOVIES.filter((movie) => {
      const haystack = `${movie.title}${movie.original_title}`.toLowerCase()
      return haystack.includes(query.toLowerCase()) || query.length === 0
    }).filter((movie) => (year > 0 ? movie.release_date.startsWith(String(year)) : true))
    return send(res, 200, JSON.stringify({ page: 1, total_results: results.length, total_pages: 1, results }))
  }

  const detail = /^\/3\/(movie|tv)\/(\d+)$/.exec(route)
  if (detail) {
    const movie = MOVIES.find((item) => String(item.id) === detail[2])
    if (!movie) return send(res, 404, JSON.stringify({ status_message: 'The resource you requested could not be found.' }))
    return send(res, 200, JSON.stringify(movie))
  }

  if (route.startsWith('/t/p/')) {
    // 图片路径：统一返回同一张本地图片
    if (!fs.existsSync(POSTER)) return send(res, 404, 'no poster')
    const buffer = fs.readFileSync(POSTER)
    return send(res, 200, buffer, 'image/jpeg')
  }

  send(res, 404, JSON.stringify({ status_message: 'not found' }))
})

server.listen(PORT, '127.0.0.1', () => {
  console.log(`模拟 TMDB 已启动: http://127.0.0.1:${PORT}/3  (图片: /t/p/w500/...)`)
})
