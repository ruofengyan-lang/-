/**
 * 只读检查 EPUB 内部结构（不改文件）：条目数、图片数、spine 页数、文本量、是否固定版式。
 * 用法：node scripts/inspect-epub.cjs <a.epub> [b.epub ...]
 */
const fs = require('node:fs')
const zlib = require('node:zlib')

function readEntries(buffer) {
  // 从尾部找 EOCD
  let eocd = -1
  for (let i = buffer.length - 22; i >= 0 && i > buffer.length - 66000; i--) {
    if (buffer.readUInt32LE(i) === 0x06054b50) {
      eocd = i
      break
    }
  }
  if (eocd < 0) throw new Error('找不到 ZIP 结尾记录')
  const count = buffer.readUInt16LE(eocd + 10)
  let offset = buffer.readUInt32LE(eocd + 16)
  const entries = []
  for (let i = 0; i < count; i++) {
    if (buffer.readUInt32LE(offset) !== 0x02014b50) break
    const method = buffer.readUInt16LE(offset + 10)
    const compressedSize = buffer.readUInt32LE(offset + 20)
    const nameLength = buffer.readUInt16LE(offset + 28)
    const extraLength = buffer.readUInt16LE(offset + 30)
    const commentLength = buffer.readUInt16LE(offset + 32)
    const localOffset = buffer.readUInt32LE(offset + 42)
    const name = buffer.toString('utf8', offset + 46, offset + 46 + nameLength)
    entries.push({ name, method, compressedSize, localOffset })
    offset += 46 + nameLength + extraLength + commentLength
  }
  return entries
}

function readEntry(buffer, entry) {
  const nameLength = buffer.readUInt16LE(entry.localOffset + 26)
  const extraLength = buffer.readUInt16LE(entry.localOffset + 28)
  const start = entry.localOffset + 30 + nameLength + extraLength
  const raw = buffer.subarray(start, start + entry.compressedSize)
  return entry.method === 0 ? Buffer.from(raw) : zlib.inflateRawSync(raw)
}

function stripTags(html) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

for (const file of process.argv.slice(2)) {
  try {
    const buffer = fs.readFileSync(file)
    const entries = readEntries(buffer)
    const names = entries.map((e) => e.name)
    const images = names.filter((n) => /\.(jpe?g|png|webp|gif|bmp|avif)$/i.test(n))
    const htmls = names.filter((n) => /\.(x?html?|xhtml)$/i.test(n))
    const opfName = names.find((n) => n.toLowerCase().endsWith('.opf'))
    const opf = opfName ? readEntry(buffer, entries[names.indexOf(opfName)]).toString('utf8') : ''
    const spineCount = (opf.match(/<itemref/g) ?? []).length
    const fixedLayout = /rendition:layout[^>]*>\s*pre-paginated/i.test(opf) || /pre-paginated/i.test(opf)
    const coverHint = /properties\s*=\s*"[^"]*cover-image/i.test(opf)
    let textTotal = 0
    let imgTags = 0
    const sample = htmls.slice(0, 6)
    for (const name of sample) {
      const html = readEntry(buffer, entries[names.indexOf(name)]).toString('utf8')
      textTotal += stripTags(html).length
      imgTags += (html.match(/<img/gi) ?? []).length
    }
    const perPage = sample.length > 0 ? Math.round(textTotal / sample.length) : 0
    console.log(`\n=== ${file}`)
    console.log(` 大小 ${(buffer.length / 1024 / 1024).toFixed(1)} MB · 条目 ${entries.length}`)
    console.log(` 图片 ${images.length} · HTML ${htmls.length} · spine ${spineCount} · 固定版式 ${fixedLayout} · 有封面 ${coverHint}`)
    console.log(` 抽样 ${sample.length} 页：文本合计 ${textTotal} 字（每页约 ${perPage} 字）· <img> 标签 ${imgTags} 个`)
    console.log(` 前 8 个条目：${names.slice(0, 8).join(' | ')}`)
    if (sample[0]) {
      const html = readEntry(buffer, entries[names.indexOf(sample[0])]).toString('utf8')
      console.log(` 首页片段：${html.replace(/\s+/g, ' ').slice(0, 220)}`)
    }
  } catch (err) {
    console.log(`\n=== ${file}\n 读取失败：${err.message}`)
  }
}
