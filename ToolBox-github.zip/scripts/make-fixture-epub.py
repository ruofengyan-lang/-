"""生成 EPUB 测试夹具：一个图集式（应判为漫画）+ 一个文字型（应判为小说）。

用法：python make-fixture-epub.py <输出目录>
"""

import os
import sys
import zipfile

from PIL import Image, ImageDraw

OUT = sys.argv[1] if len(sys.argv) > 1 else "."

CONTAINER = """<?xml version="1.0" encoding="utf-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles>
</container>
"""


def make_image(path, size, color, label):
    image = Image.new("RGB", size, color)
    ImageDraw.Draw(image).text((40, 40), label, fill=(255, 255, 255))
    image.save(path, quality=85)


def write_epub(target, opf, files):
    """files: [(归档内路径, 字节)]"""
    with zipfile.ZipFile(target, "w") as bundle:
        # mimetype 必须第一个且不压缩
        bundle.writestr(zipfile.ZipInfo("mimetype"), "application/epub+zip", zipfile.ZIP_STORED)
        bundle.writestr("META-INF/container.xml", CONTAINER)
        bundle.writestr("OEBPS/content.opf", opf)
        for name, data in files:
            bundle.writestr(name, data)


def build_comic(root):
    """图集式：每页只有一张整页图，几乎没有文字（对应你那种 PDF 转出来的 EPUB）"""
    os.makedirs(f"{root}/pages", exist_ok=True)
    files = []
    for index in range(1, 11):
        image = f"{root}/pages/page{index:03d}.jpg"
        make_image(image, (800, 1200), (30 + index * 15, 40, 90), f"PAGE {index}")
        files.append((f"OEBPS/page{index:03d}.jpg", open(image, "rb").read()))
        html = (
            '<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml">'
            f"<head><title>Page {index}</title></head><body>"
            f'<div><img src="page{index:03d}.jpg" alt="page {index}"/></div></body></html>'
        )
        files.append((f"OEBPS/page{index:03d}.xhtml", html.encode("utf-8")))
    manifest = "\n".join(
        f'<item id="img{i}" href="page{i:03d}.jpg" media-type="image/jpeg"/>'
        f'<item id="page{i}" href="page{i:03d}.xhtml" media-type="application/xhtml+xml"/>'
        for i in range(1, 11)
    )
    spine = "\n".join(f'<itemref idref="page{i}"/>' for i in range(1, 11))
    opf = f"""<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="2.0" unique-identifier="bookid">
 <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
  <dc:title>测试漫画 第01卷</dc:title><dc:creator>测试作者</dc:creator><dc:identifier id="bookid">test-comic-1</dc:identifier>
 </metadata>
 <manifest>{manifest}</manifest>
 <spine>{spine}</spine>
</package>"""
    write_epub(f"{root}/out-comic.epub", opf, files)


def build_novel(root):
    """文字型：每页几千字，只有封面一张图"""
    os.makedirs(f"{root}/text", exist_ok=True)
    cover = f"{root}/text/cover.jpg"
    make_image(cover, (600, 900), (60, 90, 160), "NOVEL")
    files = [("OEBPS/cover.jpg", open(cover, "rb").read())]
    paragraph = "这是一本普通文字小说的一段正文，用来验证图集判定不会误伤纯文字书籍。" * 40
    for index in range(1, 11):
        body = "".join(f"<p>{paragraph}</p>" for _ in range(6))
        html = (
            '<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml">'
            f"<head><title>第 {index} 章</title></head><body><h1>第 {index} 章</h1>{body}</body></html>"
        )
        files.append((f"OEBPS/chapter{index:03d}.xhtml", html.encode("utf-8")))
    manifest = "\n".join(
        [f'<item id="cover" href="cover.jpg" media-type="image/jpeg" properties="cover-image"/>']
        + [
            f'<item id="ch{i}" href="chapter{i:03d}.xhtml" media-type="application/xhtml+xml"/>'
            for i in range(1, 11)
        ]
    )
    spine = "\n".join(f'<itemref idref="ch{i}"/>' for i in range(1, 11))
    opf = f"""<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="2.0" unique-identifier="bookid">
 <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
  <dc:title>测试小说</dc:title><dc:creator>测试作者</dc:creator><dc:identifier id="bookid">test-novel-1</dc:identifier>
 </metadata>
 <manifest>{manifest}</manifest>
 <spine>{spine}</spine>
</package>"""
    write_epub(f"{root}/out-novel.epub", opf, files)


def main():
    os.makedirs(OUT, exist_ok=True)
    build_comic(OUT)
    build_novel(OUT)
    print(f"已生成：{OUT}/out-comic.epub 与 {OUT}/out-novel.epub")


if __name__ == "__main__":
    main()
