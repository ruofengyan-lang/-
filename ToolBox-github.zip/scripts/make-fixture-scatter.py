"""生成"散图漫画目录"测试夹具：一个漫画目录（应聚合成作品）+ 一个壁纸目录（不应被聚合）。

用法：python make-fixture-scatter.py <输出目录>
"""

import os
import sys

from PIL import Image, ImageDraw

OUT = sys.argv[1] if len(sys.argv) > 1 else "."


def make_page(path: str, index: int, portrait: bool, color: tuple) -> None:
    size = (800, 1200) if portrait else (1600, 900)
    image = Image.new("RGB", size, color)
    draw = ImageDraw.Draw(image)
    draw.rectangle([20, 20, size[0] - 20, size[1] - 20], outline=(255, 255, 255), width=5)
    draw.text((50, 60), f"PAGE {index:03d}", fill=(255, 255, 255))
    image.save(path, quality=88)


def main() -> None:
    # 正例：漫画目录里的页码图（竖版）
    comic = os.path.join(OUT, "漫画", "测试散图集")
    os.makedirs(comic, exist_ok=True)
    for index in range(1, 9):
        make_page(os.path.join(comic, f"{index:03d}.jpg"), index, True, (30 + index * 8, 45, 95))
    # 反例：壁纸目录里的"页码式"图片（横版，绝不能被聚合成漫画）
    wallpaper = os.path.join(OUT, "壁纸", "风景集")
    os.makedirs(wallpaper, exist_ok=True)
    for index in range(1, 9):
        make_page(os.path.join(wallpaper, f"{index:03d}.jpg"), index, False, (90, 120 + index * 5, 60))
    print(f"已生成散图夹具：{comic}（8 张竖版）与 {wallpaper}（8 张横版）")


if __name__ == "__main__":
    main()
