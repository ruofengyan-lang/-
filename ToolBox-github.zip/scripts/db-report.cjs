// 诊断：按类型统计缩略图/元数据情况（直接用 node:sqlite 读索引）
const { DatabaseSync } = require('node:sqlite')
const path = require('node:path')

const file = path.resolve(__dirname, '..', '..', 'data', 'index.db')
const db = new DatabaseSync(file)
const rows = db
  .prepare(
    `SELECT kind,
            COUNT(*) AS total,
            SUM(CASE WHEN thumb_state = 1 THEN 1 ELSE 0 END) AS thumb_ok,
            SUM(CASE WHEN thumb_state = -1 THEN 1 ELSE 0 END) AS thumb_fail,
            SUM(CASE WHEN meta_state = 1 THEN 1 ELSE 0 END) AS meta_done
     FROM resources GROUP BY kind ORDER BY total DESC`
  )
  .all()
console.log('kind         total  thumb_ok  thumb_fail  meta_done')
for (const row of rows) {
  console.log(
    `${String(row.kind).padEnd(12)} ${String(row.total).padStart(5)} ${String(row.thumb_ok).padStart(9)} ${String(row.thumb_fail).padStart(11)} ${String(row.meta_done).padStart(10)}`
  )
}
console.log('---- 缩略图失败的样本 ----')
const failed = db
  .prepare(`SELECT name, kind, ext, path FROM resources WHERE thumb_state = -1 LIMIT 8`)
  .all()
for (const row of failed) console.log(`${row.kind.padEnd(10)} ${row.name}`)
console.log('---- 成功拿到缩略图的样本 ----')
const ok = db
  .prepare(`SELECT name, kind FROM resources WHERE thumb_state = 1 AND kind IN ('movie','tv','anime','music','document','archive') LIMIT 8`)
  .all()
for (const row of ok) console.log(`${row.kind.padEnd(10)} ${row.name}`)
db.close()
