/**
 * 测试夹具用的资源库登记脚本（不影响正常使用）：
 *   node scripts/comic-test-lib.cjs add     登记 .test-comics 为临时资源库
 *   node scripts/comic-test-lib.cjs remove  移除该临时资源库（连同它的索引记录）
 *   node scripts/comic-test-lib.cjs report  打印漫画分类与作品聚合结果
 */
const path = require('node:path')
const { DatabaseSync } = require('node:sqlite')

const DATA = path.resolve(__dirname, '..', '..', 'data', 'index.db')
const FIXTURE = path.resolve(__dirname, '..', '.test-comics')
const action = process.argv[2] ?? 'report'

const db = new DatabaseSync(DATA)

function rows(sql, ...params) {
  return db.prepare(sql).all(...params)
}

function add() {
  // 先清理同名残留（避免之前写坏路径的记录）
  for (const row of rows(`SELECT id, path FROM libraries`)) {
    if (row.path.includes('.test-comics') && row.path !== FIXTURE) {
      db.prepare(`DELETE FROM resources WHERE library_id = ?`).run(row.id)
      db.prepare(`DELETE FROM libraries WHERE id = ?`).run(row.id)
    }
  }
  db.prepare(
    `INSERT INTO libraries (path, norm, label, enabled, max_depth, created_at)
     VALUES (?, ?, '漫画测试', 1, 0, ?)
     ON CONFLICT(norm) DO UPDATE SET enabled = 1, path = excluded.path`
  ).run(FIXTURE, FIXTURE.toLowerCase(), Date.now())
  console.log('已登记测试资源库：', FIXTURE)
}

function remove() {
  for (const row of rows(`SELECT id, path FROM libraries`)) {
    if (row.path.includes('.test-comics')) {
      db.prepare(`DELETE FROM resources WHERE library_id = ?`).run(row.id)
      db.prepare(`DELETE FROM libraries WHERE id = ?`).run(row.id)
      console.log('已移除测试资源库 id=', row.id)
    }
  }
}

function report() {
  console.log('=== 资源库 ===')
  for (const row of rows(`SELECT id, path, enabled FROM libraries`)) {
    console.log(` #${row.id} ${row.path} enabled=${row.enabled}`)
  }
  console.log('=== 各类型数量 ===')
  for (const row of rows(
    `SELECT kind, COUNT(*) c FROM resources GROUP BY kind ORDER BY c DESC`
  )) {
    console.log(` ${String(row.kind).padEnd(10)} ${row.c}`)
  }
  console.log('=== 漫画作品聚合 ===')
  for (const row of rows(
    `SELECT series_key, MIN(series_title) t, COUNT(*) n,
            SUM(CASE WHEN volume > 0 THEN 1 ELSE 0 END) numbered
     FROM resources WHERE kind = 'comic' AND series_key <> ''
     GROUP BY series_key ORDER BY t`
  )) {
    console.log(` 《${row.t}》 ${row.n} 卷（识别卷号 ${row.numbered}）  key=${row.series_key}`)
  }
  console.log('=== 漫画文件明细 ===')
  for (const row of rows(
    `SELECT name, volume, series_title FROM resources WHERE kind = 'comic' ORDER BY series_title, volume`
  )) {
    console.log(` 第${String(row.volume).padStart(2)}卷  ${row.name}  → 《${row.series_title}》`)
  }
  console.log('=== 压缩包（应保持压缩包）===')
  for (const row of rows(`SELECT name FROM resources WHERE kind = 'archive' ORDER BY name`)) {
    console.log(` ${row.name}`)
  }
}

if (action === 'add') add()
else if (action === 'remove') remove()
else report()

db.close()
