"""生成一个中性的演示资源库（仅用于截图与功能演示，不含任何个人内容）。

用法：
    python scripts/make-fixture-demo.py <输出目录>

生成内容：
    <输出目录>/壁纸/      6 张抽象渐变图（命名 01.jpg …）
    <输出目录>/图片/      2 张图
    <输出目录>/漫画/      2 部手写 EPUB（含封面）+ 1 个散图目录（8 张页码图，演示目录聚合）
    <输出目录>/小说/      4 个 txt（演示 《书名》作者：xxx 文件名解析）
    <输出目录>/压缩包/    2 个 zip（内含图片与说明，演示"读列表判定内容"）

注意：漫画 EPUB 是用脚本手写的**占位文件**，只为让界面有真实可读的标题与封面，
      不是完整可渲染的电子书。音乐需要真实音频文件，本演示库不含音乐。
"""

import io
import os
import struct
import sys
import zipfile

from PIL import Image, ImageDraw

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
PALETTES = [
    ((24, 38, 74), (58, 96, 158), (142, 196, 232)),
    ((52, 30, 58), (122, 62, 108), (214, 138, 178)),
    ((18, 46, 42), (46, 108, 92), (156, 214, 186)),
    ((58, 44, 24), (146, 108, 52), (232, 202, 138)),
    ((40, 32, 56), (96, 78, 136), (186, 168, 226)),
    ((28, 42, 52), (72, 108, 128), (168, 206, 218)),
]


def abstract_artwork(path: str, width: int, height: int, palette, seed: int, label: str = "") -> None:
    image = Image.new("RGB", (width, height), palette[0])
    draw = ImageDraw.Draw(image)
    for index in range(18):
        cx = int(width * ((index * seed * 37) % 100) / 100)
        cy = int(height * ((index * seed * 53) % 100) / 100)
        radius = int(min(width, height) * (0.12 + ((index * 7) % 5) / 20))
        draw.ellipse(
            [cx - radius, cy - radius, cx + radius, cy + radius],
            fill=palette[(index + 1) % len(palette)],
        )
    draw.rectangle([24, 24, width - 24, height - 24], outline=(255, 255, 255), width=3)
    if label:
        draw.text((48, 52), label, fill=(255, 255, 255))
    image.save(path, quality=90)


def cover_bytes(width: int, height: int, palette, title: str) -> bytes:
    buffer = io.BytesIO()
    image = Image.new("RGB", (width, height), palette[0])
    draw = ImageDraw.Draw(image)
    for index in range(10):
        top = int(height * index / 10)
        draw.rectangle([0, top, width, top + height // 20], fill=palette[(index + 1) % len(palette)])
    draw.rectangle([30, 30, width - 30, height - 30], outline=(255, 255, 255), width=4)
    draw.text((60, height // 2), title, fill=(255, 255, 255))
    image.save(buffer, format="JPEG", quality=88)
    return buffer.getvalue()


def write_epub(path: str, title: str, author: str, palette, pages: int = 6) -> None:
    cover = cover_bytes(600, 900, palette, title)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("mimetype", "application/epub+zip", compress_type=zipfile.ZIP_STORED)
        zf.writestr(
            "META-INF/container.xml",
            '<?xml version="1.0"?><container version="1.0" '
            'xmlns="urn:oasis:names:tc:opendocument:xmlns:container">'
            '<rootfiles><rootfile full-path="OEBPS/content.opf" '
            'media-type="application/oebps-package+xml"/></rootfiles></container>',
        )
        zf.writestr("OEBPS/cover.jpg", cover)
        pages_xml = "".join(
            f'<item id="p{index}" href="p{index}.xhtml" media-type="application/xhtml+xml"/>'
            for index in range(1, pages + 1)
        )
        zf.writestr(
            "OEBPS/content.opf",
            '<?xml version="1.0" encoding="utf-8"?>\n'
            '<package xmlns="http://www.idpf.org/2007/opf" version="2.0" unique-identifier="id">\n'
            f'  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">'
            f"<dc:title>{title}</dc:title><dc:creator>{author}</dc:creator>"
            f'<dc:language>zh</dc:language><dc:identifier id="id">demo-{title}</dc:identifier>'
            '</metadata>\n  <manifest><item id="cover" href="cover.jpg" media-type="image/jpeg"/>'
            f'{pages_xml}</manifest>\n  <spine><itemref idref="p1"/></spine>\n</package>',
        )
        for index in range(1, pages + 1):
            zf.writestr(
                f"OEBPS/p{index}.xhtml",
                '<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml">'
                f"<head><title>第 {index} 页</title></head><body><p>演示用第 {index} 页正文。</p></body></html>",
            )


def write_flac(path: str, artist: str, album: str, title: str, palette) -> None:
    """手写一个只含元数据（VORBIS_COMMENT + PICTURE）的最小 FLAC 占位文件。"""
    comments = [f"ARTIST={artist}", f"ALBUM={album}", f"TITLE={title}", "DATE=2024", "TRACKNUMBER=1"]
    vendor = "ToolBox demo"
    payload = struct.pack("<I", len(vendor)) + vendor.encode() + struct.pack("<I", len(comments))
    for item in comments:
        raw = item.encode("utf-8")
        payload += struct.pack("<I", len(raw)) + raw
    comment_block = struct.pack(">I", len(payload))[1:] + payload

    picture = cover_bytes(500, 500, palette, album)
    pic_payload = (
        struct.pack(">I", 3)
        + struct.pack(">I", len(b"image/jpeg"))
        + b"image/jpeg"
        + struct.pack(">I", 0)
        + struct.pack(">I", len(picture))
        + picture
    )
    picture_block = struct.pack(">I", len(pic_payload))[1:] + pic_payload

    # STREAMINFO：44.1kHz / 2ch / 16bit
    streaminfo = (
        struct.pack(">H", 4096)
        + struct.pack(">H", 4096)
        + b"\x00\x00\x00"
        + b"\x00\x0a\xc4\x40"
        + b"\x0a\xc4\x40" + b"\xf0\x00\x00\x00\x00\x00\x00\x00"
    )
    streaminfo = (streaminfo + b"\x00" * 34)[:34]
    data = b"fLaC"
    data += b"\x00" + struct.pack(">I", 34)[1:] + streaminfo  # STREAMINFO（非最后一块）
    data += b"\x04" + comment_block  # VORBIS_COMMENT
    data += b"\x84" + picture_block  # PICTURE（最后一块）
    with open(path, "wb") as handle:
        handle.write(data)


def write_zip(path: str, title: str, palette) -> None:
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("说明.txt", f"{title}\n演示压缩包：只读取列表用于判定内容，不会自动解压。\n")
        for index in range(1, 5):
            zf.writestr(f"素材/{index:02d}.jpg", cover_bytes(320, 200, palette, f"{title} {index}"))


def main() -> None:
    for name in ("壁纸", "图片", "漫画", "小说", "压缩包"):
        os.makedirs(os.path.join(OUT, name), exist_ok=True)

    for index in range(6):
        abstract_artwork(
            os.path.join(OUT, "壁纸", f"{index + 1:02d}.jpg"),
            2560,
            1440,
            PALETTES[index % len(PALETTES)],
            index + 2,
            f"DEMO WALLPAPER {index + 1:02d}",
        )
    for index in range(2):
        abstract_artwork(
            os.path.join(OUT, "图片", f"插画 {index + 1}.jpg"), 1600, 1200, PALETTES[(index + 3) % 6], index + 5
        )

    write_epub(os.path.join(OUT, "漫画", "星空旅人 第01卷.epub"), "星空旅人", "示范作者", PALETTES[0])
    write_epub(os.path.join(OUT, "漫画", "星空旅人 第02卷.epub"), "星空旅人", "示范作者", PALETTES[1])
    # 散图目录：演示"目录聚合为一部作品"
    scatter = os.path.join(OUT, "漫画", "海边小镇 第01卷")
    os.makedirs(scatter, exist_ok=True)
    for index in range(1, 9):
        abstract_artwork(
            os.path.join(scatter, f"{index:03d}.jpg"), 900, 1300, PALETTES[(index + 2) % 6], index, f"PAGE {index:03d}"
        )

    novels = [
        ("《长夜列车》作者：示范甲.txt", "《长夜列车》作者：示范甲\n\n演示用正文……\n"),
        ("《雨林手记》作者：示范乙.txt", "《雨林手记》作者：示范乙\n\n演示用正文……\n"),
        ("《灯塔与海》作者：示范丙.txt", "《灯塔与海》作者：示范丙\n\n演示用正文……\n"),
        ("《第九个夏天》作者：示范丁.txt", "《第九个夏天》作者：示范丁\n\n演示用正文……\n"),
    ]
    for name, content in novels:
        with open(os.path.join(OUT, "小说", name), "w", encoding="utf-8") as handle:
            handle.write(content)

    write_zip(os.path.join(OUT, "压缩包", "素材合集.zip"), "素材合集", PALETTES[4])
    write_zip(os.path.join(OUT, "压缩包", "旧项目备份.zip"), "旧项目备份", PALETTES[5])

    total = sum(len(files) for _, _, files in os.walk(OUT))
    print(f"演示资源库已生成：{os.path.abspath(OUT)}（{total} 个文件）")


if __name__ == "__main__":
    main()
