"""生成验证用的模拟海报（本地 mock TMDB 服务回给客户端的图片）。"""

import sys

from PIL import Image, ImageDraw

OUT = sys.argv[1] if len(sys.argv) > 1 else "mock-poster.jpg"

# 2:3 海报比例，颜色与真实界面明显不同，方便一眼看出是模拟数据
image = Image.new("RGB", (500, 750), (24, 30, 44))
draw = ImageDraw.Draw(image)
draw.rectangle([16, 16, 484, 734], outline=(90, 160, 230), width=5)
draw.text((40, 60), "MOCK POSTER", fill=(230, 240, 255))
draw.text((40, 90), "模拟 TMDB 海报", fill=(150, 200, 245))
draw.rectangle([40, 140, 460, 620], fill=(40, 62, 96))
draw.text((60, 660), "World War Z (2013)", fill=(200, 220, 245))
image.save(OUT, quality=88)
print(f"已生成模拟海报：{OUT}")
