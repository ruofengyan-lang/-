/**
 * 演示库登记脚本（截图 / 功能演示用，不影响正常使用）：
 *   node scripts/demo-lib.cjs add     生成并登记演示库，同时暂时停用其它资源库
 *   node scripts/demo-lib.cjs remove  移除演示库并恢复其它资源库
 *
 * 停用其它资源库是为了保证截图里只有中性演示内容，不会出现个人资源。
 */
const path = require('node:path')
const { DatabaseSync } = require('node:sqlite')

const DATA = path.resolve(__dirname, '..', '..', 'data', 'index.db')
const DEMO = path.resolve(__dirname, '..', '.demo-lib')
const action = process.argv[2] ?? 'add'

const db = new DatabaseSync(DATA)
const rows = (sql, ...params) => db.prepare(sql).all(...params)

function add() {
  for (const row of rows(`SELECT id, path FROM libraries`)) {
    if (row.path.includes('.demo-lib') && row.path !== DEMO) {
      db.prepare(`DELETE FROM resources WHERE library_id = ?`).run(row.id)
      db.prepare(`DELETE FROM libraries WHERE id = ?`).run(row.id)
    }
  }
  db.prepare(
    `INSERT INTO libraries (path, norm, label, enabled, max_depth, created_at)
     VALUES (?, ?, '演示资源库', 1, 0, ?)
     ON CONFLICT(norm) DO UPDATE SET enabled = 1, path = excluded.path`
  ).run(DEMO, DEMO.toLowerCase(), Date.now())
  // 暂时停用其它库，保证截图内容可公开
  db.prepare(`UPDATE libraries SET enabled = 0 WHERE path NOT LIKE '%demo-lib%'`).run()
  console.log('已登记演示资源库并暂停其它资源库：', DEMO)
}

function remove() {
  for (const row of rows(`SELECT id, path FROM libraries`)) {
    if (row.path.includes('.demo-lib')) {
      db.prepare(`DELETE FROM resources WHERE library_id = ?`).run(row.id)
      db.prepare(`DELETE FROM libraries WHERE id = ?`).run(row.id)
    }
  }
  db.prepare(`UPDATE libraries SET enabled = 1 WHERE path NOT LIKE '%demo-lib%'`).run()
  console.log('已移除演示资源库并恢复其它资源库')
}

if (action === 'remove') remove()
else add()
console.log(
  '当前资源库：',
  JSON.stringify(rows(`SELECT id, path, enabled FROM libraries`).map((r) => ({ path: r.path, enabled: r.enabled })))
)
db.close()
