/**
 * 还原验证现场：清掉测试 Key 与模拟数据，配置回到"由用户填写 Key"的状态。
 * 用法：node scripts/reset-verify-state.cjs
 */
const fs = require('node:fs')
const path = require('node:path')
const { DatabaseSync } = require('node:sqlite')

const CONFIG = path.resolve(__dirname, '..', '..', 'config', 'config.json')
const DATA_METADATA = path.resolve(__dirname, '..', '..', 'data', 'metadata')

// 1) 元数据：把被模拟数据写过的电影恢复成「本地信息」
const db = new DatabaseSync(path.resolve(__dirname, '..', '..', 'data', 'index.db'))
db.prepare(
  `UPDATE metadata SET match_status = 'local', external_source = 'local', external_id = '',
     original_title = '', year = 0, overview = '', genres = '[]', rating = 0,
     poster_path = '', backdrop_path = '', match_confidence = 0, extra_json = '{}'
   WHERE kind = 'movie'`
).run()
console.log('电影元数据已恢复为本地信息')
db.close()

// 2) 删掉下载缓存（模拟海报）
for (const sub of ['posters', 'backdrops']) {
  const dir = `${DATA_METADATA}\\${sub}`
  if (!fs.existsSync(dir)) continue
  for (const name of fs.readdirSync(dir)) {
    fs.rmSync(`${dir}\\${name}`, { force: true })
    console.log('已删除缓存图片:', `${sub}/${name}`)
  }
}

// 3) 配置：清空 Key，保留"允许联网匹配"，地址回到官方
const config = JSON.parse(fs.readFileSync(CONFIG, 'utf8'))
config.metadata = {
  ...config.metadata,
  tmdbApiKey: '',
  online: true,
  tmdbApiBase: 'https://api.themoviedb.org/3',
  tmdbImageBase: 'https://image.tmdb.org/t/p'
}
fs.writeFileSync(CONFIG, JSON.stringify(config, null, 2))
console.log('配置已还原：Key 已清空（由用户填写）| online =', config.metadata.online)
