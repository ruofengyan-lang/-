"""生成 Phase 2 漫画测试用的图片（竖版页面 + 封面 + 非图片文件）。

用法：python make-fixture-images.py <输出目录>
"""

import os
import sys

from PIL import Image, ImageDraw

OUT = sys.argv[1] if len(sys.argv) > 1 else "."


def page(path: str, width: int, height: int, color: tuple, label: str) -> None:
    image = Image.new("RGB", (width, height), color)
    draw = ImageDraw.Draw(image)
    draw.rectangle([20, 20, width - 20, height - 20], outline=(255, 255, 255), width=6)
    draw.text((50, 60), label, fill=(255, 255, 255))
    image.save(path, quality=88)


def main() -> None:
    os.makedirs(OUT, exist_ok=True)
    # 漫画内页：竖版（高 > 宽），用于"首图是否竖版"的内容判定
    for index in range(1, 7):
        page(
            os.path.join(OUT, f"page{index:03d}.jpg"),
            800,
            1200,
            (30 + index * 12, 40, 90),
            f"PAGE {index}",
        )
    # 封面：竖版，颜色明显不同，便于在截图里一眼认出封面生效
    page(os.path.join(OUT, "cover.jpg"), 600, 900, (200, 60, 40), "COVER")
    page(os.path.join(OUT, "folder.jpg"), 600, 900, (40, 160, 90), "FOLDER")
    # 非图片内容：验证"不要把普通 zip 判成漫画"
    with open(os.path.join(OUT, "notes.txt"), "w", encoding="utf-8") as handle:
        handle.write("这是一份普通资料，不是漫画。\n" * 20)
    print(f"已生成测试图片到 {OUT}")


if __name__ == "__main__":
    main()
