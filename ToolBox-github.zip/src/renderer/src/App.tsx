import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { formatSize } from '@shared/format'
import { KIND_LABEL, SERIES_KINDS } from '@shared/resource-kinds'
import type {
  AppConfig,
  AppInfo,
  FolderNode,
  Library,
  LibraryStats,
  MediaInfo,
  MetadataRecord,
  ResourceDetail,
  ResourceItem,
  ResourceKind,
  ScanProgress,
  SeriesDetail,
  SeriesItem,
  SortBy,
  SortOrder,
  ViewId
} from '@shared/types'
import ContextMenu, { type MenuEntry } from './components/ContextMenu'
import HomeView from './components/HomeView'
import DetailDrawer from './components/DetailDrawer'
import LibrariesView from './components/LibrariesView'
import { KindPickerDialog, PreviewModal, RenameDialog, SettingsDialog } from './components/Modals'
import MatchingCenter from './components/MatchingCenter'
import ResourceGrid from './components/ResourceGrid'
import SeriesDrawer from './components/SeriesDrawer'
import Sidebar from './components/Sidebar'
import TopBar from './components/TopBar'
import Toasts, { type ToastItem } from './components/Toasts'
import { OVERLAY_OPTIONS, VIRTUAL_MAX_ITEMS, VIRTUAL_THRESHOLD, cssBackgroundRepeat, cssBackgroundSize, hintFor, imageToPngDataUrl } from './utils'

const PAGE_SIZE = 120
const VIEWS: ViewId[] = ['home', 'all', 'recent-added', 'recent-used', 'favorites', 'duplicates', 'folders', 'libraries', 'settings']

interface MenuState {
  x: number
  y: number
  item?: ResourceItem
  folder?: FolderNode
  series?: SeriesItem
}

export default function App(): React.JSX.Element {
  const api = window.toolbox

  const [info, setInfo] = useState<AppInfo | null>(null)
  const [config, setConfig] = useState<AppConfig | null>(null)
  const [stats, setStats] = useState<LibraryStats | null>(null)
  const [libraries, setLibraries] = useState<Library[]>([])
  const [view, setView] = useState<ViewId>('home')
  const [kind, setKind] = useState<ResourceKind | null>(null)
  const [folder, setFolder] = useState<{ libraryId: number; relDir: string } | null>(null)
  const [folders, setFolders] = useState<FolderNode[]>([])
  const [search, setSearch] = useState('')
  const [searchKind, setSearchKind] = useState<ResourceKind | null>(null)
  const [sort, setSort] = useState<SortBy>('name')
  const [order, setOrder] = useState<SortOrder>('asc')
  const [items, setItems] = useState<ResourceItem[]>([])
  const [total, setTotal] = useState(0)
  const [offset, setOffset] = useState(0)
  const [loading, setLoading] = useState(false)
  const [selectedPath, setSelectedPath] = useState<string | null>(null)
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [detail, setDetail] = useState<ResourceDetail | null>(null)
  const [media, setMedia] = useState<MediaInfo | null>(null)
  const [progress, setProgress] = useState<ScanProgress | null>(null)
  const [scanning, setScanning] = useState(false)
  const [paused, setPaused] = useState(false)
  const [preview, setPreview] = useState<ResourceItem | null>(null)
  const [renaming, setRenaming] = useState<ResourceItem | null>(null)
  const [kindPicker, setKindPicker] = useState<ResourceItem | null>(null)
  const [settingsOpen, setSettingsOpen] = useState(false)
  /** Phase 9：元数据匹配中心 */
  const [matchingOpen, setMatchingOpen] = useState(false)
  const [menu, setMenu] = useState<MenuState | null>(null)
  const [toasts, setToasts] = useState<ToastItem[]>([])
  const [busy, setBusy] = useState('')
  const [refreshKey, setRefreshKey] = useState(0)
  /* ---- Phase 2：作品（系列）聚合 ---- */
  const [seriesMode, setSeriesMode] = useState(true)
  const [seriesItems, setSeriesItems] = useState<SeriesItem[]>([])
  const [selectedSeriesKey, setSelectedSeriesKey] = useState<string | null>(null)
  const [openSeries, setOpenSeries] = useState<SeriesDetail | null>(null)
  const [seriesDrawerOpen, setSeriesDrawerOpen] = useState(false)
  /* ---- Phase 3：作品元数据 ---- */
  const [seriesMetadata, setSeriesMetadata] = useState<MetadataRecord | null>(null)
  const [detailMetadata, setDetailMetadata] = useState<MetadataRecord | null>(null)
  const [detailPoster, setDetailPoster] = useState('')
  const [metadataVersion, setMetadataVersion] = useState(0)
  /** 正在联网抓取元数据（详情里的刷新按钮） */
  const [matching, setMatching] = useState(false)
  const [homeStrips, setHomeStrips] = useState<{ added: ResourceItem[]; used: ResourceItem[]; favs: ResourceItem[] }>({
    added: [],
    used: [],
    favs: []
  })

  const configRef = useRef<AppConfig | null>(null)
  const toastId = useRef(0)

  const toast = useCallback((type: ToastItem['type'], text: string) => {
    const id = ++toastId.current
    setToasts((list) => [...list, { id, type, text }].slice(-4))
    setTimeout(() => setToasts((list) => list.filter((item) => item.id !== id)), type === 'error' ? 5200 : 2800)
  }, [])

  const patch = useCallback(
    async (partial: Partial<AppConfig>): Promise<void> => {
      const next = await api.setConfig(partial)
      configRef.current = next
      setConfig(next)
    },
    [api]
  )

  /* ------------------------- 启动 ------------------------- */

  useEffect(() => {
    void (async () => {
      try {
        const [appInfo, appConfig, libs] = await Promise.all([api.info(), api.getConfig(), api.libraries()])
        setInfo(appInfo)
        setConfig(appConfig)
        configRef.current = appConfig
        setLibraries(libs)
        setSort(appConfig.sortBy)
        setOrder(appConfig.sortOrder)
        setView(VIEWS.includes(appConfig.lastView as ViewId) ? (appConfig.lastView as ViewId) : 'home')
        setStats(await api.stats())
      } catch (err) {
        toast('error', `启动失败：${err instanceof Error ? err.message : String(err)}`)
      }
    })()
  }, [api, toast])

  /* ------------------------- 主进程事件 ------------------------- */

  useEffect(() => {
    const offConfig = api.onConfigChanged((next) => {
      configRef.current = next
      setConfig(next)
    })
    const offToast = api.onToast((payload) => toast(payload.type, payload.text))
    const offScan = api.onScanProgress((state) => {
      setProgress(state)
      const active = !['done', 'idle'].includes(state.phase)
      setScanning(active)
      setPaused(state.phase === 'paused')
    })
    const offIndex = api.onIndexChanged(() => setRefreshKey((value) => value + 1))
    return () => {
      offConfig()
      offToast()
      offScan()
      offIndex()
    }
  }, [api, toast])

  /* ------------------------- 统计 / 资源库 ------------------------- */

  useEffect(() => {
    void (async () => {
      const [nextStats, libs] = await Promise.all([api.stats(), api.libraries()])
      setStats(nextStats)
      setLibraries(libs)
    })()
  }, [api, refreshKey])

  /* ------------------------- 列表加载 ------------------------- */

  /** 作品视图：漫画分类默认按「作品」聚合展示（Phase 2） */
  const isSeriesView = Boolean(
    view === 'all' && kind && SERIES_KINDS.includes(kind) && seriesMode && !search.trim()
  )

  useEffect(() => {
    if (view === 'libraries' || view === 'settings') {
      setItems([])
      setFolders([])
      setSeriesItems([])
      setTotal(0)
      return
    }
    let alive = true
    setLoading(true)
    void (async () => {
      try {
        if (view === 'home') {
          const [added, used, favs] = await Promise.all([
            api.list({ view: 'recent-added', sort: 'added', order: 'desc', offset: 0, limit: 12 }),
            api.list({ view: 'recent-used', sort: 'opened', order: 'desc', offset: 0, limit: 12 }),
            api.list({ view: 'favorites', sort: 'name', order: 'asc', offset: 0, limit: 12 })
          ])
          if (!alive) return
          setHomeStrips({ added: added.items, used: used.items, favs: favs.items })
          setItems([])
          setFolders([])
          setSeriesItems([])
          setTotal(next_total(added, used, favs))
          return
        }
        if (view === 'folders') {
          const libraryId = folder?.libraryId ?? libraries[0]?.id ?? 0
          const relDir = folder?.relDir ?? ''
          const [children, files] = await Promise.all([api.folders(libraryId, relDir), api.folderResources(libraryId, relDir)])
          if (!alive) return
          setFolders(children)
          setItems(files.items)
          setSeriesItems([])
          setTotal(files.total)
          return
        }
        if (isSeriesView && kind) {
          const list = await api.series(kind, null)
          if (!alive) return
          setSeriesItems(list)
          setItems([])
          setFolders([])
          setTotal(list.length)
          return
        }
        setSeriesItems([])
        const baseQuery = {
          view,
          kind: search.trim() ? searchKind : kind,
          search,
          libraryId: null,
          folder: null,
          sort,
          order
        }
        const page = await api.list({ ...baseQuery, offset, limit: PAGE_SIZE })
        if (!alive) return
        // Phase 10：大列表一次读全，交给虚拟网格只渲染可视行；
        // 小列表保持原来的分批续载（行为与观感不变）。
        if (offset === 0 && page.total > VIRTUAL_THRESHOLD) {
          const all = [...page.items]
          const maxPages = Math.ceil(Math.min(page.total, VIRTUAL_MAX_ITEMS) / PAGE_SIZE)
          for (let index = 1; index < maxPages; index++) {
            const next = await api.list({ ...baseQuery, offset: index * PAGE_SIZE, limit: PAGE_SIZE })
            if (!alive) return
            all.push(...next.items)
            if (next.items.length < PAGE_SIZE) break
          }
          setItems(all)
        } else {
          setItems((current) => (offset === 0 ? page.items : [...current, ...page.items]))
        }
        setTotal(page.total)
        setFolders([])
      } catch (err) {
        if (alive) toast('error', `读取失败：${err instanceof Error ? err.message : String(err)}`)
      } finally {
        if (alive) setLoading(false)
      }
    })()
    return () => {
      alive = false
    }
  }, [api, view, kind, folder, search, searchKind, sort, order, offset, libraries, refreshKey, isSeriesView, toast])

  /* ------------------------- 选中项详情（懒加载媒体信息）------------------------- */

  useEffect(() => {
    if (selectedId === null) {
      setDetail(null)
      setMedia(null)
      return
    }
    let alive = true
    void (async () => {
      const nextDetail = await api.detail(selectedId)
      if (!alive) return
      setDetail(nextDetail)
      if (nextDetail) {
        const nextMedia = await api.media(nextDetail.path, nextDetail.kind).catch(() => null)
        if (alive) setMedia(nextMedia)
      }
    })()
    return () => {
      alive = false
    }
  }, [api, selectedId])

  /* ------------------------- 作品详情（漫画卷列表）------------------------- */

  useEffect(() => {
    if (!selectedSeriesKey) {
      setOpenSeries(null)
      return
    }
    let alive = true
    void (async () => {
      const detail = await api.seriesDetail(selectedSeriesKey).catch(() => null)
      if (alive) setOpenSeries(detail)
    })()
    return () => {
      alive = false
    }
  }, [api, selectedSeriesKey, refreshKey, metadataVersion])

  /* ------------------------- 作品元数据（Phase 3） ------------------------- */

  useEffect(() => {
    if (!selectedSeriesKey) {
      setSeriesMetadata(null)
      return
    }
    let alive = true
    void (async () => {
      const meta = await api.metaGet(selectedSeriesKey).catch(() => null)
      if (alive) setSeriesMetadata(meta)
    })()
    return () => {
      alive = false
    }
  }, [api, selectedSeriesKey, refreshKey, metadataVersion])

  useEffect(() => {
    const key = detail?.seriesKey ?? ''
    if (!key) {
      setDetailMetadata(null)
      setDetailPoster('')
      return
    }
    let alive = true
    void (async () => {
      const meta = await api.metaGet(key).catch(() => null)
      const poster = await api.metaPoster(key).catch(() => '')
      if (alive) {
        setDetailMetadata(meta)
        setDetailPoster(poster)
      }
    })()
    return () => {
      alive = false
    }
  }, [api, detail, refreshKey, metadataVersion])

  /** 触发一次匹配：没配 Key / 没开联网 / 网络不通都如实说明原因，不假装成功 */
  const runMatch = useCallback(
    async (seriesKey: string): Promise<boolean> => {
      if (matching) return false
      setMatching(true)
      try {
        const result = await api.metaMatch(seriesKey)
        if (!result) {
          toast('error', '找不到这部作品')
          return false
        }
        const { decision } = result
        if (decision.providerCount === 0) {
          if (decision.reason.includes('未配置')) {
            toast('info', '还没填 TMDB API Key：⋯ 更多 → 设置… → 在线元数据，粘贴 Key 保存后重试')
          } else if (decision.reason.includes('关闭')) {
            toast('info', '在线匹配未开启：⋯ 更多 → 设置… → 在线元数据，勾选「允许联网匹配」')
          } else {
            toast('info', `暂不可匹配：${decision.reason}`)
          }
        } else if (decision.status === 'matched') {
          toast('ok', `已抓取到元数据（置信度 ${Math.round(decision.confidence * 100)}%）：${result.record?.title ?? ''}`)
        } else if (decision.status === 'pending') {
          toast('info', `有候选但需要确认：${decision.reason}`)
        } else {
          toast('error', `抓取失败：${decision.reason}`)
        }
        setMetadataVersion((value) => value + 1)
        return decision.status === 'matched'
      } catch (err) {
        toast('error', `抓取失败：${err instanceof Error ? err.message : String(err)}`)
        return false
      } finally {
        setMatching(false)
      }
    },
    [api, matching, toast]
  )

  /** 详情抽屉里的「刷新信息」：有作品归属就走联网抓取，没有就说明原因 */
  const refreshDetailMetadata = useCallback(
    (item: ResourceItem): void => {
      if (!item.seriesKey) {
        toast('info', `「${KIND_LABEL[item.kind]}」暂不支持联网抓取（音乐等后续阶段接入）`)
        return
      }
      void runMatch(item.seriesKey)
    },
    [runMatch, toast]
  )

  /* ------------------------- 行为 ------------------------- */

  /** 作品（系列）：单击打开作品抽屉，双击阅读第一卷 */
  const selectSeries = useCallback((item: SeriesItem) => {
    setSelectedSeriesKey(item.key)
    setSeriesDrawerOpen(true)
    setDrawerOpen(false)
    setSelectedId(null)
    setSelectedPath(null)
  }, [])

  const activateSeries = useCallback(
    async (item: SeriesItem): Promise<void> => {
      try {
        const result = await api.open(item.firstResourceId)
        if (result.ok) toast('ok', result.message ?? `已打开《${item.title}》`)
        else if (result.error && result.error !== '已取消') toast('error', result.error)
      } catch (err) {
        toast('error', `打开失败：${err instanceof Error ? err.message : String(err)}`)
      }
    },
    [api, toast]
  )

  const closeSeries = useCallback(() => setSeriesDrawerOpen(false), [])

  const applyWallpaper = useCallback(
    async (item: ResourceItem): Promise<void> => {
      const style = configRef.current?.wallpaperStyle ?? 'fill'
      setBusy('正在设置桌面壁纸…')
      try {
        let result = await api.setWallpaper(item.path, style)
        if (!result.ok && result.error === 'NEED_CONVERT') {
          const dataUrl = await imageToPngDataUrl(api.mediaUrl(item.path))
          result = await api.setWallpaperFromData(dataUrl, style)
        }
        toast(result.ok ? 'ok' : 'error', result.ok ? result.message ?? '壁纸设置成功' : result.error ?? '壁纸设置失败')
      } catch (err) {
        toast('error', `壁纸设置失败：${err instanceof Error ? err.message : String(err)}`)
      } finally {
        setBusy('')
      }
    },
    [api, toast]
  )

  const activate = useCallback(
    async (item: ResourceItem): Promise<void> => {
      try {
        const result = await api.open(item.id)
        if (result.ok) toast('ok', result.message ?? `已打开 ${item.name}`)
        else if (result.error && result.error !== '已取消') toast('error', result.error)
      } catch (err) {
        toast('error', `打开失败：${err instanceof Error ? err.message : String(err)}`)
      }
    },
    [api, toast]
  )

  /** 单击：选中并打开详情抽屉 */
  const select = useCallback((item: ResourceItem | null) => {
    setSelectedPath(item?.path ?? null)
    setSelectedId(item?.id ?? null)
    setDrawerOpen(Boolean(item))
    if (item) setSeriesDrawerOpen(false)
  }, [])

  /** 右键：只选中（抽屉已开则跟着切换内容，不强制弹出） */
  const selectForMenu = useCallback((item: ResourceItem | null) => {
    setSelectedPath(item?.path ?? null)
    setSelectedId(item?.id ?? null)
  }, [])

  const closeDrawer = useCallback(() => setDrawerOpen(false), [])

  const refreshIndex = useCallback((): void => {
    setOffset(0)
    setRefreshKey((value) => value + 1)
    toast('info', '已重新读取索引')
  }, [toast])

  const startScan = useCallback(
    async (libraryId?: number): Promise<void> => {
      const result = await api.scan(libraryId)
      if (!result.ok) toast('error', result.error ?? '无法开始扫描')
      else {
        setScanning(true)
        toast('info', '已开始扫描资源库')
      }
    },
    [api, toast]
  )

  const removeItem = useCallback(
    async (item: ResourceItem, permanent: boolean): Promise<void> => {
      const result = await api.remove(item.path, permanent)
      if (result.ok) {
        toast('ok', result.message ?? '已删除')
        if (selectedPath === item.path) select(null)
        refreshIndex()
      } else if (result.error && result.error !== '已取消') {
        toast('error', result.error)
      }
    },
    [api, refreshIndex, select, selectedPath, toast]
  )

  const submitRename = useCallback(
    async (item: ResourceItem, name: string): Promise<void> => {
      setRenaming(null)
      const result = await api.rename(item.path, name)
      if (result.ok) {
        toast('ok', result.message ?? '已重命名')
        refreshIndex()
      } else {
        toast('error', result.error ?? '重命名失败')
      }
    },
    [api, refreshIndex, toast]
  )

  const toggleFavorite = useCallback(
    async (item: ResourceItem): Promise<void> => {
      const result = await api.toggleFavorite(item.id)
      if (result.ok) toast('ok', result.message ?? '已更新收藏')
      else toast('error', result.error ?? '操作失败')
    },
    [api, toast]
  )

  const changeKind = useCallback(
    async (item: ResourceItem, next: ResourceKind | null): Promise<void> => {
      const result = await api.setKind(item.id, next)
      if (result.ok) toast('ok', result.message ?? '已修改分类')
      else toast('error', result.error ?? '修改分类失败')
    },
    [api, toast]
  )

  const selectKindView = useCallback(
    (nextKind: ResourceKind | null, nextView: ViewId): void => {
      setKind(nextKind)
      setView(nextView)
      setFolder(null)
      setOffset(0)
      select(null)
      setSelectedSeriesKey(null)
      setSeriesDrawerOpen(false)
      if (nextView !== 'folders' && nextView !== 'libraries' && nextView !== 'settings') {
        void patch({ lastView: nextView })
      }
    },
    [patch, select]
  )

  const openFolderNode = useCallback(
    (node: FolderNode): void => {
      setFolder({ libraryId: node.libraryId, relDir: node.relDir })
      setView('folders')
      setOffset(0)
      select(null)
    },
    [select]
  )

  /* ------------------------- 快捷键 ------------------------- */

  useEffect(() => {
    const onKey = (event: KeyboardEvent): void => {
      const target = event.target as HTMLElement | null
      const typing = target?.tagName === 'INPUT' || target?.tagName === 'SELECT' || target?.tagName === 'TEXTAREA'
      if (event.key === 'F5') {
        event.preventDefault()
        refreshIndex()
        return
      }
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'f') {
        event.preventDefault()
        document.querySelector<HTMLInputElement>('.search-box input')?.focus()
        return
      }
      if (typing) return
      if (event.key === 'Escape' && drawerOpen) {
        closeDrawer()
        return
      }
      if (event.key === 'Delete' && detail) void removeItem(detail, false)
      if (event.key === 'Enter' && detail) void activate(detail)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [activate, closeDrawer, detail, drawerOpen, refreshIndex, removeItem])

  /* ------------------------- 渲染数据 ------------------------- */

  const backgroundStyle = useMemo(() => {
    if (!config?.background) return undefined
    return {
      backgroundImage: `url("${api.mediaUrl(config.background)}")`,
      backgroundSize: cssBackgroundSize(config.backgroundMode),
      backgroundRepeat: cssBackgroundRepeat(config.backgroundMode)
    }
  }, [api, config?.background, config?.backgroundMode])

  const overlayStyle = useMemo(
    () => ({ '--overlay': String(config?.overlay ?? 0.4) }) as React.CSSProperties,
    [config?.overlay]
  )

  const detailLine = useMemo(() => {
    if (!detail) return ''
    const parts = [KIND_LABEL[detail.kind], formatSize(detail.size)]
    if (detail.width && detail.height) parts.push(`${detail.width}×${detail.height}`)
    if (detail.cardLine) parts.push(detail.cardLine)
    parts.push(detail.path)
    return parts.join('　|　')
  }, [detail])

  const emptyText = useMemo(() => {
    if (search.trim()) return `没有找到匹配「${search.trim()}」的资源`
    if (isSeriesView) return '还没有漫画：把 CBZ / CBR / 漫画 ZIP 放进资源库后重新扫描即可自动归入这里'
    if (view === 'favorites') return '还没有收藏任何资源（右键资源 → 收藏）'
    if (view === 'duplicates') return '没有发现重复资源'
    if (view === 'recent-used') return '还没有打开过资源'
    if (view === 'recent-added') return '最近 30 天没有新资源'
    if (view === 'folders') return '这个目录下没有资源'
    if (kind) return `「${KIND_LABEL[kind]}」分类下暂无资源`
    return '索引里还没有资源：到「资源库」添加目录后会自动扫描'
  }, [kind, search, view, isSeriesView])

  /** 右键菜单按资源类型区分（未实现的项置灰并写明原因，不伪造功能） */
  const fileMenu = (item: ResourceItem): MenuEntry[] => {
    const items: MenuEntry[] = []
    const isVideo = item.kind === 'movie' || item.kind === 'tv' || item.kind === 'anime'
    const isMedia = isVideo || item.kind === 'music'
    const isImage = item.kind === 'image' || item.kind === 'wallpaper'

    // —— 主操作
    if (isMedia) items.push({ label: item.kind === 'music' ? '播放' : '播放（默认播放器）', onClick: () => void activate(item) })
    else if (item.kind === 'comic') items.push({ label: '阅读（默认程序打开）', onClick: () => void activate(item) })
    else if (item.kind === 'installer' || item.kind === 'software') items.push({ label: '运行', onClick: () => void activate(item) })
    else items.push({ label: '打开', onClick: () => void activate(item) })

    items.push({ label: '查看详情', onClick: () => setDrawerOpen(true) })

    if (isImage) {
      items.push({ label: '查看大图', onClick: () => setPreview(item) })
      items.push({ label: '设置为桌面壁纸', onClick: () => void applyWallpaper(item) })
    }

    // —— 类型专属
    if (item.kind === 'music') {
      items.push({
        label: '查看专辑',
        disabled: true,
        hint: '专辑视图待接入',
        onClick: () => undefined
      })
      items.push({
        label: '加入播放列表',
        disabled: true,
        hint: '播放列表待接入',
        onClick: () => undefined
      })
    }
    if (isVideo || item.kind === 'comic') {
      items.push({
        label: '重新匹配元数据',
        disabled: true,
        hint: 'Phase 4 接入 TMDB',
        onClick: () => undefined
      })
      items.push({
        label: '编辑作品信息',
        disabled: true,
        hint: 'Phase 3 接入',
        onClick: () => undefined
      })
    }

    // —— 通用
    items.push({ separator: true })
    items.push({ label: item.isFavorite ? '取消收藏' : '加入收藏', onClick: () => void toggleFavorite(item) })
    items.push({ label: '修改分类…', onClick: () => setKindPicker(item) })
    items.push({ label: '打开所在文件夹', onClick: () => void api.reveal(item.path) })
    items.push({ label: '复制路径', onClick: () => void api.copyPath(item.path) })
    items.push({ label: '重命名…', onClick: () => setRenaming(item) })
    items.push({
      label: '仅从索引移除',
      disabled: true,
      hint: '需要排除规则，后续接入',
      onClick: () => undefined
    })

    items.push({ separator: true })
    items.push({ label: '删除（进回收站）', danger: true, onClick: () => void removeItem(item, false) })
    items.push({ label: '永久删除', danger: true, onClick: () => void removeItem(item, true) })
    items.push({ label: '刷新索引', onClick: refreshIndex })
    return items
  }

  const emptyMenu = (): MenuEntry[] => [
    { label: '刷新索引', onClick: refreshIndex },
    { label: '重新扫描资源库', onClick: () => void startScan() },
    { separator: true },
    { label: '更换工具箱壁纸…', onClick: () => void chooseBackground() },
    { label: '恢复默认壁纸', onClick: () => void api.resetBackground().then(() => toast('info', '已恢复默认背景')) },
    { separator: true },
    ...OVERLAY_OPTIONS.map<MenuEntry>((option) => ({
      label: `背景遮罩：${option.label}`,
      checked: Math.abs((config?.overlay ?? 0.4) - option.value) < 0.001,
      onClick: () => void patch({ overlay: option.value })
    })),
    { separator: true },
    { label: '设置…', onClick: () => setSettingsOpen(true) },
    { label: '资源库管理', onClick: () => selectKindView(null, 'libraries') },
    { label: '打开索引数据目录', onClick: () => void api.reveal(info?.dataDir ?? '') }
  ]

  /* ------------------------- 背景更换 ------------------------- */

  const chooseBackground = useCallback(async (): Promise<void> => {
    const result = await api.chooseBackground()
    if (result.ok) toast('ok', '工具箱背景已更换')
    else if (!result.canceled) toast('error', result.error ?? '更换背景失败')
  }, [api, toast])

  /* ------------------------- 渲染 ------------------------- */

  return (
    <div className={`app size-${config?.cardSize ?? 'normal'}`}>
      <div className="app-bg" style={backgroundStyle} />
      <div className="app-overlay" style={overlayStyle} />

      <div className="app-body">
        <div className="workspace">
          <Sidebar
            stats={stats}
            view={view}
            kind={kind}
            libraryCount={libraries.length}
            showEmpty={config?.showEmptyCategories ?? false}
            progress={progress}
            onSelectKind={selectKindView}
            onOpenLibraries={() => selectKindView(null, 'libraries')}
            onOpenSettings={() => setSettingsOpen(true)}
            onScan={() => void startScan()}
          />

          <main className="main">
            <TopBar
              hint={hintFor(view, kind, Boolean(search.trim()))}
              detail={detailLine}
              search={search}
              searchKind={searchKind}
              counts={stats?.kinds ?? []}
              sort={sort}
              order={order}
              loading={loading}
              onSearch={(value) => {
                setSearch(value)
                setOffset(0)
              }}
              onSearchKind={(value) => {
                setSearchKind(value)
                setOffset(0)
              }}
              onSort={(value) => {
                setSort(value)
                setOffset(0)
                void patch({ sortBy: value })
              }}
              onToggleOrder={() => {
                const next = order === 'asc' ? 'desc' : 'asc'
                setOrder(next)
                void patch({ sortOrder: next })
              }}
              onRefresh={refreshIndex}
              onScan={() => void startScan()}
              onOpenLibraries={() => selectKindView(null, 'libraries')}
              onOpenSettings={() => setSettingsOpen(true)}
              onOpenMatching={() => setMatchingOpen(true)}
              onChooseBackground={() => void chooseBackground()}
              onOpenDataDir={() => void api.reveal(info?.dataDir ?? '')}
              groupMode={kind && SERIES_KINDS.includes(kind) ? seriesMode : null}
              onToggleGroup={() => setSeriesMode((value) => !value)}
            />

            <div className="main-body">
              <div className="content">
                {view === 'home' ? (
                  <HomeView
                    stats={stats}
                    libraries={libraries}
                    recentAdded={homeStrips.added}
                    recentUsed={homeStrips.used}
                    favorites={homeStrips.favs}
                    loading={loading}
                    onOpenKind={(nextKind) => selectKindView(nextKind, 'all')}
                    onOpenView={(nextView) => selectKindView(null, nextView)}
                    onSelect={select}
                    onActivate={(item) => void activate(item)}
                    onContextMenu={(event, item) => {
                      event.preventDefault()
                      selectForMenu(item)
                      setMenu({ x: event.clientX, y: event.clientY, item })
                    }}
                  />
                ) : view === 'libraries' ? (
                  <LibrariesView
                    libraries={libraries}
                    progress={progress}
                    scanning={scanning}
                    paused={paused}
                    config={config ?? ({ scan: { maxDepth: 0, includeHidden: false, generateThumbnails: true, readMetadata: true, computeHash: true, hashMaxSizeMB: 2048 } } as AppConfig)}
                    onAdd={async () => {
                      const result = await api.addLibrary()
                      if (result.ok) toast('ok', '已添加资源库，正在建立索引…')
                      else if (!result.canceled) toast('error', result.error ?? '添加失败')
                      setRefreshKey((value) => value + 1)
                    }}
                    onRemove={async (library) => {
                      const result = await api.removeLibrary(library.id)
                      if (result.ok) toast('ok', result.message ?? '已移除')
                      setRefreshKey((value) => value + 1)
                    }}
                    onToggle={async (library, enabled) => {
                      await api.setLibraryEnabled(library.id, enabled)
                      setRefreshKey((value) => value + 1)
                    }}
                    onScan={(libraryId) => void startScan(libraryId)}
                    onPause={() => void api.pauseScan()}
                    onResume={() => void api.resumeScan()}
                    onCancel={() => void api.cancelScan()}
                    onOpenFolder={(path) => void api.reveal(path)}
                    onPatch={(partial) => void patch(partial)}
                  />
                ) : (
                  <>
                    <div className="crumb">
                      {view === 'folders' ? (
                        <>
                          <button
                            className="crumb-link"
                            onClick={() => {
                              setFolder(null)
                              select(null)
                            }}
                          >
                            {libraries.find((library) => library.id === folder?.libraryId)?.path ?? '资源库根目录'}
                          </button>
                          {(folder?.relDir ? folder.relDir.split('\\') : []).map((segment, index, all) => (
                            <span key={`${segment}-${index}`}>
                              <span className="crumb-sep"> › </span>
                              <button
                                className="crumb-link"
                                onClick={() => {
                                  setFolder({ libraryId: folder?.libraryId ?? 0, relDir: all.slice(0, index + 1).join('\\') })
                                  select(null)
                                }}
                              >
                                {segment}
                              </button>
                            </span>
                          ))}
                          {folder?.relDir ? (
                            <button
                              className="crumb-link"
                              onClick={() => {
                                const parts = folder.relDir.split('\\')
                                setFolder({ libraryId: folder.libraryId, relDir: parts.slice(0, -1).join('\\') })
                                select(null)
                              }}
                            >
                              ← 返回上级
                            </button>
                          ) : null}
                        </>
                      ) : (
                        <button className="crumb-link" onClick={() => selectKindView(null, 'all')}>
                          {search.trim() ? `搜索：${search.trim()}` : kind ? KIND_LABEL[kind] : '全部资源'}
                        </button>
                      )}
                      <span className="grow" />
                      <span>
                        {loading ? '读取中…' : isSeriesView ? `${seriesItems.length} 部作品` : `${items.length} / ${total} 项`}
                      </span>
                    </div>

                    <ResourceGrid
                      items={items}
                      folders={folders}
                      series={isSeriesView ? seriesItems : undefined}
                      selectedSeriesKey={selectedSeriesKey}
                      onSeriesSelect={selectSeries}
                      onSeriesActivate={(item) => void activateSeries(item)}
                      onSeriesContextMenu={(event, item) => {
                        event.preventDefault()
                        event.stopPropagation()
                        selectSeries(item)
                        setMenu({ x: event.clientX, y: event.clientY, series: item })
                      }}
                      selectedPath={selectedPath}
                      showKind={Boolean(search.trim()) || view === 'duplicates' || (view === 'all' && !kind)}
                      loading={loading}
                      emptyText={emptyText}
                      total={total}
                      hasMore={!isSeriesView && items.length < total}
                      onSelect={select}
                      onActivate={(item) => void activate(item)}
                      onContextMenu={(event, item) => {
                        event.preventDefault()
                        event.stopPropagation()
                        selectForMenu(item)
                        setMenu({ x: event.clientX, y: event.clientY, item })
                      }}
                      onFolderOpen={openFolderNode}
                      onFolderContextMenu={(event, node) => {
                        event.preventDefault()
                        setMenu({ x: event.clientX, y: event.clientY, folder: node })
                      }}
                      onEmptyContextMenu={(event) => {
                        event.preventDefault()
                        setMenu({ x: event.clientX, y: event.clientY })
                      }}
                      onLoadMore={() => setOffset((value) => value + PAGE_SIZE)}
                    />
                  </>
                )}
              </div>

              {seriesDrawerOpen && openSeries ? (
                <SeriesDrawer
                  detail={openSeries}
                  metadata={seriesMetadata}
                  onClose={closeSeries}
                  onOpenVolume={(item) => void activate(item)}
                  onRevealVolume={(item) => void api.reveal(item.path)}
                  onRevealFolder={(path) => void api.reveal(path)}
                  onToggleFavorite={(item) => void toggleFavorite(item)}
                  onMatch={(key) => void runMatch(key)}
                  matching={matching}
                />
              ) : null}

              {drawerOpen && detail ? (
                <DetailDrawer
                  item={detail}
                  detail={detail}
                  media={media}
                  workMetadata={detailMetadata}
                  workPoster={detailPoster}
                  onClose={closeDrawer}
                  onOpen={(item) => void activate(item)}
                  onReveal={(item) => void api.reveal(item.path)}
                  onCopyPath={async (item) => {
                    const result = await api.copyPath(item.path)
                    toast(result.ok ? 'ok' : 'error', result.message ?? result.error ?? '')
                  }}
                  onSetWallpaper={(item) => void applyWallpaper(item)}
                  onPreview={setPreview}
                  onRename={setRenaming}
                  onToggleFavorite={(item) => void toggleFavorite(item)}
                  onChangeKind={(item, next) => void changeKind(item, next)}
                  onRefresh={refreshDetailMetadata}
                  matching={matching}
                />
              ) : null}
            </div>
          </main>
        </div>

        <div className="statusbar">
          <span className="status-version">Version : {info?.version ?? '1.1.0'}</span>
          <span className="grow">
            {busy ||
              (scanning
                ? `正在扫描：${progress?.libraryPath ?? ''} ${progress?.total ? `${progress.scanned}/${progress.total}` : ''}`
                : `索引 ${stats?.total ?? 0} 个资源 · 资源库 ${stats?.libraries ?? 0} 个 · ${stats ? formatSize(stats.totalSize) : ''}`)}
          </span>
          <span>所有数据都在本地，不依赖云端</span>
        </div>
      </div>

      {menu ? (
        <ContextMenu
          x={menu.x}
          y={menu.y}
          items={
            menu.item
              ? fileMenu(menu.item)
              : menu.series
                ? [
                    { label: '阅读第一卷', onClick: () => void activateSeries(menu.series as SeriesItem) },
                    { label: '查看详情', onClick: () => setSeriesDrawerOpen(true) },
                    { separator: true },
                    {
                      label: openSeries?.series.isFavorite ? '取消收藏' : '加入收藏',
                      onClick: () => {
                        const first = openSeries?.volumes[0]
                        if (first) void toggleFavorite(first)
                      }
                    },
                    {
                      label: '打开所在文件夹',
                      onClick: () => {
                        const path = menu.series?.coverPath ?? ''
                        const sep = path.lastIndexOf('\\')
                        if (sep > 0) void api.reveal(path.slice(0, sep))
                      }
                    },
                    {
                      label: '复制作品名',
                      onClick: () => void api.copyPath(menu.series?.title ?? '')
                    },
                    { separator: true },
                    {
                      label: '在线匹配元数据',
                      disabled: true,
                      hint: 'Phase 7 接入 AniList',
                      onClick: () => undefined
                    },
                    { label: '刷新索引', onClick: refreshIndex }
                  ]
                : menu.folder
                ? [
                    { label: '打开这个目录', onClick: () => openFolderNode(menu.folder as FolderNode) },
                    {
                      label: '在资源管理器中打开',
                      onClick: () => {
                        const lib = libraries.find((library) => library.id === menu.folder?.libraryId)
                        if (lib) void api.reveal(`${lib.path}\\${menu.folder?.relDir ?? ''}`)
                      }
                    },
                    { label: '刷新索引', onClick: refreshIndex }
                  ]
                : emptyMenu()
          }
          onClose={() => setMenu(null)}
        />
      ) : null}

      {preview ? (
        <PreviewModal
          item={preview}
          onClose={() => setPreview(null)}
          onSetWallpaper={(item) => void applyWallpaper(item)}
          onOpen={(item) => void activate(item)}
        />
      ) : null}

      {renaming ? (
        <RenameDialog item={renaming} onCancel={() => setRenaming(null)} onSubmit={(name) => void submitRename(renaming, name)} />
      ) : null}

      {kindPicker ? (
        <KindPickerDialog
          item={kindPicker}
          current={detail?.overridden ? detail.kind : null}
          onPick={(next) => {
            void changeKind(kindPicker, next)
            setKindPicker(null)
          }}
          onClose={() => setKindPicker(null)}
        />
      ) : null}

      {settingsOpen && config ? (
        <SettingsDialog
          config={config}
          info={info}
          onPatch={(partial) => void patch(partial)}
          onChooseBackground={() => void chooseBackground()}
          onResetBackground={() => {
            void api.resetBackground().then(() => toast('info', '已恢复默认背景'))
          }}
          onRevealDataDir={() => void api.reveal(info?.dataDir ?? '')}
          onSetKey={async (key) => {
            try {
              const result = await api.metaSetKey(key)
              toast(result.hasKey ? 'ok' : 'error', result.hasKey ? 'TMDB API Key 已保存（只存在本机）' : 'Key 为空，未保存')
              return result.hasKey
            } catch (err) {
              toast('error', `保存失败：${err instanceof Error ? err.message : String(err)}`)
              return false
            }
          }}
          onClearKey={async () => {
            await api.metaClearKey()
            toast('info', '已清除 TMDB API Key')
          }}
          onCacheCleared={(message) => {
            toast('info', message)
            setRefreshKey((value) => value + 1)
          }}
          onClose={() => setSettingsOpen(false)}
        />
      ) : null}

      {matchingOpen ? (
        <MatchingCenter
          onClose={() => setMatchingOpen(false)}
          onToast={(level, message) => toast(level, message)}
          onChanged={() => {
            setMetadataVersion((value) => value + 1)
            setRefreshKey((value) => value + 1)
          }}
        />
      ) : null}

      <Toasts items={toasts} />
    </div>
  )
}

function next_total(
  added: { total: number },
  used: { total: number },
  favs: { total: number }
): number {
  return Math.max(added.total, used.total, favs.total)
}
