import { KIND_LABEL } from '@shared/resource-kinds'
import type { BackgroundMode, ResourceKind, SortBy, WallpaperStyleId } from '@shared/types'

/** 顶部提示栏文案：按当前视图/分类动态变化 */
export function hintFor(view: string, kind: ResourceKind | null, searching: boolean): string {
  if (searching) return `正在全库搜索：输入关键字即时过滤，可用右侧类型按钮缩小范围。`
  if (kind) {
    const map: Partial<Record<ResourceKind, string>> = {
      movie: '提示：单击查看影片信息，双击用系统默认播放器播放。',
      tv: '提示：单击查看剧集信息，双击用系统默认播放器播放。',
      anime: '提示：单击查看番剧信息，双击用系统默认播放器播放。',
      music: '提示：单击查看歌曲信息，双击用系统默认播放器播放。',
      novel: '提示：单击查看书籍信息，双击用默认阅读器打开。',
      comic: '提示：单击作品查看卷列表，双击阅读第一卷；切到「按文件」可看单卷。',
      document: '提示：单击查看文档信息，双击用默认程序打开。',
      image: '提示：单击预览图片，双击用系统看图程序打开。',
      wallpaper: '提示：单击预览壁纸，双击将其设置为 Windows 桌面壁纸。',
      installer: '提示：单击查看安装包信息，双击启动安装程序。',
      archive: '提示：单击查看压缩包信息，双击用系统关联的解压软件打开。',
      software: '提示：这是绿色软件目录里的程序文件，双击运行。',
      other: '提示：未识别的资源，可右键手动修改分类。'
    }
    return map[kind] ?? `提示：单击查看${KIND_LABEL[kind]}资源信息，双击执行默认动作。`
  }
  switch (view) {
    case 'home':
      return '提示：这里是资源总览，点击左侧分类或下方卡片进入；扫描会自动在后台进行。'
    case 'recent-added':
      return '提示：最近 30 天新索引到的资源，按加入时间排序。'
    case 'recent-used':
      return '提示：最近打开过的资源（最多保留 200 条）。'
    case 'favorites':
      return '提示：你收藏的资源；右键可以取消收藏。'
    case 'duplicates':
      return '提示：重复资源按「大小 + SHA-256」判定，右键可定位到具体文件。'
    case 'folders':
      return '提示：目录浏览保留真实文件夹结构，与左侧虚拟分类互不冲突。'
    case 'libraries':
      return '提示：添加多个本地目录作为资源库，程序会递归扫描并自动分类。'
    default:
      return '提示：单击选择资源查看信息，双击用系统默认程序打开。'
  }
}

export const SORT_OPTIONS: { value: SortBy; label: string }[] = [
  { value: 'name', label: '按名称' },
  { value: 'mtime', label: '按修改时间' },
  { value: 'size', label: '按大小' },
  { value: 'added', label: '按加入时间' },
  { value: 'kind', label: '按类型' },
  { value: 'opened', label: '按打开时间' }
]

export const OVERLAY_OPTIONS: { value: number; label: string }[] = [
  { value: 0, label: '0%' },
  { value: 0.2, label: '20%' },
  { value: 0.4, label: '40%' },
  { value: 0.6, label: '60%' },
  { value: 0.8, label: '80%' }
]

export const BACKGROUND_MODE_OPTIONS: { value: BackgroundMode; label: string }[] = [
  { value: 'cover', label: '填充（裁切铺满）' },
  { value: 'contain', label: '适应（完整显示）' },
  { value: 'stretch', label: '拉伸' },
  { value: 'tile', label: '平铺' },
  { value: 'center', label: '居中' }
]

export const WALLPAPER_STYLE_OPTIONS: { value: WallpaperStyleId; label: string }[] = [
  { value: 'fill', label: '填充' },
  { value: 'fit', label: '适应' },
  { value: 'stretch', label: '拉伸' },
  { value: 'tile', label: '平铺' },
  { value: 'center', label: '居中' },
  { value: 'span', label: '跨屏' }
]

/**
 * Phase 10：列表超过这个数量就走「真虚拟网格」——只渲染可视区域的行。
 * 小列表保持原来的整体渲染（观感与行为完全不变，降低风险）。
 */
export const VIRTUAL_THRESHOLD = 200

/** 虚拟网格一次最多预读多少条（避免超大库一次拉爆 IPC） */
export const VIRTUAL_MAX_ITEMS = 4000

/** 与 styles.css 里 .grid 的 minmax() 下限保持一致（仅作首帧兜底，随后按实测卡片宽修正） */
export const GRID_MIN_CARD = 116
export const GRID_GAP_X = 3
export const GRID_GAP_Y = 3
/** 卡片文字区高度的首帧兜底（随后按实测卡片高 - 缩略图高修正） */
export const CARD_META_HEIGHT = 42

/** 卡片缩略图的高宽比（按卡片形状） */
export function shapeAspect(shape: string): number {
  switch (shape) {
    case 'poster':
      return 3 / 2
    case 'photo':
    case 'wide':
      return 9 / 16
    default:
      return 1
  }
}

export function cssBackgroundSize(mode: BackgroundMode): string {  switch (mode) {
    case 'contain':
      return 'contain'
    case 'stretch':
      return '100% 100%'
    case 'tile':
    case 'center':
      return 'auto'
    default:
      return 'cover'
  }
}

export function cssBackgroundRepeat(mode: BackgroundMode): string {
  return mode === 'tile' ? 'repeat' : 'no-repeat'
}

export function kindLabel(kind: ResourceKind): string {
  return KIND_LABEL[kind] ?? kind
}

/**
 * 在渲染进程里把任意图片（webp / avif…）转成 PNG dataURL，
 * 因为 Windows 的壁纸 API 不认 webp。
 */
export function imageToPngDataUrl(url: string, maxSize = 2560): Promise<string> {
  return new Promise((resolve, reject) => {
    const image = new Image()
    image.onload = () => {
      try {
        const longest = Math.max(image.naturalWidth, image.naturalHeight)
        const scale = longest > maxSize ? maxSize / longest : 1
        const width = Math.max(1, Math.round(image.naturalWidth * scale))
        const height = Math.max(1, Math.round(image.naturalHeight * scale))
        const canvas = document.createElement('canvas')
        canvas.width = width
        canvas.height = height
        const ctx = canvas.getContext('2d')
        if (!ctx) {
          reject(new Error('无法创建画布'))
          return
        }
        ctx.drawImage(image, 0, 0, width, height)
        resolve(canvas.toDataURL('image/png'))
      } catch (err) {
        reject(err instanceof Error ? err : new Error(String(err)))
      }
    }
    image.onerror = () => reject(new Error('图片解码失败'))
    image.src = url
  })
}
