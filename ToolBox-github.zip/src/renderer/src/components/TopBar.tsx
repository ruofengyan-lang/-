import { useRef, useState } from 'react'
import { KIND_LABEL, KIND_ORDER } from '@shared/resource-kinds'
import type { KindCount, ResourceKind, SortBy, SortOrder } from '@shared/types'
import ContextMenu, { type MenuEntry } from './ContextMenu'
import { SORT_OPTIONS } from '../utils'

interface Props {
  hint: string
  detail: string
  search: string
  searchKind: ResourceKind | null
  counts: KindCount[]
  sort: SortBy
  order: SortOrder
  loading: boolean
  onSearch: (value: string) => void
  onSearchKind: (kind: ResourceKind | null) => void
  onSort: (value: SortBy) => void
  onToggleOrder: () => void
  onRefresh: () => void
  onScan: () => void
  onOpenLibraries: () => void
  onOpenSettings: () => void
  onChooseBackground: () => void
  onOpenDataDir: () => void
  /** Phase 9：打开元数据匹配中心 */
  onOpenMatching: () => void
  /** null = 当前分类不支持作品聚合（不显示切换） */
  groupMode?: boolean | null
  onToggleGroup?: () => void
}

/** 顶部栏只保留高频操作：搜索 / 筛选 / 排序 / 刷新；扫描、设置等收进「更多」 */
export default function TopBar(props: Props): React.JSX.Element {
  const { hint, detail, search, searchKind, counts, sort, order, loading } = props
  const [menuAt, setMenuAt] = useState<{ x: number; y: number } | null>(null)
  const moreRef = useRef<HTMLButtonElement>(null)
  const countOf = (kind: ResourceKind): number => counts.find((item) => item.kind === kind)?.count ?? 0
  const kinds = KIND_ORDER.filter((kind) => countOf(kind) > 0)

  const openMore = (): void => {
    const rect = moreRef.current?.getBoundingClientRect()
    setMenuAt({ x: rect ? rect.right - 210 : 200, y: rect ? rect.bottom + 6 : 60 })
  }

  const moreItems: MenuEntry[] = [
    { label: '立即扫描资源库', onClick: props.onScan },
    { label: '资源库管理…', onClick: props.onOpenLibraries },
    { separator: true },
    { label: '元数据匹配中心…', onClick: props.onOpenMatching },
    { separator: true },
    { label: '更换工具箱背景…', onClick: props.onChooseBackground },
    { label: '打开索引数据目录', onClick: props.onOpenDataDir },
    { separator: true },
    { label: '设置…', onClick: props.onOpenSettings }
  ]

  return (
    <div className="topbar">
      <div className="topbar-hint">
        <div className="hint-text" title={hint}>
          {hint}
        </div>
        {detail ? (
          <div className="hint-sub" title={detail}>
            {detail}
          </div>
        ) : null}
      </div>

      <div className="topbar-tools">
        <div className="search-box">
          <input
            type="text"
            value={search}
            placeholder="搜索整个资源库…"
            spellCheck={false}
            onChange={(event) => props.onSearch(event.target.value)}
          />
          {search ? (
            <button className="search-clear" title="清空搜索" onClick={() => props.onSearch('')}>
              ×
            </button>
          ) : null}
        </div>

        <select
          className="tool-btn"
          title="按资源类型筛选"
          value={searchKind ?? ''}
          onChange={(event) => props.onSearchKind((event.target.value || null) as ResourceKind | null)}
        >
          <option value="">全部类型</option>
          {kinds.map((kind) => (
            <option key={kind} value={kind}>
              {KIND_LABEL[kind]}（{countOf(kind)}）
            </option>
          ))}
        </select>

        <select
          className="tool-btn"
          value={sort}
          title="排序方式"
          onChange={(event) => props.onSort(event.target.value as SortBy)}
        >
          {SORT_OPTIONS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>

        <button
          className="tool-btn narrow"
          title={order === 'asc' ? '升序，点击切换为降序' : '降序，点击切换为升序'}
          onClick={props.onToggleOrder}
        >
          {order === 'asc' ? '↑' : '↓'}
        </button>

        <button className="tool-btn narrow" title="重新读取索引（F5）" onClick={props.onRefresh} disabled={loading}>
          <span className={loading ? 'spin' : undefined}>⟳</span>
        </button>

        {props.groupMode !== null && props.groupMode !== undefined ? (
          <button
            className="tool-btn"
            title={props.groupMode ? '当前按「作品」聚合（一部漫画一张卡），点击切换为按文件' : '当前按「文件」显示，点击切换为按作品聚合'}
            onClick={props.onToggleGroup}
          >
            {props.groupMode ? '按作品' : '按文件'}
          </button>
        ) : null}

        <button ref={moreRef} className="tool-btn" title="更多操作" onClick={openMore}>
          ⋯ 更多
        </button>
      </div>

      {menuAt ? <ContextMenu x={menuAt.x} y={menuAt.y} items={moreItems} onClose={() => setMenuAt(null)} /> : null}
    </div>
  )
}
