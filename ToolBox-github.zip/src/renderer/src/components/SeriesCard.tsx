import { useEffect, useRef, useState } from 'react'
import { formatSize } from '@shared/format'
import type { SeriesItem } from '@shared/types'

/**
 * 作品（系列）卡片：漫画墙用的海报卡。
 * 封面优先级由主进程的缩略图管线决定（同目录 cover.jpg → 包内首图）。
 */
interface Props {
  item: SeriesItem
  selected: boolean
  onSelect: (item: SeriesItem) => void
  onActivate: (item: SeriesItem) => void
  onContextMenu: (event: React.MouseEvent, item: SeriesItem) => void
}

export default function SeriesCard({ item, selected, onSelect, onActivate, onContextMenu }: Props): React.JSX.Element {
  const cardRef = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(false)
  const [src, setSrc] = useState<string | null>(null)

  useEffect(() => {
    const element = cardRef.current
    if (!element) return
    if (typeof IntersectionObserver === 'undefined') {
      setVisible(true)
      return
    }
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((entry) => entry.isIntersecting)) {
          setVisible(true)
          observer.disconnect()
        }
      },
      { rootMargin: '800px 0px' }
    )
    observer.observe(element)
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    if (!visible) return
    let alive = true
    setSrc(null)
    void (async () => {
      const thumb = await window.toolbox.thumb(item.coverPath, item.mtimeMs, item.kind).catch(() => null)
      if (!alive) return
      if (thumb) {
        setSrc(window.toolbox.mediaUrl(thumb))
        return
      }
      const icon = await window.toolbox.icon(item.coverPath, item.mtimeMs).catch(() => null)
      if (alive && icon) setSrc(icon)
    })()
    return () => {
      alive = false
    }
  }, [visible, item.coverPath, item.mtimeMs, item.kind])

  const isMusic = item.kind === 'music'
  const unit = isMusic ? '首' : '卷'
  const volumeText =
    item.numberedCount > 0 && item.numberedCount < item.volumeCount
      ? `${item.volumeCount} ${unit}（识别编号 ${item.numberedCount}）`
      : isMusic
        ? `${item.volumeCount} 首`
        : item.volumeCount > 1
          ? `${item.volumeCount} 卷`
          : '单卷'

  const tip = [`${item.title}`, volumeText, `共 ${formatSize(item.totalSize)}`, item.coverPath]
    .filter(Boolean)
    .join('\n')

  return (
    <div
      ref={cardRef}
      className={`tile card card-poster series-card${selected ? ' selected' : ''}`}
      title={tip}
      onClick={(event) => {
        event.stopPropagation()
        onSelect(item)
      }}
      onDoubleClick={(event) => {
        event.stopPropagation()
        onActivate(item)
      }}
      onContextMenu={(event) => onContextMenu(event, item)}
    >
      <div className="tile-thumb">
        {src ? <img src={src} alt="" draggable={false} /> : <span className="thumb-placeholder">{isMusic ? 'ALBUM' : 'COMIC'}</span>}
        {item.isFavorite ? (
          <span className="tile-fav" title="已收藏">
            ★
          </span>
        ) : null}
        {item.volumeCount > 1 ? <span className="series-count">{item.volumeCount}</span> : null}
      </div>
      <div className="tile-meta">
        <div className="tile-label" title={item.title}>
          {item.title}
        </div>
        <div className="tile-sub">{volumeText}</div>
      </div>
    </div>
  )
}
