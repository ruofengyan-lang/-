import { formatSize, formatTime } from '@shared/format'
import { KIND_LABEL } from '@shared/resource-kinds'
import type { AppConfig, Library, ScanProgress } from '@shared/types'

interface Props {
  libraries: Library[]
  progress: ScanProgress | null
  scanning: boolean
  paused: boolean
  config: AppConfig
  onAdd: () => void
  onRemove: (library: Library) => void
  onToggle: (library: Library, enabled: boolean) => void
  onScan: (libraryId?: number) => void
  onPause: () => void
  onResume: () => void
  onCancel: () => void
  onOpenFolder: (path: string) => void
  onPatch: (patch: Partial<AppConfig>) => void
}

export default function LibrariesView(props: Props): React.JSX.Element {
  const { libraries, progress, scanning, paused, config } = props
  const scan = config.scan

  const phaseLabel: Record<string, string> = {
    counting: '统计文件数量',
    scanning: '扫描文件',
    indexing: '整理索引',
    metadata: '读取媒体信息',
    thumbnails: '生成缩略图',
    hashing: '计算校验值（去重）',
    paused: '已暂停',
    done: '已完成',
    idle: '空闲'
  }

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="page-title">资源库管理</div>
          <div className="page-sub">
            添加任意本地目录（可多个），程序递归扫描 → 识别类型 → 建立索引 → 自动归入左侧虚拟分类。移动硬盘目录也可以添加。
          </div>
        </div>
        <div className="page-actions">
          <button className="tool-btn" onClick={props.onAdd}>
            ⊕ 添加目录
          </button>
          <button className="tool-btn" onClick={() => props.onScan()} disabled={scanning}>
            ⟳ 立即扫描
          </button>
          {scanning ? (
            <>
              {paused ? (
                <button className="tool-btn" onClick={props.onResume}>
                  ▶ 继续
                </button>
              ) : (
                <button className="tool-btn" onClick={props.onPause}>
                  ⏸ 暂停
                </button>
              )}
              <button className="tool-btn" onClick={props.onCancel}>
                ✕ 取消
              </button>
            </>
          ) : null}
        </div>
      </div>

      {progress && scanning ? (
        <div className="scan-panel">
          <div className="scan-panel-head">
            <span>{phaseLabel[progress.phase] ?? progress.phase}</span>
            <span>
              {progress.total > 0 ? `${progress.scanned} / ${progress.total}` : progress.scanned}
            </span>
          </div>
          <div className="scan-bar big">
            <span
              style={{
                width: `${progress.total > 0 ? Math.min(100, Math.round((progress.scanned / progress.total) * 100)) : 6}%`
              }}
            />
          </div>
          <div className="scan-current" title={progress.current}>
            {progress.libraryPath}
            {progress.current ? ` › ${progress.current}` : ''}
          </div>
          <div className="scan-counts">
            {progress.counts
              .slice()
              .sort((a, b) => b.count - a.count)
              .slice(0, 12)
              .map((entry) => (
                <span key={entry.kind} className={`kind-chip kind-${entry.kind}`}>
                  {KIND_LABEL[entry.kind]} {entry.count}
                </span>
              ))}
          </div>
        </div>
      ) : null}

      <div className="lib-list">
        {libraries.length === 0 ? (
          <div className="strip-empty">还没有资源库，点「添加目录」选择你的下载 / 影视 / 音乐目录。</div>
        ) : (
          libraries.map((library) => (
            <div key={library.id} className={`lib-row${library.enabled ? '' : ' disabled'}`}>
              <label className="lib-check" title={library.enabled ? '已启用（参与索引）' : '已禁用'}>
                <input
                  type="checkbox"
                  checked={library.enabled}
                  onChange={(event) => props.onToggle(library, event.target.checked)}
                />
              </label>
              <div className="lib-main">
                <div className="lib-path" title={library.path}>
                  {library.path}
                </div>
                <div className="lib-meta">
                  {library.resourceCount} 个资源
                  {library.lastScanned > 0 ? ` · 上次扫描 ${formatTime(library.lastScanned)}` : ' · 尚未扫描'}
                </div>
              </div>
              <div className="lib-actions">
                <button className="tool-btn" onClick={() => props.onScan(library.id)} disabled={scanning}>
                  扫描
                </button>
                <button className="tool-btn" onClick={() => props.onOpenFolder(library.path)}>
                  打开
                </button>
                <button className="tool-btn danger" onClick={() => props.onRemove(library)}>
                  移除
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="page-section">
        <div className="page-section-title">扫描设置</div>
        <div className="opt-grid">
          <label className="opt-row">
            <span>扫描深度</span>
            <select
              className="tool-btn"
              value={String(scan.maxDepth)}
              onChange={(event) => props.onPatch({ scan: { ...scan, maxDepth: Number(event.target.value) } })}
            >
              <option value="0">不限（递归全部）</option>
              <option value="1">1 层</option>
              <option value="2">2 层</option>
              <option value="3">3 层</option>
              <option value="5">5 层</option>
            </select>
          </label>
          <label className="opt-row">
            <span>扫描隐藏文件</span>
            <input
              type="checkbox"
              checked={scan.includeHidden}
              onChange={(event) => props.onPatch({ scan: { ...scan, includeHidden: event.target.checked } })}
            />
          </label>
          <label className="opt-row">
            <span>生成缩略图</span>
            <input
              type="checkbox"
              checked={scan.generateThumbnails}
              onChange={(event) => props.onPatch({ scan: { ...scan, generateThumbnails: event.target.checked } })}
            />
          </label>
          <label className="opt-row">
            <span>读取媒体信息</span>
            <input
              type="checkbox"
              checked={scan.readMetadata}
              onChange={(event) => props.onPatch({ scan: { ...scan, readMetadata: event.target.checked } })}
            />
          </label>
          <label className="opt-row">
            <span>计算 SHA-256（去重）</span>
            <input
              type="checkbox"
              checked={scan.computeHash}
              onChange={(event) => props.onPatch({ scan: { ...scan, computeHash: event.target.checked } })}
            />
          </label>
          <label className="opt-row">
            <span>参与哈希的最大文件</span>
            <select
              className="tool-btn"
              value={String(scan.hashMaxSizeMB)}
              onChange={(event) => props.onPatch({ scan: { ...scan, hashMaxSizeMB: Number(event.target.value) } })}
            >
              <option value="256">256 MB</option>
              <option value="1024">1 GB</option>
              <option value="2048">2 GB</option>
              <option value="8192">8 GB</option>
              <option value="65536">不限</option>
            </select>
          </label>
        </div>
        <div className="page-note">
          默认不会扫描 Windows 系统目录（C:\Windows、Program Files、ProgramData、AppData 等），除非你主动把它们加为资源库。
          压缩包只读取目录列表用于判断内容，不会自动解压。
        </div>
      </div>
    </div>
  )
}
