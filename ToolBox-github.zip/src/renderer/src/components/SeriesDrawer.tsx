import { useEffect, useState } from 'react'
import { formatSize } from '@shared/format'
import { MATCH_STATUS_HINT, MATCH_STATUS_LABEL } from '@shared/metadata-labels'
import { KIND_LABEL } from '@shared/resource-kinds'
import type { MetadataRecord, ResourceItem, SeriesDetail } from '@shared/types'

interface Props {
  detail: SeriesDetail
  /** 作品元数据（Phase 3），可能还没有 */
  metadata?: MetadataRecord | null
  onClose: () => void
  onOpenVolume: (item: ResourceItem) => void
  onRevealVolume: (item: ResourceItem) => void
  onRevealFolder: (path: string) => void
  onToggleFavorite: (item: ResourceItem) => void
  /** 触发一次匹配（Phase 3 没有在线 Provider，会如实返回原因） */
  onMatch?: (seriesKey: string) => void
  /** 正在联网抓取 */
  matching?: boolean
}

/**
 * 作品详情抽屉（漫画先行）：
 * 封面 / 作品名 / 作者（待在线匹配）/ 卷数 / 卷列表 / 阅读入口。
 */
export default function SeriesDrawer(props: Props): React.JSX.Element {
  const { detail } = props
  const meta = props.metadata ?? null
  const { series, volumes } = detail
  const [cover, setCover] = useState<string | null>(null)
  const [activeId, setActiveId] = useState<number>(series.firstResourceId)

  useEffect(() => {
    let alive = true
    setCover(null)
    void (async () => {
      const thumb = await window.toolbox
        .thumb(series.coverPath, series.mtimeMs, series.kind, 'detail')
        .catch(() => null)
      if (!alive) return
      if (thumb) setCover(window.toolbox.mediaUrl(thumb))
    })()
    return () => {
      alive = false
    }
  }, [series.coverPath, series.mtimeMs, series.kind])

  useEffect(() => {
    const onKey = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') props.onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [props])

  const isMusic = series.kind === 'music'
  const unit = isMusic ? '首' : '卷'
  const first = volumes.find((item) => item.id === series.firstResourceId) ?? volumes[0]
  const folderPath = detail.relDir ? `${detail.libraryPath}\\${detail.relDir}` : detail.libraryPath

  return (
    <aside className="drawer" onClick={(event) => event.stopPropagation()}>
      <div className="drawer-head">
        <span className={`kind-dot kind-${series.kind}`} />
        <span className="drawer-kind">{KIND_LABEL[series.kind]}</span>
        <span className="grow" />
        <button
          className={`fav-btn${series.isFavorite ? ' on' : ''}`}
          title={series.isFavorite ? '取消收藏（对第一卷生效）' : '加入收藏（对第一卷生效）'}
          onClick={() => first && props.onToggleFavorite(first)}
        >
          ★
        </button>
        <button className="drawer-close" title="关闭详情（Esc）" onClick={props.onClose}>
          ×
        </button>
      </div>

      <div className="drawer-scroll">
        <div className="drawer-poster poster-poster">
          {cover ? (
            <img src={cover} alt={series.title} draggable={false} />
          ) : (
            <div className="drawer-poster-empty">
              <span>COMIC</span>
              <small>暂无封面</small>
            </div>
          )}
        </div>

        <div className="drawer-title">
          <h2 title={series.title}>{series.title}</h2>
          <div className="drawer-sub">
            {series.volumeCount} {unit} · {formatSize(series.totalSize)}
            {series.numberedCount > 0 && series.numberedCount < series.volumeCount
              ? ` · 其中 ${series.numberedCount} ${unit}识别出编号`
              : ''}
          </div>
        </div>

        <div className="drawer-actions">
          <button className="btn primary block" onClick={() => first && props.onOpenVolume(first)}>
            {isMusic ? '▶ 播放第一首' : '▶ 阅读第一卷'}
          </button>
          <div className="drawer-actions-row">
            <button className="tool-btn" onClick={() => props.onRevealFolder(folderPath)}>
              打开文件夹
            </button>
            <button
              className={`tool-btn${props.matching ? ' busy' : ''}`}
              disabled={props.matching}
              title={
                props.matching
                  ? '正在联网抓取…'
                  : '刷新信息：用已配置的 API 联网抓取这部作品的元数据与封面（需要先在设置里填 TMDB API Key 与代理）'
              }
              onClick={() => props.onMatch?.(series.key)}
            >
              <span className={props.matching ? 'spin' : undefined}>⟳</span> {props.matching ? '抓取中…' : '刷新信息'}
            </button>
            <button
              className="tool-btn"
              disabled
              title="编辑作品信息（新增/修改元数据）排在下一步，届时可在匹配中心里手动改"
            >
              编辑信息
            </button>
          </div>
        </div>

        <div className="drawer-section">
          <div className="drawer-section-title">作品信息</div>
          <div className="info-rows">
            <div className="info-row">
              <span className="info-key">名称</span>
              <span className="info-val">{meta?.title || series.title}</span>
            </div>
            <div className="info-row">
              <span className="info-key">原名</span>
              <span className={meta?.originalTitle ? 'info-val' : 'info-val muted'}>
                {meta?.originalTitle || '未匹配（Phase 4~7 接入在线元数据）'}
              </span>
            </div>
            <div className="info-row">
              <span className="info-key">作者</span>
              <span className={meta?.author ? 'info-val' : 'info-val muted'}>
                {meta?.author || '未匹配（Phase 4~7 接入在线元数据）'}
              </span>
            </div>
            {meta && meta.year > 0 ? (
              <div className="info-row">
                <span className="info-key">年份</span>
                <span className="info-val">{meta.year}</span>
              </div>
            ) : null}
            <div className="info-row">
              <span className="info-key">{isMusic ? '曲目' : '卷数'}</span>
              <span className="info-val">
                {series.volumeCount} {unit}
              </span>
            </div>
            <div className="info-row">
              <span className="info-key">元数据</span>
              <span className="info-val" title={meta ? MATCH_STATUS_HINT[meta.matchStatus] : ''}>
                {meta ? `${MATCH_STATUS_LABEL[meta.matchStatus]}${meta.externalSource ? ` · ${meta.externalSource}` : ''}` : '未处理'}
              </span>
            </div>
            <div className="info-row">
              <span className="info-key">位置</span>
              <span className="info-val" title={folderPath}>
                {folderPath}
              </span>
            </div>
          </div>
          {meta && meta.genres.length > 0 ? (
            <div className="genre-tags">
              {meta.genres.map((genre) => (
                <span className="genre-tag" key={genre}>
                  {genre}
                </span>
              ))}
            </div>
          ) : null}
          <div className="drawer-note">
            {meta?.overview
              ? meta.overview
              : `卷号从文件名解析（第N卷 / Vol.N / 末尾数字）；封面按「同目录 cover.jpg → 包内首图」取用。${
                  meta?.matchStatus === 'local'
                    ? '作者等信息来自本地文件与文件名解析；在线元数据（原名、简介、评分）会在 Phase 4~7 接入后补齐。'
                    : '在线元数据（TMDB / MusicBrainz / Open Library / AniList）会在 Phase 4~7 接入。'
                }`}
          </div>
        </div>

        <div className="drawer-section">
          <div className="drawer-section-title">
            {isMusic ? '曲目列表' : '卷列表'}（{volumes.length}）
          </div>
          <div className="volume-list">
            {volumes.map((item) => (
              <div
                key={item.id}
                className={`volume-row${item.id === activeId ? ' active' : ''}`}
                title={`${item.name}\n${formatSize(item.size)}\n双击${isMusic ? '播放' : '阅读'}`}
                onClick={() => setActiveId(item.id)}
                onDoubleClick={() => props.onOpenVolume(item)}
              >
                <span className="volume-index">
                  {item.volume > 0 ? (isMusic ? `第 ${item.volume} 轨` : `第 ${item.volume} 卷`) : '未编号'}
                </span>
                <span className="volume-name">{item.name}</span>
                <span className="volume-size">{formatSize(item.size)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </aside>
  )
}
