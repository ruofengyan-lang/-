import { formatSize } from '@shared/format'
import { KIND_LABEL, KIND_ORDER } from '@shared/resource-kinds'
import type { Library, LibraryStats, ResourceItem, ResourceKind, ViewId } from '@shared/types'
import ResourceCard from './ResourceCard'

interface Props {
  stats: LibraryStats | null
  libraries: Library[]
  recentAdded: ResourceItem[]
  recentUsed: ResourceItem[]
  favorites: ResourceItem[]
  loading: boolean
  onOpenKind: (kind: ResourceKind) => void
  onOpenView: (view: ViewId) => void
  onSelect: (item: ResourceItem) => void
  onActivate: (item: ResourceItem) => void
  onContextMenu: (event: React.MouseEvent, item: ResourceItem) => void
}

/**
 * 内容型首页：最近添加 / 最近使用 / 收藏 三条内容带在前，
 * 分类入口在后，统计数字压成一行小字，不再是视觉主体。
 */
export default function HomeView(props: Props): React.JSX.Element {
  const { stats, libraries, loading } = props
  const countOf = (kind: ResourceKind): number => stats?.kinds.find((item) => item.kind === kind)?.count ?? 0
  const kinds = KIND_ORDER.map((kind) => ({ kind, count: countOf(kind) })).filter((entry) => entry.count > 0)

  const strip = (items: ResourceItem[], emptyText: string, onMore: () => void): React.JSX.Element => (
    <>
      <div className="strip">
        {items.length === 0 ? (
          <div className="strip-empty">{loading ? '读取中…' : emptyText}</div>
        ) : (
          items.map((item) => (
            <ResourceCard
              key={item.id}
              item={item}
              selected={false}
              showKind={false}
              onSelect={props.onSelect}
              onActivate={props.onActivate}
              onContextMenu={props.onContextMenu}
            />
          ))
        )}
      </div>
      {items.length > 0 ? (
        <button className="link-btn strip-more" onClick={onMore}>
          查看全部 ›
        </button>
      ) : null}
    </>
  )

  return (
    <div className="home">
      <section className="home-section">
        <header>
          <span>最近添加</span>
          {stats && stats.recentAdded > 0 ? <span className="home-count">{stats.recentAdded}</span> : null}
        </header>
        {strip(props.recentAdded, '最近 30 天没有新资源', () => props.onOpenView('recent-added'))}
      </section>

      <section className="home-section">
        <header>
          <span>最近使用</span>
          {stats && stats.recentUsed > 0 ? <span className="home-count">{stats.recentUsed}</span> : null}
        </header>
        {strip(props.recentUsed, '还没有打开过资源：双击任意资源即可打开，之后会出现在这里', () =>
          props.onOpenView('recent-used')
        )}
      </section>

      <section className="home-section">
        <header>
          <span>收藏</span>
          {stats && stats.favorites > 0 ? <span className="home-count">{stats.favorites}</span> : null}
        </header>
        {strip(props.favorites, '还没有收藏：右键资源 → 加入收藏', () => props.onOpenView('favorites'))}
      </section>

      <section className="home-section">
        <header>
          <span>分类入口</span>
          <button className="link-btn" onClick={() => props.onOpenView('libraries')}>
            资源库 {libraries.length}
          </button>
        </header>
        <div className="home-kinds">
          {kinds.length === 0 ? (
            <div className="strip-empty">
              {loading ? '正在读取索引…' : '还没有资源：到「资源库」添加目录后会自动扫描并分类。'}
            </div>
          ) : (
            kinds.map((entry) => (
              <button
                key={entry.kind}
                className={`kind-tile kind-${entry.kind}`}
                onClick={() => props.onOpenKind(entry.kind)}
              >
                <span className="kind-tile-count">{entry.count}</span>
                <span className="kind-tile-label">{KIND_LABEL[entry.kind]}</span>
              </button>
            ))
          )}
        </div>
        <div className="home-libs">
          {libraries.map((library) => (
            <span key={library.id} className={`lib-chip${library.enabled ? '' : ' disabled'}`} title={library.path}>
              <span className="lib-dot" />
              <span className="lib-path">{library.path}</span>
              <span className="lib-count">{library.resourceCount}</span>
            </span>
          ))}
        </div>
      </section>

      <div className="home-stats-line">
        {stats
          ? `共 ${stats.total} 个资源 · ${formatSize(stats.totalSize)} · ${stats.libraries} 个资源库 · ${stats.folderCount} 个目录` +
            (stats.duplicates > 0 ? ` · 重复 ${stats.duplicates}` : '')
          : '正在统计…'}
      </div>
    </div>
  )
}
