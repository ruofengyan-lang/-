import { useEffect, useState } from 'react'
import { formatDuration, formatSize, formatTime } from '@shared/format'
import { KIND_LABEL, KIND_ORDER, isWallpaperExt } from '@shared/resource-kinds'
import type { MediaInfo, MetadataRecord, ResourceDetail, ResourceItem, ResourceKind } from '@shared/types'
import { MATCH_STATUS_LABEL } from '@shared/metadata-labels'
import { displayTitle, shapeOf } from './ResourceCard'

interface Props {
  item: ResourceItem
  detail: ResourceDetail | null
  media: MediaInfo | null
  /** 该文件所属作品的元数据（Phase 3，没有就是 null） */
  workMetadata?: MetadataRecord | null
  /** 已缓存的在线海报绝对路径（Phase 4） */
  workPoster?: string
  onClose: () => void
  onOpen: (item: ResourceItem) => void
  onReveal: (item: ResourceItem) => void
  onCopyPath: (item: ResourceItem) => void
  onSetWallpaper: (item: ResourceItem) => void
  onPreview: (item: ResourceItem) => void
  onRename: (item: ResourceItem) => void
  onToggleFavorite: (item: ResourceItem) => void
  onChangeKind: (item: ResourceItem, kind: ResourceKind | null) => void
  /** 刷新信息：联网抓取该作品元数据（Phase 4） */
  onRefresh?: (item: ResourceItem) => void
  /** 正在抓取 */
  matching?: boolean
}

/**
 * 右侧详情抽屉：
 * 只有选中资源时才出现（默认不占宽度），关闭后主区域恢复全宽。
 */
export default function DetailDrawer(props: Props): React.JSX.Element {
  const { item, detail, media, workMetadata } = props
  const [poster, setPoster] = useState<string | null>(null)
  const [backdrop, setBackdrop] = useState<string | null>(null)

  useEffect(() => {
    let alive = true
    setPoster(null)
    setBackdrop(null)
    /** 顶部背景带只给影视：那类文件本来就有宽幅画面（视频首帧）；
     *  音乐用方形封面本身就是视觉主体，再来一条背景带只会重复。 */
    const wideKinds = ['movie', 'tv', 'anime']
    const thumbable = ['movie', 'tv', 'anime', 'music', 'image', 'wallpaper', 'novel', 'comic', 'document', 'archive']
    const load = async (): Promise<void> => {
      // 有在线海报就直接用（已缓存在本地，断网也能显示）
      if (props.workPoster) {
        if (alive) {
          setPoster(window.toolbox.mediaUrl(props.workPoster))
          if (wideKinds.includes(item.kind)) setBackdrop(window.toolbox.mediaUrl(props.workPoster))
        }
        return
      }
      if (thumbable.includes(item.kind)) {
        // 详情用大图（1024），比卡片图清楚
        const file = await window.toolbox.thumb(item.path, item.mtimeMs, item.kind, 'detail').catch(() => null)
        if (!alive || !file) return
        const url = window.toolbox.mediaUrl(file)
        setPoster(url)
        // 影视/音乐：同一张图兼作详情页顶部背景
        if (wideKinds.includes(item.kind)) setBackdrop(url)
      }
    }
    void load()
    return () => {
      alive = false
    }
  }, [item.path, item.mtimeMs, item.kind, props.workPoster])

  useEffect(() => {
    const onKey = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') props.onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [props])

  const title = displayTitle(item)
  const shape = shapeOf(item.kind)
  // 影视目前只有本地首帧（16:9），用宽幅卡面；等在线海报（2:3）接入后自动变竖版
  const posterShape = item.kind === 'movie' || item.kind === 'tv' || item.kind === 'anime' ? 'wide' : shape
  const originalTitle = item.title && item.title !== item.baseName ? item.title : ''
  const resolution =
    item.width && item.height
      ? `${item.width} × ${item.height}`
      : media?.width && media?.height
        ? `${media.width} × ${media.height}`
        : ''
  const duration = formatDuration(item.durationMs || media?.durationMs || 0) || formatDuration(media?.durationMs ?? 0)
  const bitrate = detail?.bitrate || media?.bitrate || 0
  const fileName = item.name
  const isMedia = ['movie', 'tv', 'anime', 'music'].includes(item.kind)

  const rows: { key: string; value: string }[] = []
  const push = (key: string, value: string): void => {
    if (value) rows.push({ key, value })
  }

  if (item.kind === 'music') {
    push('艺术家', media?.artist || detail?.artist || '')
    push('专辑', media?.album || detail?.album || '')
    push('时长', duration)
    push('格式', item.ext.replace('.', '').toUpperCase())
    push('码率', bitrate > 0 ? `${Math.round(bitrate / 1000)} kbps` : '')
  } else if (isMedia) {
    push('分辨率', resolution)
    push('时长', duration)
    push('格式', item.ext.replace('.', '').toUpperCase())
  } else if (item.kind === 'novel' || item.kind === 'comic') {
    push('作者', media?.artist || detail?.artist || '')
    push('格式', item.ext.replace('.', '').toUpperCase())
  } else if (item.kind === 'image' || item.kind === 'wallpaper') {
    push('分辨率', resolution)
    push('格式', item.ext.replace('.', '').toUpperCase())
  } else if (item.kind === 'archive') {
    const inner = typeof detail?.meta.innerKind === 'string' ? detail.meta.innerKind : media?.innerKind ?? ''
    if (inner === 'video') push('内容判定', '检测到影视资源（压缩包）')
    else if (inner === 'audio') push('内容判定', '检测到音频资源')
    else if (inner === 'image') push('内容判定', '检测到图片资源')
    push('格式', item.ext.replace('.', '').toUpperCase())
  } else {
    push('格式', item.ext.replace('.', '').toUpperCase() || '无扩展名')
  }
  push('本地文件', fileName)
  push('文件大小', formatSize(item.size))
  push('修改时间', formatTime(item.mtimeMs))
  push('加入索引', formatTime(item.addedMs))
  if (detail?.hash) push('SHA-256', `${detail.hash.slice(0, 24)}…`)
  push('文件路径', item.path)

  return (
    <aside className="drawer" onClick={(event) => event.stopPropagation()}>
      <div className="drawer-head">
        <span className={`kind-dot kind-${item.kind}`} />
        <span className="drawer-kind">{KIND_LABEL[item.kind]}</span>
        <span className="grow" />
        <button
          className={`fav-btn${item.isFavorite ? ' on' : ''}`}
          title={item.isFavorite ? '取消收藏' : '加入收藏'}
          onClick={() => props.onToggleFavorite(item)}
        >
          ★
        </button>
        <button className="drawer-close" title="关闭详情（Esc）" onClick={props.onClose}>
          ×
        </button>
      </div>

      {/* Phase 8：影视/音乐用本地大图做顶部背景带（视频首帧 / 专辑封面），没有就不显示 */}
      {backdrop ? <div className="drawer-hero" style={{ backgroundImage: `url("${backdrop}")` }} /> : null}

      <div className="drawer-scroll">
        {/* 影视已经有顶部背景带（同一帧），不再重复显示一块海报；音乐/其它保留方形封面 */}
        {!(backdrop && ['movie', 'tv', 'anime'].includes(item.kind)) ? (
          <div className={`drawer-poster poster-${posterShape}`}>
            {poster ? (
              <img src={poster} alt={title} draggable={false} onDoubleClick={() => props.onPreview(item)} />
            ) : (
              <div className="drawer-poster-empty">
                <span>{item.ext.replace('.', '').toUpperCase() || 'FILE'}</span>
                <small>暂无封面</small>
              </div>
            )}
          </div>
        ) : null}

        <div className="drawer-title">
          <h2 title={title}>{title}</h2>
          {originalTitle ? <div className="drawer-original">{originalTitle}</div> : null}
          <div className="drawer-sub">
            {item.cardLine || KIND_LABEL[item.kind]}
            {detail?.overridden ? ' · 手动分类' : ''}
          </div>
        </div>

        <div className="drawer-actions">
          <button className="btn primary block" onClick={() => props.onOpen(item)}>
            {isMedia ? '▶ 播放' : item.kind === 'comic' ? '▶ 阅读' : '▶ 打开'}
          </button>
          <div className="drawer-actions-row">
            <button className="tool-btn" onClick={() => props.onReveal(item)}>
              打开文件夹
            </button>
            <button className="tool-btn" onClick={() => props.onCopyPath(item)}>
              复制路径
            </button>
            {item.kind === 'image' || item.kind === 'wallpaper' ? (
              <button className="tool-btn" onClick={() => props.onPreview(item)}>
                查看大图
              </button>
            ) : null}
            {isWallpaperExt(item.ext) && (item.kind === 'image' || item.kind === 'wallpaper') ? (
              <button className="tool-btn" onClick={() => props.onSetWallpaper(item)}>
                设为壁纸
              </button>
            ) : null}
            <button className="tool-btn" onClick={() => props.onRename(item)}>
              重命名
            </button>
            <button
              className={`tool-btn${props.matching ? ' busy' : ''}`}
              disabled={props.matching}
              title={
                props.matching
                  ? '正在联网抓取…'
                  : '刷新信息：用已配置的 API 联网抓取这部作品的元数据与海报（需要先在设置里填 TMDB API Key 与代理）'
              }
              onClick={() => props.onRefresh?.(item)}
            >
              <span className={props.matching ? 'spin' : undefined}>⟳</span> {props.matching ? '抓取中…' : '刷新信息'}
            </button>
          </div>
        </div>

        <div className="drawer-section">
          <div className="drawer-section-title">本地信息</div>
          <div className="info-rows">
            {rows.map((row) => (
              <div className="info-row" key={row.key}>
                <span className="info-key">{row.key}</span>
                <span className="info-val" title={row.value}>
                  {row.value}
                </span>
              </div>
            ))}
          </div>
        </div>

        {workMetadata ? (
          <div className="drawer-section">
            <div className="drawer-section-title">作品信息</div>
            <div className="info-rows">
              <div className="info-row">
                <span className="info-key">作品</span>
                <span className="info-val">{workMetadata.title || item.seriesTitle}</span>
              </div>
              {workMetadata.author ? (
                <div className="info-row">
                  <span className="info-key">作者</span>
                  <span className="info-val">{workMetadata.author}</span>
                </div>
              ) : null}
              {workMetadata.originalTitle ? (
                <div className="info-row">
                  <span className="info-key">原名</span>
                  <span className="info-val">{workMetadata.originalTitle}</span>
                </div>
              ) : null}
              {workMetadata.year > 0 ? (
                <div className="info-row">
                  <span className="info-key">年份</span>
                  <span className="info-val">{workMetadata.year}</span>
                </div>
              ) : null}
              <div className="info-row">
                <span className="info-key">元数据</span>
                <span className="info-val">
                  {MATCH_STATUS_LABEL[workMetadata.matchStatus]}
                  {workMetadata.externalSource ? ` · ${workMetadata.externalSource}` : ''}
                </span>
              </div>
            </div>
            {workMetadata.genres.length > 0 ? (
              <div className="genre-tags">
                {workMetadata.genres.map((genre) => (
                  <span className="genre-tag" key={genre}>
                    {genre}
                  </span>
                ))}
              </div>
            ) : null}
          </div>
        ) : null}

        <div className="drawer-section">
          <div className="drawer-section-title">简介</div>
          <div className="drawer-note">
            {workMetadata?.overview
              ? workMetadata.overview
              : media?.innerSummary
                ? media.innerSummary
                : isMedia
                  ? '还没有在线简介。当前版本只使用本地信息（文件名、标签、容器参数）；TMDB / MusicBrainz / AniList / Open Library 的在线匹配会在后续阶段接入，接入后这里显示海报、简介、导演、演员等信息。'
                  : '该类型没有在线简介。'}
          </div>
        </div>

        <div className="drawer-section">
          <div className="drawer-section-title">分类</div>
          <select
            className="tool-btn full"
            value={detail?.overridden ? item.kind : ''}
            onChange={(event) => props.onChangeKind(item, (event.target.value || null) as ResourceKind | null)}
          >
            <option value="">自动识别（{detail ? KIND_LABEL[detail.autoKind] : '—'}）</option>
            {KIND_ORDER.map((kind) => (
              <option key={kind} value={kind}>
                {KIND_LABEL[kind]}
              </option>
            ))}
          </select>
        </div>

        {backdrop ? <div className="drawer-backdrop-note">顶部背景取自本地画面（在线高清背景图后续接入）</div> : null}
      </div>
    </aside>
  )
}
