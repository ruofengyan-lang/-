export interface ToastItem {
  id: number
  type: 'ok' | 'error' | 'info'
  text: string
}

export default function Toasts({ items }: { items: ToastItem[] }): React.JSX.Element {
  return (
    <div className="toasts">
      {items.map((item) => (
        <div key={item.id} className={`toast ${item.type}`}>
          {item.text}
        </div>
      ))}
    </div>
  )
}
