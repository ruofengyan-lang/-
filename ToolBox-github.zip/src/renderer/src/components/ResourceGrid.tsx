import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { formatSize } from '@shared/format'
import type { FolderNode, ResourceItem, SeriesItem } from '@shared/types'
import ResourceCard, { shapeOf } from './ResourceCard'
import SeriesCard from './SeriesCard'
import {
  CARD_META_HEIGHT,
  GRID_GAP_X,
  GRID_GAP_Y,
  GRID_MIN_CARD,
  VIRTUAL_THRESHOLD,
  shapeAspect
} from '../utils'

interface Props {
  items: ResourceItem[]
  folders: FolderNode[]
  /** 作品（系列）视图：漫画墙 */
  series?: SeriesItem[]
  selectedSeriesKey?: string | null
  onSeriesSelect?: (item: SeriesItem) => void
  onSeriesActivate?: (item: SeriesItem) => void
  onSeriesContextMenu?: (event: React.MouseEvent, item: SeriesItem) => void
  selectedPath: string | null
  showKind: boolean
  loading: boolean
  emptyText: string
  total: number
  hasMore: boolean
  onSelect: (item: ResourceItem | null) => void
  onActivate: (item: ResourceItem) => void
  onContextMenu: (event: React.MouseEvent, item: ResourceItem) => void
  onFolderOpen: (folder: FolderNode) => void
  onFolderContextMenu: (event: React.MouseEvent, folder: FolderNode) => void
  onEmptyContextMenu: (event: React.MouseEvent) => void
  onLoadMore: () => void
}

type Row =
  | { kind: 'series'; items: SeriesItem[]; height: number }
  | { kind: 'folder'; items: FolderNode[]; height: number }
  | { kind: 'resource'; items: ResourceItem[]; height: number }

/** 找到真正在滚动的元素：先看自己（.grid-wrap 本身就是 overflow:auto），再往上找 */
function findScroller(element: HTMLElement | null): HTMLElement | null {
  const scrollable = (node: HTMLElement | null): boolean => {
    if (!node) return false
    const style = getComputedStyle(node)
    return /(auto|scroll)/.test(`${style.overflowY}`) && node.scrollHeight > node.clientHeight - 1
  }
  if (scrollable(element)) return element
  let node = element?.parentElement ?? null
  while (node) {
    if (scrollable(node)) return node
    node = node.parentElement
  }
  return null
}

/**
 * Phase 10：真虚拟网格。
 * 只渲染可视区域（外加 overscan 行）的卡片，滚动时按行偏移定位；
 * 列表不超过 VIRTUAL_THRESHOLD 时走原来的整体渲染，观感零变化。
 */
export default function ResourceGrid(props: Props): React.JSX.Element {
  const { items, folders, selectedPath, showKind, loading, emptyText, total, hasMore } = props
  const series = props.series ?? []
  const isEmpty = items.length === 0 && folders.length === 0 && series.length === 0
  const sentinelRef = useRef<HTMLDivElement>(null)
  const loadMoreRef = useRef(props.onLoadMore)
  loadMoreRef.current = props.onLoadMore
  const wrapRef = useRef<HTMLDivElement>(null)

  // 滚到底部附近自动续载（非虚拟模式仍然用这套）
  useEffect(() => {
    if (!hasMore) return
    const element = sentinelRef.current
    if (!element || typeof IntersectionObserver === 'undefined') return
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((entry) => entry.isIntersecting)) loadMoreRef.current()
      },
      { rootMargin: '600px 0px' }
    )
    observer.observe(element)
    return () => observer.disconnect()
  }, [hasMore])

  /* ---------------- 虚拟化 ---------------- */

  const entryCount = items.length + folders.length + series.length
  const virtual = entryCount > VIRTUAL_THRESHOLD
  const [metrics, setMetrics] = useState({ contentWidth: 0, viewportHeight: 0, scrollTop: 0 })

  useLayoutEffect(() => {
    if (!virtual) return
    const wrap = wrapRef.current
    if (!wrap) return
    const scroller = findScroller(wrap)
    const measure = (): void => {
      const style = getComputedStyle(wrap)
      const paddingX = (Number.parseFloat(style.paddingLeft) || 0) + (Number.parseFloat(style.paddingRight) || 0)
      const contentWidth = Math.max(0, wrap.clientWidth - paddingX)
      const viewportHeight = scroller ? scroller.clientHeight : window.innerHeight
      let scrollTop = scroller ? scroller.scrollTop : 0
      if (scroller && scroller !== wrap) {
        // 滚动发生在祖先元素上：换算成网格内部坐标
        const offsetTop = wrap.getBoundingClientRect().top - scroller.getBoundingClientRect().top + scroller.scrollTop
        scrollTop = Math.max(0, scrollTop - offsetTop)
      }
      setMetrics((current) =>
        current.contentWidth === contentWidth &&
        current.viewportHeight === viewportHeight &&
        Math.abs(current.scrollTop - scrollTop) < 1
          ? current
          : { contentWidth, viewportHeight, scrollTop }
      )
    }
    measure()
    const onScroll = (): void => measure()
    scroller?.addEventListener('scroll', onScroll, { passive: true })
    window.addEventListener('resize', onScroll)
    const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(() => measure()) : null
    observer?.observe(wrap)
    if (scroller && scroller !== wrap) observer?.observe(scroller)
    return () => {
      scroller?.removeEventListener('scroll', onScroll)
      window.removeEventListener('resize', onScroll)
      observer?.disconnect()
    }
  }, [virtual])

  /** 卡片文字区高度：从真实卡片量一次（卡片宽高由 CSS 规则直接算，避免测量反馈环） */
  const [metaHeight, setMetaHeight] = useState(CARD_META_HEIGHT)

  useLayoutEffect(() => {
    if (!virtual) return
    const tile = wrapRef.current?.querySelector('.tile') as HTMLElement | null
    if (!tile) return
    const thumb = tile.querySelector('.tile-thumb') as HTMLElement | null
    if (!thumb) return
    const value = Math.max(20, tile.offsetHeight - thumb.offsetHeight)
    if (Math.abs(value - metaHeight) > 1) setMetaHeight(value)
  }, [virtual, metaHeight, items.length, folders.length, series.length])

  /** 复刻 CSS 的 `repeat(auto-fill, minmax(116px, 1fr))`，得到列数与单卡宽度 */
  const columns = useMemo(() => {
    if (!virtual || metrics.contentWidth <= 0) return 1
    return Math.max(1, Math.floor((metrics.contentWidth + GRID_GAP_X) / (GRID_MIN_CARD + GRID_GAP_X)))
  }, [virtual, metrics.contentWidth])

  const cardWidth = useMemo(() => {
    if (columns <= 0 || metrics.contentWidth <= 0) return GRID_MIN_CARD
    return (metrics.contentWidth - (columns - 1) * GRID_GAP_X) / columns
  }, [columns, metrics.contentWidth])

  /** 先把所有条目按列切成行，并算出每行高度（取该行最高的一张卡） */
  const rows = useMemo<Row[]>(() => {
    if (!virtual) return []
    const heightOf = (shape: string): number => Math.round(cardWidth * shapeAspect(shape) + metaHeight)

    const result: Row[] = []
    const chunk = <T,>(list: T[]): T[][] => {
      const out: T[][] = []
      for (let i = 0; i < list.length; i += columns) out.push(list.slice(i, i + columns))
      return out
    }
    for (const group of chunk(series)) {
      result.push({ kind: 'series', items: group, height: Math.max(...group.map((item) => heightOf(shapeOf(item.kind)))) })
    }
    for (const group of chunk(folders)) {
      result.push({ kind: 'folder', items: group, height: heightOf('icon') })
    }
    for (const group of chunk(items)) {
      result.push({ kind: 'resource', items: group, height: Math.max(...group.map((item) => heightOf(shapeOf(item.kind)))) })
    }
    return result
  }, [virtual, columns, cardWidth, metaHeight, series, folders, items])

  const offsets = useMemo(() => {
    const list: number[] = []
    let top = 0
    for (const row of rows) {
      list.push(top)
      top += row.height + GRID_GAP_Y
    }
    return { list, total: Math.max(0, top - GRID_GAP_Y) }
  }, [rows])

  const window_ = useMemo(() => {
    if (!virtual) return { from: 0, to: rows.length }
    const overscan = 300
    let from = 0
    let to = rows.length
    for (let index = 0; index < rows.length; index++) {
      const top = offsets.list[index] ?? 0
      const bottom = top + (rows[index]?.height ?? 0)
      if (bottom < metrics.scrollTop - overscan) {
        from = index + 1
        continue
      }
      if (top > metrics.scrollTop + metrics.viewportHeight + overscan) {
        to = index
        break
      }
    }
    return { from: Math.min(from, Math.max(0, rows.length - 1)), to }
  }, [virtual, rows, offsets, metrics.scrollTop, metrics.viewportHeight])

  const visibleRows = virtual ? rows.slice(window_.from, window_.to) : []

  const renderSeries = (list: SeriesItem[]): React.JSX.Element[] =>
    list.map((item) => (
      <SeriesCard
        key={item.key}
        item={item}
        selected={item.key === props.selectedSeriesKey}
        onSelect={props.onSeriesSelect ?? (() => undefined)}
        onActivate={props.onSeriesActivate ?? (() => undefined)}
        onContextMenu={props.onSeriesContextMenu ?? (() => undefined)}
      />
    ))

  const renderFolder = (folder: FolderNode): React.JSX.Element => (
    <div
      key={`${folder.libraryId}|${folder.relDir}`}
      className="tile card card-icon folder-card"
      title={`${folder.name}\n${folder.fileCount} 个文件${folder.subFolderCount > 0 ? `，${folder.subFolderCount} 个子目录` : ''}`}
      onClick={(event) => {
        event.stopPropagation()
        props.onFolderOpen(folder)
      }}
      onContextMenu={(event) => {
        event.preventDefault()
        event.stopPropagation()
        props.onFolderContextMenu(event, folder)
      }}
    >
      <div className="tile-thumb">
        <span className="folder-glyph">🗀</span>
      </div>
      <div className="tile-meta">
        <div className="tile-label" title={folder.name}>
          {folder.name}
        </div>
        <div className="tile-sub">
          {folder.fileCount} 文件
          {folder.subFolderCount > 0 ? ` · ${folder.subFolderCount} 目录` : ''}
          {folder.totalSize > 0 ? ` · ${formatSize(folder.totalSize)}` : ''}
        </div>
      </div>
    </div>
  )

  const renderResource = (item: ResourceItem): React.JSX.Element => (
    <ResourceCard
      key={item.id}
      item={item}
      selected={item.path === selectedPath}
      showKind={showKind}
      onSelect={props.onSelect}
      onActivate={props.onActivate}
      onContextMenu={props.onContextMenu}
    />
  )

  const renderRow = (row: Row, index: number): React.JSX.Element => (
    <div
      className="grid grid-row"
      key={`row-${window_.from + index}`}
      style={{
        position: 'absolute',
        top: offsets.list[window_.from + index] ?? 0,
        left: 0,
        right: 0,
        gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`,
        gap: `${GRID_GAP_Y}px ${GRID_GAP_X}px`,
        height: row.height
      }}
    >
      {row.kind === 'series' ? renderSeries(row.items) : null}
      {row.kind === 'folder' ? row.items.map(renderFolder) : null}
      {row.kind === 'resource' ? row.items.map(renderResource) : null}
    </div>
  )

  const handleContextMenu = (event: React.MouseEvent): void => {
    if ((event.target as HTMLElement).closest('.tile')) return
    props.onEmptyContextMenu(event)
  }

  return (
    <div
      ref={wrapRef}
      className={`grid-wrap${virtual ? ' virtual' : ''}`}
      onContextMenu={handleContextMenu}
      onClick={(event) => {
        if ((event.target as HTMLElement).closest('.tile')) return
        props.onSelect(null)
      }}
    >
      {isEmpty ? (
        <div className="empty-state">{loading ? '正在读取索引…' : emptyText}</div>
      ) : (
        <>
          {virtual ? (
            <div className="grid-spacer" style={{ height: offsets.total }}>
              {visibleRows.map((row, index) => renderRow(row, index))}
            </div>
          ) : (
            <div className="grid">
              {renderSeries(series)}
              {folders.map(renderFolder)}
              {items.map(renderResource)}
            </div>
          )}
          <div className="grid-foot" ref={sentinelRef}>
            <span>
              {series.length > 0
                ? `${series.length} 部作品`
                : virtual
                  ? `共 ${total} 项 · 虚拟滚动（已渲染 ${visibleRows.reduce((sum, row) => sum + row.items.length, 0)} 个）`
                  : `已显示 ${items.length} / ${total} 项`}
            </span>
            {hasMore && !virtual ? (
              <button className="tool-btn" onClick={props.onLoadMore} disabled={loading}>
                {loading ? '读取中…' : '加载更多'}
              </button>
            ) : null}
          </div>
        </>
      )}
    </div>
  )
}
