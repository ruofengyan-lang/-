import { useEffect, useRef, useState } from 'react'

export interface MenuEntry {
  label?: string
  onClick?: () => void
  danger?: boolean
  checked?: boolean
  separator?: boolean
  /** 未实现的菜单项：置灰并显示提示，不伪造功能 */
  disabled?: boolean
  hint?: string
}

interface Props {
  x: number
  y: number
  items: MenuEntry[]
  onClose: () => void
}

export default function ContextMenu({ x, y, items, onClose }: Props): React.JSX.Element {
  const ref = useRef<HTMLDivElement>(null)
  const [pos, setPos] = useState({ x, y })

  useEffect(() => {
    const element = ref.current
    if (!element) return
    const rect = element.getBoundingClientRect()
    const nextX = Math.max(4, Math.min(x, window.innerWidth - rect.width - 6))
    const nextY = Math.max(4, Math.min(y, window.innerHeight - rect.height - 6))
    setPos({ x: nextX, y: nextY })
  }, [x, y])

  useEffect(() => {
    const close = (): void => onClose()
    const onKey = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') onClose()
    }
    window.addEventListener('mousedown', close)
    window.addEventListener('blur', close)
    window.addEventListener('resize', close)
    window.addEventListener('wheel', close, { passive: true })
    window.addEventListener('keydown', onKey)
    return () => {
      window.removeEventListener('mousedown', close)
      window.removeEventListener('blur', close)
      window.removeEventListener('resize', close)
      window.removeEventListener('wheel', close)
      window.removeEventListener('keydown', onKey)
    }
  }, [onClose])

  return (
    <div
      className="ctx"
      ref={ref}
      style={{ left: pos.x, top: pos.y }}
      onMouseDown={(event) => event.stopPropagation()}
      onContextMenu={(event) => {
        event.preventDefault()
        event.stopPropagation()
      }}
    >
      {items.map((item, index) =>
        item.separator ? (
          <div className="ctx-sep" key={`sep-${index}`} />
        ) : (
          <div
            key={`${item.label}-${index}`}
            className={`ctx-item${item.danger ? ' danger' : ''}${item.checked ? ' checked' : ''}${item.disabled ? ' disabled' : ''}`}
            title={item.disabled ? item.hint ?? '该功能尚未实现' : undefined}
            onClick={() => {
              if (item.disabled) return
              item.onClick?.()
              onClose()
            }}
          >
            {item.label}
            {item.hint ? <span className="ctx-hint">{item.hint}</span> : null}
          </div>
        )
      )}
    </div>
  )
}
