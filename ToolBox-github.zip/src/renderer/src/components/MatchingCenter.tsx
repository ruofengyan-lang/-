import { useCallback, useEffect, useMemo, useState } from 'react'
import { formatSize } from '@shared/format'
import { MATCH_STATUS_HINT, MATCH_STATUS_LABEL } from '@shared/metadata-labels'
import { KIND_LABEL } from '@shared/resource-kinds'
import type {
  BatchProgress,
  MatchingCenterData,
  MetadataRecord,
  MatchStatus,
  ResourceKind,
  StoredCandidate,
  WorkRow
} from '@shared/types'

interface Props {
  onClose: () => void
  onToast: (kind: 'ok' | 'error' | 'info', message: string) => void
  /** 元数据变了，通知外面刷新详情抽屉 */
  onChanged: () => void
}

type StatusFilter = MatchStatus | 'all' | 'unmatched'

const STATUS_FILTERS: { id: StatusFilter; label: string }[] = [
  { id: 'unmatched', label: '未处理' },
  { id: 'pending', label: '待确认' },
  { id: 'failed', label: '失败' },
  { id: 'matched', label: '已匹配' },
  { id: 'confirmed', label: '已确认' },
  { id: 'all', label: '全部作品' }
]

const KIND_FILTERS: { id: ResourceKind | null; label: string }[] = [
  { id: null, label: '全部类型' },
  { id: 'movie', label: '电影' },
  { id: 'tv', label: '电视剧' },
  { id: 'anime', label: '动漫' },
  { id: 'music', label: '音乐' },
  { id: 'novel', label: '小说' },
  { id: 'comic', label: '漫画' }
]

const STATUS_CLASS: Record<MatchStatus, string> = {
  none: 'st-none',
  local: 'st-local',
  pending: 'st-pending',
  matched: 'st-matched',
  failed: 'st-failed',
  confirmed: 'st-confirmed'
}

/**
 * 元数据匹配中心（Phase 9）：
 * 看全部作品的状态、批量匹配、挑候选确认、手动填写、重置回本地信息。
 */
export default function MatchingCenter(props: Props): React.JSX.Element {
  const [data, setData] = useState<MatchingCenterData | null>(null)
  const [status, setStatus] = useState<StatusFilter>('unmatched')
  const [kind, setKind] = useState<ResourceKind | null>(null)
  const [batch, setBatch] = useState<BatchProgress | null>(null)
  const [expanded, setExpanded] = useState<string>('')
  const [candidates, setCandidates] = useState<StoredCandidate[]>([])
  const [editing, setEditing] = useState<string>('')
  const [draft, setDraft] = useState<Partial<MetadataRecord>>({})
  const [busy, setBusy] = useState<string>('')

  const load = useCallback(async (): Promise<void> => {
    const center = await window.toolbox.matchingCenter().catch(() => null)
    if (!center) return
    setData(center)
    if (center.batch) setBatch(center.batch)
  }, [])

  useEffect(() => {
    void load()
    const off = window.toolbox.onMatchingBatch((progress) => {
      setBatch(progress)
      if (!progress.running) void load()
    })
    return off
  }, [load])

  useEffect(() => {
    const onKey = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') props.onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [props])

  const rows = useMemo(() => {
    const all = data?.rows ?? []
    return all.filter((row) => {
      if (kind && row.kind !== kind) return false
      if (status === 'all') return true
      if (status === 'unmatched') return row.matchStatus === 'local' || row.matchStatus === 'none'
      return row.matchStatus === status
    })
  }, [data, kind, status])

  const counts = useMemo(() => {
    const result: Record<string, number> = { all: 0, unmatched: 0, pending: 0, failed: 0, matched: 0, confirmed: 0 }
    for (const row of data?.rows ?? []) {
      result.all++
      if (row.matchStatus === 'local' || row.matchStatus === 'none') result.unmatched++
      result[row.matchStatus] = (result[row.matchStatus] ?? 0) + 1
    }
    return result
  }, [data])

  const runMatch = async (row: WorkRow): Promise<void> => {
    setBusy(row.seriesKey)
    const record = await window.toolbox.metaMatch(row.seriesKey).catch(() => null)
    setBusy('')
    if (!record) {
      props.onToast('error', '匹配失败')
      return
    }
    const { decision } = record
    if (decision.status === 'matched') props.onToast('ok', `《${row.title}》已匹配（${Math.round(decision.confidence * 100)}%）`)
    else if (decision.status === 'pending') props.onToast('info', `《${row.title}》：${decision.reason}`)
    else props.onToast('error', `《${row.title}》：${decision.reason}`)
    await load()
    props.onChanged()
  }

  const openCandidates = async (row: WorkRow): Promise<void> => {
    if (expanded === row.seriesKey) {
      setExpanded('')
      return
    }
    const list = await window.toolbox.matchingCandidates(row.seriesKey).catch(() => [])
    setCandidates(list)
    setExpanded(row.seriesKey)
    setEditing('')
    if (list.length === 0) props.onToast('info', '这部作品还没有候选：先点「匹配」让它去找一次')
  }

  const useCandidate = async (row: WorkRow, candidate: StoredCandidate): Promise<void> => {
    setBusy(row.seriesKey)
    const record = await window.toolbox.matchingConfirm(row.seriesKey, candidate).catch(() => null)
    setBusy('')
    if (!record) {
      props.onToast('error', '确认失败')
      return
    }
    props.onToast('ok', `《${record.title}》已确认（${candidate.source}）`)
    setExpanded('')
    await load()
    props.onChanged()
  }

  const openManual = (row: WorkRow): void => {
    setExpanded('')
    setEditing(row.seriesKey)
    setDraft({
      title: row.title,
      originalTitle: '',
      year: row.year || undefined,
      author: row.author,
      overview: ''
    })
  }

  const saveManual = async (row: WorkRow): Promise<void> => {
    setBusy(row.seriesKey)
    const record = await window.toolbox
      .matchingSaveManual(row.seriesKey, {
        ...draft,
        year: Number(draft.year) || 0,
        title: String(draft.title ?? '').trim() || row.title
      })
      .catch(() => null)
    setBusy('')
    if (!record) {
      props.onToast('error', '保存失败')
      return
    }
    props.onToast('ok', '已保存并标记为「已确认」')
    setEditing('')
    await load()
    props.onChanged()
  }

  /** 候选都不对：标记失败但保留候选，方便以后重看 */
  const rejectAll = async (row: WorkRow): Promise<void> => {
    setBusy(row.seriesKey)
    await window.toolbox.matchingReject(row.seriesKey).catch(() => null)
    setBusy('')
    props.onToast('info', `《${row.title}》：已标记为「候选都不对」，候选已保留`)
    setExpanded('')
    await load()
  }

  const reset = async (row: WorkRow): Promise<void> => {    setBusy(row.seriesKey)
    await window.toolbox.matchingReset(row.seriesKey).catch(() => null)
    setBusy('')
    props.onToast('info', `《${row.title}》已重置为本地信息`)
    await load()
    props.onChanged()
  }

  const startBatch = async (): Promise<void> => {
    const started = await window.toolbox
      .matchingBatchStart({ status: status === 'all' ? 'all' : status === 'unmatched' ? 'local' : status, kind, limit: 200 })
      .catch(() => null)
    if (!started) {
      props.onToast('error', '无法启动批量匹配')
      return
    }
    setBatch(started)
    props.onToast('info', `开始匹配 ${started.total} 部作品…`)
  }

  const cancelBatch = async (): Promise<void> => {
    await window.toolbox.matchingBatchCancel()
    props.onToast('info', '已请求取消，当前这一部跑完就停')
  }

  const progressPercent = batch && batch.total > 0 ? Math.round((batch.done / batch.total) * 100) : 0

  return (
    <div className="modal-mask">
      <div className="modal wide matching-center">
        <div className="modal-title">
          元数据匹配中心
          <span className="grow" />
          <button className="drawer-close" title="关闭（Esc）" onClick={props.onClose}>
            ×
          </button>
        </div>

        <div className="modal-body">
          <div className="mc-filters">
            {STATUS_FILTERS.map((filter) => (
              <button
                key={filter.id}
                className={`mc-chip${status === filter.id ? ' on' : ''}`}
                onClick={() => setStatus(filter.id)}
              >
                {filter.label}
                <span className="mc-chip-count">{counts[filter.id] ?? counts[filter.id === 'unmatched' ? 'unmatched' : filter.id] ?? 0}</span>
              </button>
            ))}
          </div>

          <div className="mc-toolbar">
            <select
              className="btn"
              value={kind ?? ''}
              onChange={(event) => setKind((event.target.value || null) as ResourceKind | null)}
            >
              {KIND_FILTERS.map((item) => (
                <option key={item.label} value={item.id ?? ''}>
                  {item.label}
                </option>
              ))}
            </select>
            <button className="btn primary" disabled={batch?.running || rows.length === 0} onClick={() => void startBatch()}>
              {batch?.running ? '匹配中…' : `匹配当前筛选（${rows.length}）`}
            </button>
            {batch?.running ? (
              <button className="btn" onClick={() => void cancelBatch()}>
                取消
              </button>
            ) : null}
            <button className="btn" onClick={() => void load()}>
              刷新列表
            </button>
            <span className="grow" />
            <span className="field-hint">
              已匹配 {counts.matched ?? 0} · 待确认 {counts.pending ?? 0} · 失败 {counts.failed ?? 0} · 未处理{' '}
              {counts.unmatched ?? 0}
            </span>
          </div>

          {batch && (batch.running || batch.finishedAt > 0) ? (
            <div className="mc-progress">
              <div className="mc-progress-bar">
                <div className="mc-progress-fill" style={{ width: `${progressPercent}%` }} />
              </div>
              <div className="mc-progress-text">
                {batch.running ? '进行中' : batch.cancelled ? '已取消' : '已完成'}：{batch.done}/{batch.total} · 成功{' '}
                {batch.matched} · 待确认 {batch.pending} · 失败 {batch.failed}
                {batch.current ? ` · 当前：${batch.current}` : ''}
                {batch.lastError ? <span className="mc-last-error"> · 最近一条：{batch.lastError}</span> : null}
              </div>
            </div>
          ) : null}

          <div className="mc-list">
            {rows.length === 0 ? (
              <div className="mc-empty">这个筛选下没有作品</div>
            ) : (
              rows.map((row) => (
                <div className="mc-row-wrap" key={row.seriesKey}>
                  <div className="mc-row">
                    <span className={`kind-dot kind-${row.kind}`} />
                    <span className="mc-title" title={row.seriesKey}>
                      {row.title}
                    </span>
                    <span className="mc-kind">{KIND_LABEL[row.kind]}</span>
                    <span className="mc-meta">
                      {row.volumeCount} {row.kind === 'music' ? '首' : '卷'} · {formatSize(row.totalSize)}
                      {row.year > 0 ? ` · ${row.year}` : ''}
                      {row.author ? ` · ${row.author}` : ''}
                    </span>
                    <span className={`mc-status ${STATUS_CLASS[row.matchStatus]}`} title={MATCH_STATUS_HINT[row.matchStatus]}>
                      {MATCH_STATUS_LABEL[row.matchStatus]}
                      {row.externalSource && row.externalSource !== 'local' ? ` · ${row.externalSource}` : ''}
                    </span>
                    <span className="mc-actions">
                      <button
                        className="btn"
                        disabled={busy === row.seriesKey}
                        title="联网匹配一次"
                        onClick={() => void runMatch(row)}
                      >
                        {busy === row.seriesKey ? '…' : '匹配'}
                      </button>
                      <button
                        className="btn"
                        title="查看候选并人工确认"
                        onClick={() => void openCandidates(row)}
                      >
                        候选{row.candidateCount > 0 ? `(${row.candidateCount})` : ''}
                      </button>
                      <button className="btn" title="手动填写信息" onClick={() => openManual(row)}>
                        手动
                      </button>
                      <button
                        className="btn"
                        title="清掉在线元数据，回到本地信息"
                        disabled={row.matchStatus === 'local' || row.matchStatus === 'none'}
                        onClick={() => void reset(row)}
                      >
                        重置
                      </button>
                    </span>
                  </div>

                  {expanded === row.seriesKey ? (
                    <div className="mc-candidates">
                      <div className="mc-candidates-head">
                        <span className="field-hint">
                          下面是这次匹配留下的候选，作者/年份对得上再点「用这个」；一个都不对就点「都不是」。
                        </span>
                        <span className="grow" />
                        <button className="btn" onClick={() => void rejectAll(row)}>
                          都不是
                        </button>
                        <button className="btn" onClick={() => setExpanded('')}>
                          收起
                        </button>
                      </div>
                      {candidates.length === 0 ? (
                        <div className="field-hint">没有候选</div>
                      ) : (
                        candidates.map((candidate) => (
                          <div className="mc-candidate" key={`${candidate.source}:${candidate.id}`}>
                            <span className="mc-candidate-title">{candidate.title}</span>
                            {candidate.originalTitle && candidate.originalTitle !== candidate.title ? (
                              <span className="mc-candidate-sub">{candidate.originalTitle}</span>
                            ) : null}
                            <span className="mc-candidate-sub">
                              {candidate.source}
                              {candidate.year > 0 ? ` · ${candidate.year}` : ''}
                              {candidate.author ? ` · ${candidate.author}` : ''}
                            </span>
                            <span className="grow" />
                            <button className="btn" onClick={() => void useCandidate(row, candidate)}>
                              用这个
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  ) : null}

                  {editing === row.seriesKey ? (
                    <div className="mc-edit">
                      <div className="mc-edit-row">
                        <label>
                          标题
                          <input
                            className="text-input"
                            value={String(draft.title ?? '')}
                            onChange={(event) => setDraft({ ...draft, title: event.target.value })}
                          />
                        </label>
                        <label>
                          原名
                          <input
                            className="text-input"
                            value={String(draft.originalTitle ?? '')}
                            onChange={(event) => setDraft({ ...draft, originalTitle: event.target.value })}
                          />
                        </label>
                        <label className="mc-edit-narrow">
                          年份
                          <input
                            className="text-input"
                            value={String(draft.year ?? '')}
                            onChange={(event) => setDraft({ ...draft, year: Number(event.target.value) || 0 })}
                          />
                        </label>
                        <label>
                          作者 / 艺术家
                          <input
                            className="text-input"
                            value={String(draft.author ?? '')}
                            onChange={(event) => setDraft({ ...draft, author: event.target.value })}
                          />
                        </label>
                      </div>
                      <label className="mc-edit-overview">
                        简介
                        <textarea
                          className="text-input"
                          rows={3}
                          value={String(draft.overview ?? '')}
                          onChange={(event) => setDraft({ ...draft, overview: event.target.value })}
                        />
                      </label>
                      <div className="row-inline">
                        <button className="btn primary" onClick={() => void saveManual(row)}>
                          保存并确认
                        </button>
                        <button className="btn" onClick={() => setEditing('')}>
                          取消
                        </button>
                      </div>
                    </div>
                  ) : null}
                </div>
              ))
            )}
          </div>
        </div>

        <div className="modal-foot">
          <span className="field-hint">
            数据源：TMDB（影视，需要 API Key）· MusicBrainz（音乐，免 Key）· Open Library / AniList（未接入）
          </span>
          <span className="grow" />
          <button className="btn primary" onClick={props.onClose}>
            关闭
          </button>
        </div>
      </div>
    </div>
  )
}
