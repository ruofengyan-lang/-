import { formatSize } from '@shared/format'
import { KIND_ORDER } from '@shared/resource-kinds'
import type { LibraryStats, ResourceKind, ScanProgress, ViewId } from '@shared/types'
import { KIND_LABEL } from '@shared/resource-kinds'

interface Props {
  stats: LibraryStats | null
  view: ViewId
  kind: ResourceKind | null
  libraryCount: number
  showEmpty: boolean
  progress: ScanProgress | null
  onSelectKind: (kind: ResourceKind | null, view: ViewId) => void
  onOpenLibraries: () => void
  onOpenSettings: () => void
  onScan: () => void
}

export default function Sidebar(props: Props): React.JSX.Element {
  const { stats, view, kind, libraryCount, showEmpty, progress } = props
  const countOf = (target: ResourceKind): number =>
    stats?.kinds.find((item) => item.kind === target)?.count ?? 0

  const kindEntries = KIND_ORDER.map((item) => ({ kind: item, count: countOf(item) })).filter(
    (entry) => showEmpty || entry.count > 0
  )

  const item = (
    label: string,
    active: boolean,
    count: number | null,
    onClick: () => void,
    extraClass = ''
  ): React.JSX.Element => (
    <div
      className={`nav-item${active ? ' active' : ''}${extraClass ? ` ${extraClass}` : ''}`}
      title={count === null ? label : `${label}（${count} 项）`}
      onClick={onClick}
    >
      <span className="nav-icon" />
      <span className="nav-name">{label}</span>
      {count !== null ? <span className="nav-count">{count}</span> : null}
    </div>
  )

  return (
    <aside className="sidebar">
      <div className="sidebar-title">
        <span className="title-dot" />
        本地资源中心
      </div>

      <nav className="nav">
        {item('首页', view === 'home', null, () => props.onSelectKind(null, 'home'))}
        {item('全部资源', view === 'all' && kind === null, stats?.total ?? 0, () => props.onSelectKind(null, 'all'))}

        <div className="nav-sep" />
        {kindEntries.map((entry) =>
          item(
            KIND_LABEL[entry.kind],
            view === 'all' && kind === entry.kind,
            entry.count,
            () => props.onSelectKind(entry.kind, 'all'),
            `kind-${entry.kind}`
          )
        )}

        <div className="nav-sep" />
        {item('最近添加', view === 'recent-added', stats?.recentAdded ?? 0, () =>
          props.onSelectKind(null, 'recent-added')
        )}
        {item('最近使用', view === 'recent-used', stats?.recentUsed ?? 0, () =>
          props.onSelectKind(null, 'recent-used')
        )}
        {item('收藏', view === 'favorites', stats?.favorites ?? 0, () => props.onSelectKind(null, 'favorites'))}
        {item('重复资源', view === 'duplicates', stats?.duplicates ?? 0, () =>
          props.onSelectKind(null, 'duplicates')
        )}

        <div className="nav-sep" />
        {item('目录', view === 'folders', stats?.folderCount ?? 0, () => props.onSelectKind(null, 'folders'))}
        {item('资源库', view === 'libraries', libraryCount, props.onOpenLibraries)}
        {item('设置', view === 'settings', null, props.onOpenSettings)}
      </nav>

      <div className="sidebar-foot">
        {progress && (progress.phase === 'scanning' || progress.phase === 'counting' || progress.phase === 'metadata' || progress.phase === 'thumbnails' || progress.phase === 'hashing' || progress.phase === 'paused') ? (
          <div className="scan-strip" title={`${progress.phase} · ${progress.current}`}>
            <div className="scan-line">
              <span>{progress.phase === 'paused' ? '已暂停' : '正在扫描…'}</span>
              <span>
                {progress.total > 0 ? `${progress.scanned} / ${progress.total}` : `${progress.scanned}`}
              </span>
            </div>
            <div className="scan-bar">
              <span
                style={{
                  width: `${progress.total > 0 ? Math.min(100, Math.round((progress.scanned / progress.total) * 100)) : 8}%`
                }}
              />
            </div>
          </div>
        ) : (
          <div className="foot-label">
            资源库 {libraryCount} 个 · {stats ? formatSize(stats.totalSize) : '—'}
          </div>
        )}
        <div className="foot-actions">
          <button className="foot-btn" title="立即重新扫描所有资源库" onClick={props.onScan}>
            ⟳ 扫描
          </button>
          <button className="foot-btn" title="管理资源库目录" onClick={props.onOpenLibraries}>
            ⊕ 资源库
          </button>
          <button className="foot-btn" title="打开设置" onClick={props.onOpenSettings}>
            ⚙ 设置
          </button>
        </div>
      </div>
    </aside>
  )
}
