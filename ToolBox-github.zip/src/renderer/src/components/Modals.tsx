import { useEffect, useState } from 'react'
import { formatDuration, formatSize } from '@shared/format'
import { KIND_LABEL, KIND_ORDER } from '@shared/resource-kinds'
import type { AppConfig, AppInfo, ResourceItem, ResourceKind, WallpaperStyleId } from '@shared/types'
import {
  BACKGROUND_MODE_OPTIONS,
  OVERLAY_OPTIONS,
  WALLPAPER_STYLE_OPTIONS
} from '../utils'

/* ------------------------------ 修改分类 ------------------------------ */

interface KindPickerProps {
  item: ResourceItem
  current: ResourceKind | null
  onPick: (kind: ResourceKind | null) => void
  onClose: () => void
}

export function KindPickerDialog({ item, current, onPick, onClose }: KindPickerProps): React.JSX.Element {
  return (
    <div className="modal-mask">
      <div className="modal">
        <div className="modal-title">修改分类</div>
        <div className="modal-body">
          <div className="field">
            <span className="field-label">资源</span>
            <span className="field-value">{item.name}</span>
          </div>
          <div className="field">
            <span className="field-label">归入哪个分类（手动指定后，扫描不会再覆盖）</span>
            <div className="kind-grid">
              <button className={`kind-btn${current === null ? ' active' : ''}`} onClick={() => onPick(null)}>
                自动识别
              </button>
              {KIND_ORDER.map((kind) => (
                <button
                  key={kind}
                  className={`kind-btn kind-${kind}${current === kind ? ' active' : ''}`}
                  onClick={() => onPick(kind)}
                >
                  {KIND_LABEL[kind]}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="modal-foot">
          <button className="btn" onClick={onClose}>
            取消
          </button>
        </div>
      </div>
    </div>
  )
}

/* ------------------------------ 大图预览 ------------------------------ */

interface PreviewProps {
  item: ResourceItem
  onClose: () => void
  onSetWallpaper: (item: ResourceItem) => void
  onOpen: (item: ResourceItem) => void
}

export function PreviewModal({ item, onClose, onSetWallpaper, onOpen }: PreviewProps): React.JSX.Element {
  const [src, setSrc] = useState<string | null>(null)

  useEffect(() => {
    let alive = true
    window.toolbox
      .thumb(item.path, item.mtimeMs, item.kind)
      .then((file) => {
        if (alive) setSrc(file ? window.toolbox.mediaUrl(file) : window.toolbox.mediaUrl(item.path))
      })
      .catch(() => {
        if (alive) setSrc(window.toolbox.mediaUrl(item.path))
      })
    return () => {
      alive = false
    }
  }, [item.path, item.mtimeMs, item.kind])

  useEffect(() => {
    const onKey = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  return (
    <div className="modal-mask" onMouseDown={onClose}>
      <div className="viewer" onMouseDown={(event) => event.stopPropagation()}>
        {src ? <img src={src} alt={item.name} draggable={false} /> : <div className="viewer-bar">正在生成预览…</div>}
        <div className="viewer-bar">
          <span title={item.path}>
            {item.name} · {KIND_LABEL[item.kind]} · {formatSize(item.size)}
            {item.durationMs > 0 ? ` · ${formatDuration(item.durationMs)}` : ''}
            {item.width && item.height ? ` · ${item.width}×${item.height}` : ''}
          </span>
          <span className="row-inline">
            <button className="btn" onClick={() => onOpen(item)}>
              打开
            </button>
            {item.kind === 'image' || item.kind === 'wallpaper' ? (
              <button className="btn primary" onClick={() => onSetWallpaper(item)}>
                设为桌面壁纸
              </button>
            ) : null}
            <button className="btn" onClick={onClose}>
              关闭
            </button>
          </span>
        </div>
      </div>
    </div>
  )
}

/* ------------------------------ 重命名 ------------------------------ */

interface RenameProps {
  item: ResourceItem
  onCancel: () => void
  onSubmit: (name: string) => void
}

export function RenameDialog({ item, onCancel, onSubmit }: RenameProps): React.JSX.Element {
  const [value, setValue] = useState(item.name)

  return (
    <div className="modal-mask">
      <div className="modal">
        <div className="modal-title">重命名</div>
        <div className="modal-body">
          <div className="field">
            <span className="field-label">当前名称</span>
            <span className="field-value">{item.name}</span>
          </div>
          <div className="field">
            <span className="field-label">新名称（请保留扩展名）</span>
            <input
              type="text"
              autoFocus
              value={value}
              spellCheck={false}
              onChange={(event) => setValue(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === 'Enter') onSubmit(value)
                if (event.key === 'Escape') onCancel()
              }}
            />
          </div>
        </div>
        <div className="modal-foot">
          <button className="btn primary" onClick={() => onSubmit(value)}>
            确定
          </button>
          <button className="btn" onClick={onCancel}>
            取消
          </button>
        </div>
      </div>
    </div>
  )
}

/* ------------------------------ 设置 ------------------------------ */

interface SettingsProps {
  config: AppConfig
  info: AppInfo | null
  onPatch: (patch: Partial<AppConfig>) => void
  onChooseBackground: () => void
  onResetBackground: () => void
  onRevealDataDir: () => void
  /** 写入 TMDB API Key（空值表示不修改；由用户自己填写） */
  onSetKey: (key: string) => Promise<boolean>
  onClearKey: () => Promise<void>
  /** Phase 8：缓存清理后的提示 */
  onCacheCleared: (message: string) => void
  onClose: () => void
}

export function SettingsDialog(props: SettingsProps): React.JSX.Element {
  const { config, info } = props
  /** API Key 只以草稿形式存在于组件内，点保存才写入配置 */
  const [keyDraft, setKeyDraft] = useState('')
  const [saving, setSaving] = useState(false)
  /** Phase 8：缓存统计 */
  const [cache, setCache] = useState<Awaited<ReturnType<typeof window.toolbox.cacheStats>> | null>(null)
  const [clearing, setClearing] = useState(false)
  const patchMetadata = (patch: Partial<AppConfig['metadata']>): void => {
    props.onPatch({ metadata: { ...config.metadata, ...patch } })
  }
  const saveKey = async (): Promise<void> => {
    const value = keyDraft.trim()
    if (!value || saving) return
    setSaving(true)
    const ok = await props.onSetKey(value)
    setSaving(false)
    if (ok) setKeyDraft('')
  }
  const refreshCache = async (): Promise<void> => {
    const stats = await window.toolbox.cacheStats().catch(() => null)
    setCache(stats)
  }
  useEffect(() => {
    void refreshCache()
  }, [])
  const clearCache = async (target: 'thumbs' | 'images'): Promise<void> => {
    const label =
      target === 'thumbs'
        ? '清理缩略图缓存？清理后会在浏览时按需重建（首次滚动会稍慢）。'
        : '清理在线海报/背景图缓存？之后重新匹配会再次下载。'
    if (!window.confirm(label)) return
    setClearing(true)
    await window.toolbox.cacheClear(target).catch(() => null)
    await refreshCache()
    setClearing(false)
    props.onCacheCleared(target === 'thumbs' ? '缩略图缓存已清理' : '在线图片缓存已清理')
  }

  return (
    <div className="modal-mask">
      <div className="modal wide">
        <div className="modal-title">设置</div>
        <div className="modal-body">
          <div className="field">
            <span className="field-label">工具箱背景</span>
            <div className="row-inline">
              <button className="btn" onClick={props.onChooseBackground}>
                更换背景图…
              </button>
              <button className="btn" onClick={props.onResetBackground}>
                恢复默认渐变
              </button>
            </div>
          </div>

          <div className="field">
            <span className="field-label">背景遮罩强度（越大文字越清晰）</span>
            <div className="radio-group">
              {OVERLAY_OPTIONS.map((option) => (
                <label key={option.label}>
                  <input
                    type="radio"
                    name="overlay"
                    checked={Math.abs(config.overlay - option.value) < 0.001}
                    onChange={() => props.onPatch({ overlay: option.value })}
                  />
                  {option.label}
                </label>
              ))}
            </div>
          </div>

          <div className="field">
            <span className="field-label">背景填充方式</span>
            <select
              className="tool-btn light"
              value={config.backgroundMode}
              onChange={(event) => props.onPatch({ backgroundMode: event.target.value as AppConfig['backgroundMode'] })}
            >
              {BACKGROUND_MODE_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <div className="field">
            <span className="field-label">资源卡片大小</span>
            <div className="radio-group">
              {(['compact', 'normal', 'large'] as const).map((size) => (
                <label key={size}>
                  <input
                    type="radio"
                    name="cardSize"
                    checked={config.cardSize === size}
                    onChange={() => props.onPatch({ cardSize: size })}
                  />
                  {size === 'compact' ? '紧凑' : size === 'normal' ? '标准' : '宽松'}
                </label>
              ))}
            </div>
          </div>

          <div className="field">
            <span className="field-label">设置为桌面壁纸时的填充方式</span>
            <select
              className="tool-btn light"
              value={config.wallpaperStyle}
              onChange={(event) => props.onPatch({ wallpaperStyle: event.target.value as WallpaperStyleId })}
            >
              {WALLPAPER_STYLE_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <div className="field">
            <span className="field-label">行为</span>
            <label className="row-inline" style={{ fontSize: 12.5 }}>
              <input
                type="checkbox"
                checked={config.showEmptyCategories}
                onChange={(event) => props.onPatch({ showEmptyCategories: event.target.checked })}
              />
              显示数量为 0 的分类
            </label>
            <label className="row-inline" style={{ fontSize: 12.5 }}>
              <input
                type="checkbox"
                checked={config.showFileExtensions}
                onChange={(event) => props.onPatch({ showFileExtensions: event.target.checked })}
              />
              卡片显示文件扩展名
            </label>
            <label className="row-inline" style={{ fontSize: 12.5 }}>
              <input
                type="checkbox"
                checked={config.confirmExecutables}
                onChange={(event) => props.onPatch({ confirmExecutables: event.target.checked, approvedPrograms: [] })}
              />
              运行 exe / msi / bat / cmd / ps1 前先确认
            </label>
          </div>

          <div className="field">
            <span className="field-label">在线元数据（TMDB 影视）</span>
            <label className="row-inline" style={{ fontSize: 12.5 }}>
              <input
                type="checkbox"
                checked={config.metadata.online}
                onChange={(event) => patchMetadata({ online: event.target.checked })}
              />
              允许联网匹配（关闭时只用本地信息，程序完全离线可用）
            </label>

            <div className="row-inline" style={{ marginTop: 6 }}>
              <span className={`key-state${config.metadata.tmdbKeySet ? ' on' : ''}`}>
                {config.metadata.tmdbKeySet ? 'API Key 已配置' : 'API Key 未配置'}
              </span>
              {config.metadata.tmdbKeySet ? (
                <span className="field-hint">（明文只存在本机 config.json，界面不回显）</span>
              ) : (
                <span className="field-hint">（去 themoviedb.org 免费注册后，把 API Key 填在这里）</span>
              )}
            </div>

            <div className="row-inline" style={{ marginTop: 6 }}>
              <input
                className="text-input"
                style={{ flex: 1 }}
                type="password"
                autoComplete="off"
                placeholder={config.metadata.tmdbKeySet ? '输入新的 API Key 可替换现有配置' : '在此粘贴 TMDB API Key'}
                value={keyDraft}
                onChange={(event) => setKeyDraft(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' && keyDraft.trim()) void saveKey()
                }}
              />
              <button className="btn primary" disabled={!keyDraft.trim()} onClick={() => void saveKey()}>
                保存
              </button>
              {config.metadata.tmdbKeySet ? (
                <button className="btn" onClick={() => void props.onClearKey()}>
                  清除
                </button>
              ) : null}
            </div>

            <div className="row-inline" style={{ marginTop: 6 }}>
              <input
                className="text-input"
                style={{ flex: 1 }}
                placeholder="代理地址，例如 http://127.0.0.1:7890（留空表示直连）"
                defaultValue={config.metadata.proxy}
                onBlur={(event) => patchMetadata({ proxy: event.target.value.trim() })}
              />
            </div>
            <span className="field-hint">
              国内直连 api.themoviedb.org 会连接超时（实测），一般需要填本机代理。
              连通性会在点「在线匹配」时如实反馈，不会假装成功。
            </span>
          </div>

          <div className="field">
            <span className="field-label">缓存占用（缩略图 / 在线图片）</span>
            <span className="field-value">
              {cache
                ? `缩略图 ${cache.thumbnailFiles} 张 · ${cache.thumbnailMB} MB（卡片 ${
                    cache.thumbnailBySize.card?.files ?? 0
                  } / 详情 ${cache.thumbnailBySize.detail?.files ?? 0} / 图标 ${
                    cache.thumbnailBySize.icon?.files ?? 0
                  }）　在线图片 ${cache.imageFiles} 张 · ${cache.imageMB} MB`
                : '正在统计…'}
            </span>
            <div className="row-inline" style={{ marginTop: 6 }}>
              <button className="btn" disabled={clearing} onClick={() => void clearCache('thumbs')}>
                清理缩略图缓存
              </button>
              <button className="btn" disabled={clearing} onClick={() => void clearCache('images')}>
                清理在线图片缓存
              </button>
              <button className="btn" onClick={() => void refreshCache()}>
                重新统计
              </button>
              <button className="btn" onClick={props.onRevealDataDir}>
                打开缓存目录
              </button>
            </div>
            <span className="field-hint">
              缩略图缓存清空后不会立刻重算：浏览到哪张就生成哪张，也可以再点一次「扫描」让后台预热。
            </span>
          </div>

          <div className="field">
            <span className="field-label">索引数据库与缩略图缓存</span>
            <span className="field-value">{info?.dataDir ?? '…'}</span>
            <div className="row-inline" style={{ marginTop: 6 }}>
              <button className="btn" onClick={props.onRevealDataDir}>
                打开所在文件夹
              </button>
            </div>
          </div>

          <div className="field">
            <span className="field-label">关于</span>
            <span className="field-value">
              一站式本地资源管理中心 {info?.version ?? ''}　Electron {info?.electron ?? ''}　Chromium {info?.chrome ?? ''}
              <br />
              Node {info?.node ?? ''}　运行模式：{info?.packaged ? '打包版（绿色便携）' : '开发模式'}　索引资源：
              {info?.resourceCount ?? 0} 个
            </span>
          </div>
        </div>
        <div className="modal-foot">
          <button className="btn primary" onClick={props.onClose}>
            关闭
          </button>
        </div>
      </div>
    </div>
  )
}
