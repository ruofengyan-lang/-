import { useEffect, useRef, useState } from 'react'
import { formatSize, formatTime } from '@shared/format'
import { KIND_LABEL } from '@shared/resource-kinds'
import type { ResourceItem } from '@shared/types'

/** 卡片版式：媒体类走海报，资源类走图标 */
export type CardShape = 'poster' | 'square' | 'photo' | 'wide' | 'icon'

export function shapeOf(kind: ResourceItem['kind']): CardShape {
  switch (kind) {
    // 影视与图书：竖版海报位（有真海报时铺满，没有时把画面完整放在深色卡面里）
    case 'movie':
    case 'tv':
    case 'anime':
    case 'novel':
    case 'comic':
      return 'poster'
    case 'music':
      return 'square'
    case 'image':
    case 'wallpaper':
      return 'photo'
    case 'document':
      return 'wide'
    default:
      return 'icon'
  }
}

/** 媒体类卡片不显示扩展名，显示作品名 */
const MEDIA_KINDS = new Set(['movie', 'tv', 'anime', 'music', 'novel', 'comic'])

export function displayTitle(item: ResourceItem): string {
  if (MEDIA_KINDS.has(item.kind)) return item.title || item.baseName
  return item.name
}

/**
 * 缩略图取用：先问主进程要缩略图缓存文件（视频首帧 / 专辑封面 / 图片缩放 / PDF 首页），
 * 没有缩略图就退回真实文件图标（exe 程序图标等）。
 * 进入视口附近才请求，几千个资源也不会一次性解码。
 */
export function useResourceImage(
  item: ResourceItem | null,
  enabled: boolean
): { src: string | null; isIcon: boolean; loading: boolean } {
  const [src, setSrc] = useState<string | null>(null)
  const [isIcon, setIsIcon] = useState(false)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!item || !enabled) return
    let alive = true
    setSrc(null)
    setIsIcon(false)
    setLoading(true)
    const run = async (): Promise<void> => {
      try {
        const thumbable = ['movie', 'tv', 'anime', 'music', 'image', 'wallpaper', 'novel', 'comic', 'document', 'archive']
        if (thumbable.includes(item.kind)) {
          const file = await window.toolbox.thumb(item.path, item.mtimeMs, item.kind).catch(() => null)
          if (!alive) return
          if (file) {
            setSrc(window.toolbox.mediaUrl(file))
            return
          }
        }
        const icon = await window.toolbox.icon(item.path, item.mtimeMs).catch(() => null)
        if (!alive) return
        if (icon) {
          setSrc(icon)
          setIsIcon(true)
        }
      } finally {
        if (alive) setLoading(false)
      }
    }
    void run()
    return () => {
      alive = false
    }
  }, [item?.path, item?.mtimeMs, item?.kind, enabled])

  return { src, isIcon, loading }
}

interface Props {
  item: ResourceItem
  selected: boolean
  showKind: boolean
  onSelect: (item: ResourceItem) => void
  onActivate: (item: ResourceItem) => void
  onContextMenu: (event: React.MouseEvent, item: ResourceItem) => void
}

export default function ResourceCard({
  item,
  selected,
  showKind,
  onSelect,
  onActivate,
  onContextMenu
}: Props): React.JSX.Element {
  const cardRef = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(false)
  const shape = shapeOf(item.kind)
  const title = displayTitle(item)

  useEffect(() => {
    const element = cardRef.current
    if (!element) return
    if (typeof IntersectionObserver === 'undefined') {
      setVisible(true)
      return
    }
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((entry) => entry.isIntersecting)) {
          setVisible(true)
          observer.disconnect()
        }
      },
      { rootMargin: '800px 0px' }
    )
    observer.observe(element)
    return () => observer.disconnect()
  }, [])

  const { src, isIcon } = useResourceImage(item, visible)

  const tip = [
    title,
    item.name !== title ? `文件：${item.name}` : '',
    `类型：${KIND_LABEL[item.kind]}`,
    `大小：${formatSize(item.size)}`,
    `修改时间：${formatTime(item.mtimeMs)}`,
    `位置：${item.path}`
  ]
    .filter(Boolean)
    .join('\n')

  return (
    <div
      ref={cardRef}
      className={`tile card card-${shape}${selected ? ' selected' : ''}`}
      title={tip}
      onClick={(event) => {
        event.stopPropagation()
        onSelect(item)
      }}
      onDoubleClick={(event) => {
        event.stopPropagation()
        onActivate(item)
      }}
      onContextMenu={(event) => onContextMenu(event, item)}
    >
      <div className="tile-thumb">
        {src ? (
          <img src={src} alt="" draggable={false} className={isIcon ? 'as-icon' : undefined} />
        ) : (
          <span className="thumb-placeholder">{item.ext.replace('.', '').slice(0, 4).toUpperCase() || '—'}</span>
        )}
        {item.isFavorite ? (
          <span className="tile-fav" title="已收藏">
            ★
          </span>
        ) : null}
        {showKind ? <span className="tile-kind">{KIND_LABEL[item.kind]}</span> : null}
      </div>
      <div className="tile-meta">
        <div className="tile-label" title={title}>
          {title}
        </div>
        {item.cardLine ? (
          <div className="tile-sub" title={item.cardLine}>
            {item.cardLine}
          </div>
        ) : null}
      </div>
    </div>
  )
}
