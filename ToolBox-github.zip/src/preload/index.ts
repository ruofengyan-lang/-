import { contextBridge, ipcRenderer } from 'electron'
import type {
  AppConfig,
  BatchProgress,
  Library,
  MatchStatus,
  MediaInfo,
  MetadataRecord,
  ResourceDetail,
  ResourceKind,
  ResourcePage,
  ResourceQuery,
  StoredCandidate,
  ToastPayload,
  ToolboxApi
} from '@shared/types'

/**
 * 渲染进程唯一的对外通道。
 * contextIsolation + sandbox，页面里没有 require / process / fs，
 * 所有文件系统与系统操作都由主进程校验后执行。
 */
const MEDIA_PREFIX = 'toolbox-media://local/?p='

const api: ToolboxApi = {
  info: () => ipcRenderer.invoke('app:info'),
  getConfig: () => ipcRenderer.invoke('config:get'),
  setConfig: (patch: Partial<AppConfig>) => ipcRenderer.invoke('config:set', patch),

  libraries: () => ipcRenderer.invoke('library:list'),
  addLibrary: () => ipcRenderer.invoke('library:add'),
  removeLibrary: (id: number) => ipcRenderer.invoke('library:remove', id),
  setLibraryEnabled: (id: number, enabled: boolean) => ipcRenderer.invoke('library:setEnabled', id, enabled),

  scan: (startLibraryId?: number) => ipcRenderer.invoke('scan:start', startLibraryId),
  pauseScan: () => ipcRenderer.invoke('scan:pause'),
  resumeScan: () => ipcRenderer.invoke('scan:resume'),
  cancelScan: () => ipcRenderer.invoke('scan:cancel'),
  scanStatus: () => ipcRenderer.invoke('scan:status'),

  stats: () => ipcRenderer.invoke('res:stats'),
  list: (query: ResourceQuery) => ipcRenderer.invoke('res:list', query),
  detail: (id: number) => ipcRenderer.invoke('res:detail', id),
  toggleFavorite: (id: number) => ipcRenderer.invoke('res:favorite', id),
  setKind: (id: number, kind: ResourceKind | null) => ipcRenderer.invoke('res:setKind', id, kind),
  folders: (libraryId: number, relDir: string) => ipcRenderer.invoke('res:folders', libraryId, relDir),
  folderResources: (libraryId: number, relDir: string) =>
    ipcRenderer.invoke('res:folderResources', libraryId, relDir),
  topFolders: () => ipcRenderer.invoke('res:topFolders'),
  series: (kind: ResourceKind, libraryId?: number | null) => ipcRenderer.invoke('res:series', kind, libraryId),
  seriesDetail: (key: string) => ipcRenderer.invoke('res:seriesDetail', key),

  /* ---- Phase 3：作品元数据 ---- */
  metaGet: (seriesKey: string) => ipcRenderer.invoke('meta:get', seriesKey),
  metaOverview: () => ipcRenderer.invoke('meta:overview'),
  metaList: (status?: MatchStatus) => ipcRenderer.invoke('meta:list', status),
  metaPoster: (seriesKey: string) => ipcRenderer.invoke('meta:poster', seriesKey),
  metaSetKey: (key: string) => ipcRenderer.invoke('meta:setKey', key),
  metaClearKey: () => ipcRenderer.invoke('meta:clearKey'),

  /* ---- Phase 9：元数据匹配中心 ---- */
  matchingCenter: () => ipcRenderer.invoke('matching:center'),
  matchingCandidates: (seriesKey: string) => ipcRenderer.invoke('matching:candidates', seriesKey),
  matchingConfirm: (seriesKey: string, candidate: StoredCandidate) =>
    ipcRenderer.invoke('matching:confirm', seriesKey, candidate),
  matchingSaveManual: (seriesKey: string, patch: Partial<MetadataRecord>) =>
    ipcRenderer.invoke('matching:manual', seriesKey, patch),
  matchingReset: (seriesKey: string) => ipcRenderer.invoke('matching:reset', seriesKey),
  matchingReject: (seriesKey: string) => ipcRenderer.invoke('matching:reject', seriesKey),
  matchingBatchStart: (options: { status: MatchStatus | 'all'; kind: ResourceKind | null; limit: number }) =>
    ipcRenderer.invoke('matching:batchStart', options),
  matchingBatchCancel: () => ipcRenderer.invoke('matching:batchCancel'),
  onMatchingBatch: (callback: (progress: BatchProgress) => void) => {
    const listener = (_event: unknown, progress: BatchProgress): void => callback(progress)
    ipcRenderer.on('matching:batch', listener)
    return () => {
      ipcRenderer.removeListener('matching:batch', listener)
    }
  },
  metaMatch: (seriesKey: string) => ipcRenderer.invoke('meta:match', seriesKey),
  metaSave: (seriesKey: string, patch: Partial<MetadataRecord>) =>
    ipcRenderer.invoke('meta:save', seriesKey, patch),

  thumb: (filePath: string, mtimeMs: number, kind: ResourceKind, size?: 'card' | 'detail' | 'icon') =>
    ipcRenderer.invoke('thumb:get', filePath, mtimeMs, kind, size),
  icon: (filePath: string, mtimeMs: number) => ipcRenderer.invoke('thumb:icon', filePath, mtimeMs),

  /* ---- Phase 8：缓存管理 ---- */
  cacheStats: () => ipcRenderer.invoke('cache:stats'),
  cacheClear: (target: 'thumbs' | 'images') => ipcRenderer.invoke('cache:clear', target),
  media: (filePath: string, kind: ResourceKind) => ipcRenderer.invoke('media:info', filePath, kind),

  open: (idOrPath: number | string) => ipcRenderer.invoke('action:open', idOrPath),
  reveal: (filePath: string) => ipcRenderer.invoke('action:reveal', filePath),
  copyPath: (filePath: string) => ipcRenderer.invoke('action:copyPath', filePath),
  rename: (filePath: string, newName: string) => ipcRenderer.invoke('action:rename', filePath, newName),
  remove: (filePath: string, permanent: boolean) => ipcRenderer.invoke('action:remove', filePath, permanent),

  setWallpaper: (filePath: string, style) => ipcRenderer.invoke('wallpaper:set', filePath, style),
  setWallpaperFromData: (dataUrl: string, style) => ipcRenderer.invoke('wallpaper:setData', dataUrl, style),

  chooseBackground: () => ipcRenderer.invoke('background:choose'),
  resetBackground: () => ipcRenderer.invoke('background:reset'),

  mediaUrl: (filePath: string) => `${MEDIA_PREFIX}${encodeURIComponent(filePath)}`,

  onConfigChanged: (cb: (config: AppConfig) => void) => {
    const listener = (_event: unknown, config: AppConfig): void => cb(config)
    ipcRenderer.on('config:changed', listener)
    return () => {
      ipcRenderer.removeListener('config:changed', listener)
    }
  },
  onToast: (cb: (payload: ToastPayload) => void) => {
    const listener = (_event: unknown, payload: ToastPayload): void => cb(payload)
    ipcRenderer.on('toast', listener)
    return () => {
      ipcRenderer.removeListener('toast', listener)
    }
  },
  onScanProgress: (cb) => {
    const listener = (_event: unknown, progress: Parameters<typeof cb>[0]): void => cb(progress)
    ipcRenderer.on('scan:progress', listener)
    return () => {
      ipcRenderer.removeListener('scan:progress', listener)
    }
  },
  onIndexChanged: (cb: () => void) => {
    const listener = (): void => cb()
    ipcRenderer.on('index:changed', listener)
    return () => {
      ipcRenderer.removeListener('index:changed', listener)
    }
  }
}

void ((_library: Library) => _library)
void ((_detail: ResourceDetail) => _detail)
void ((_page: ResourcePage) => _page)
void ((_media: MediaInfo) => _media)

contextBridge.exposeInMainWorld('toolbox', api)
