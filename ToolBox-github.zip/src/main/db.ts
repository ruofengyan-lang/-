import { DatabaseSync, type StatementSync } from 'node:sqlite'
import fs from 'node:fs'
import path from 'node:path'
import { naturalKey } from '@shared/format'
import type {
  FolderNode,
  KindCount,
  Library,
  LibraryStats,
  ResourceDetail,
  ResourceItem,
  ResourceKind,
  ResourcePage,
  ResourceQuery,
  SeriesItem
} from '@shared/types'
import type { MatchStatus, MetadataRecord } from './metadata/types'

/** 数据库里的原始行 */
interface Row {
  id: number
  path: string
  norm: string
  library_id: number
  rel_dir: string
  name: string
  base_name: string
  ext: string
  kind: string
  auto_kind: string
  overridden: number
  size: number
  mtime: number
  ctime: number
  first_seen: number
  hash: string
  hash_state: number
  width: number
  height: number
  duration_ms: number
  bitrate: number
  title: string
  artist: string
  album: string
  year: number
  card_line: string
  thumb_key: string
  meta_json: string
  is_favorite: number
  open_count: number
  last_opened: number
  series_key: string
  series_title: string
  volume: number
}

const RESOURCE_COLUMNS = `id, path, norm, library_id, rel_dir, name, base_name, ext, kind, auto_kind,
  overridden, size, mtime, ctime, first_seen, hash, hash_state, width, height, duration_ms, bitrate,
  title, artist, album, year, card_line, thumb_key, meta_json, is_favorite, open_count, last_opened,
  series_key, series_title, volume`

/** 与 libraries 表 JOIN 时必须带 r. 前缀，否则 id 列有歧义 */
const RESOURCE_COLUMNS_JOINED = RESOURCE_COLUMNS.split(',')
  .map((column) => `r.${column.trim()}`)
  .join(', ')
  .replace(/\s+/g, ' ')

const RECENT_ADDED_DAYS = 30

/**
 * 元数据 / 分类判定规则版本。
 * 升级这个数字会让所有资源的 meta_state 归零，下次扫描按新规则重新判定
 * （v2：EPUB 图集归为漫画；v3：修正被旧行为写坏的 kind；v4：小说/影视也归属到作品实体；
 *   v5：作品名去掉书名号与"作者：xxx"后缀；v6：音乐按专辑归组）
 */
const META_PIPELINE_VERSION = 6

export interface UpsertInput {
  path: string
  libraryId: number
  relDir: string
  name: string
  ext: string
  kind: ResourceKind
  autoKind: ResourceKind
  size: number
  mtime: number
  ctime: number
  scanToken: number
  seriesKey?: string
  seriesTitle?: string
  volume?: number
}

let db: DatabaseSync | null = null
let stmts: Record<string, StatementSync> = {}

export function initDatabase(dataDir: string): void {
  fs.mkdirSync(dataDir, { recursive: true })
  const file = path.join(dataDir, 'index.db')
  db = new DatabaseSync(file)
  db.exec('PRAGMA journal_mode = WAL')
  db.exec('PRAGMA synchronous = NORMAL')
  db.exec('PRAGMA foreign_keys = OFF')
  db.exec(`
    CREATE TABLE IF NOT EXISTS libraries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      path TEXT NOT NULL,
      norm TEXT NOT NULL UNIQUE,
      label TEXT NOT NULL DEFAULT '',
      enabled INTEGER NOT NULL DEFAULT 1,
      max_depth INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL,
      last_scanned INTEGER NOT NULL DEFAULT 0,
      scan_token INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS resources (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      path TEXT NOT NULL,
      norm TEXT NOT NULL UNIQUE,
      library_id INTEGER NOT NULL,
      rel_dir TEXT NOT NULL DEFAULT '',
      name TEXT NOT NULL,
      sort_name TEXT NOT NULL,
      base_name TEXT NOT NULL,
      ext TEXT NOT NULL,
      kind TEXT NOT NULL,
      auto_kind TEXT NOT NULL,
      overridden INTEGER NOT NULL DEFAULT 0,
      size INTEGER NOT NULL DEFAULT 0,
      mtime INTEGER NOT NULL DEFAULT 0,
      ctime INTEGER NOT NULL DEFAULT 0,
      first_seen INTEGER NOT NULL,
      last_scan_token INTEGER NOT NULL DEFAULT 0,
      hash TEXT NOT NULL DEFAULT '',
      hash_state INTEGER NOT NULL DEFAULT 0,
      width INTEGER NOT NULL DEFAULT 0,
      height INTEGER NOT NULL DEFAULT 0,
      duration_ms INTEGER NOT NULL DEFAULT 0,
      bitrate INTEGER NOT NULL DEFAULT 0,
      title TEXT NOT NULL DEFAULT '',
      artist TEXT NOT NULL DEFAULT '',
      album TEXT NOT NULL DEFAULT '',
      year INTEGER NOT NULL DEFAULT 0,
      card_line TEXT NOT NULL DEFAULT '',
      thumb_key TEXT NOT NULL DEFAULT '',
      thumb_state INTEGER NOT NULL DEFAULT 0,
      meta_state INTEGER NOT NULL DEFAULT 0,
      meta_json TEXT NOT NULL DEFAULT '',
      is_favorite INTEGER NOT NULL DEFAULT 0,
      open_count INTEGER NOT NULL DEFAULT 0,
      last_opened INTEGER NOT NULL DEFAULT 0,
      series_key TEXT NOT NULL DEFAULT '',
      series_title TEXT NOT NULL DEFAULT '',
      volume INTEGER NOT NULL DEFAULT 0
    );

    CREATE INDEX IF NOT EXISTS idx_res_kind ON resources(kind);
    CREATE INDEX IF NOT EXISTS idx_res_lib ON resources(library_id);
    CREATE INDEX IF NOT EXISTS idx_res_sort ON resources(sort_name);
    CREATE INDEX IF NOT EXISTS idx_res_mtime ON resources(mtime);
    CREATE INDEX IF NOT EXISTS idx_res_added ON resources(first_seen);
    CREATE INDEX IF NOT EXISTS idx_res_size ON resources(size);
    CREATE INDEX IF NOT EXISTS idx_res_fav ON resources(is_favorite);
    CREATE INDEX IF NOT EXISTS idx_res_hash ON resources(hash);
    CREATE INDEX IF NOT EXISTS idx_res_folder ON resources(library_id, rel_dir);
    /* Phase 10：按执行计划补的复合索引
       - 分类列表（最常见）：原来只有 idx_res_kind，排序要临时 B 树
       - 最近使用：原来直接全表扫 */
    CREATE INDEX IF NOT EXISTS idx_res_kind_sort ON resources(kind, sort_name);
    CREATE INDEX IF NOT EXISTS idx_res_opened ON resources(open_count, last_opened);

    CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT NOT NULL);

    /* Phase 3：作品（系列）级元数据。一行 = 一部作品，与本地文件（resources）分离。
       Provider（TMDB / MusicBrainz / Open Library / AniList）的匹配结果都写这里。 */
    CREATE TABLE IF NOT EXISTS metadata (
      series_key TEXT PRIMARY KEY,
      kind TEXT NOT NULL,
      title TEXT NOT NULL DEFAULT '',
      original_title TEXT NOT NULL DEFAULT '',
      year INTEGER NOT NULL DEFAULT 0,
      overview TEXT NOT NULL DEFAULT '',
      genres TEXT NOT NULL DEFAULT '[]',
      author TEXT NOT NULL DEFAULT '',
      studio TEXT NOT NULL DEFAULT '',
      country TEXT NOT NULL DEFAULT '',
      language TEXT NOT NULL DEFAULT '',
      rating REAL NOT NULL DEFAULT 0,
      external_source TEXT NOT NULL DEFAULT '',
      external_id TEXT NOT NULL DEFAULT '',
      match_status TEXT NOT NULL DEFAULT 'none',
      match_confidence REAL NOT NULL DEFAULT 0,
      poster_path TEXT NOT NULL DEFAULT '',
      backdrop_path TEXT NOT NULL DEFAULT '',
      cover_path TEXT NOT NULL DEFAULT '',
      extra_json TEXT NOT NULL DEFAULT '{}',
      updated_at INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_meta_status ON metadata(match_status);
    CREATE INDEX IF NOT EXISTS idx_meta_source ON metadata(external_source);
  `)

  // 老库升级：补齐 Phase 2 新增的列（SQLite 支持 ADD COLUMN，不动已有数据）
  const existingColumns = (db.prepare(`PRAGMA table_info(resources)`).all() as unknown as { name: string }[]).map(
    (row) => row.name
  )
  const missing: [string, string][] = [
    ['series_key', `TEXT NOT NULL DEFAULT ''`],
    ['series_title', `TEXT NOT NULL DEFAULT ''`],
    ['volume', `INTEGER NOT NULL DEFAULT 0`]
  ].filter(([name]) => !existingColumns.includes(name)) as [string, string][]
  for (const [name, type] of missing) {
    db.exec(`ALTER TABLE resources ADD COLUMN ${name} ${type}`)
  }
  // 索引必须在补列之后建（老库上直接建这个索引会报 no such column）
  db.exec(`CREATE INDEX IF NOT EXISTS idx_res_series ON resources(series_key)`)

  // Phase 10：老库补建新索引（IF NOT EXISTS，安全）
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_res_kind_sort ON resources(kind, sort_name);
    CREATE INDEX IF NOT EXISTS idx_res_opened ON resources(open_count, last_opened);
  `)

  // 判定规则升级：旧记录重新走一遍元数据/分类判定
  const storedMetaVersion = (db.prepare(`SELECT v FROM kv WHERE k = 'metaVersion'`).get() as unknown as
    | { v: string }
    | undefined)?.v
  if (storedMetaVersion !== String(META_PIPELINE_VERSION)) {
    db.exec(`UPDATE resources SET meta_state = 0`)
    db.prepare(`INSERT INTO kv (k, v) VALUES ('metaVersion', ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v`).run(
      String(META_PIPELINE_VERSION)
    )
  }

  stmts = {
    insertLib: db.prepare(
      `INSERT INTO libraries (path, norm, label, enabled, max_depth, created_at) VALUES (?, ?, ?, 1, 0, ?)`
    ),
    allLibs: db.prepare(
      `SELECT l.*, (SELECT COUNT(*) FROM resources r WHERE r.library_id = l.id) AS resource_count
       FROM libraries l ORDER BY l.id ASC`
    ),
    libById: db.prepare(`SELECT * FROM libraries WHERE id = ?`),
    libByNorm: db.prepare(`SELECT * FROM libraries WHERE norm = ?`),
    deleteLib: db.prepare(`DELETE FROM libraries WHERE id = ?`),
    deleteLibResources: db.prepare(`DELETE FROM resources WHERE library_id = ?`),
    setLibEnabled: db.prepare(`UPDATE libraries SET enabled = ? WHERE id = ?`),
    setLibLabel: db.prepare(`UPDATE libraries SET label = ? WHERE id = ?`),
    setLibScanned: db.prepare(`UPDATE libraries SET last_scanned = ?, scan_token = ? WHERE id = ?`),
    bumpToken: db.prepare(`UPDATE libraries SET scan_token = scan_token + 1 WHERE id = ?`),
    deleteMissing: db.prepare(`DELETE FROM resources WHERE library_id = ? AND last_scan_token <> ?`),

    upsert: db.prepare(`
      INSERT INTO resources (path, norm, library_id, rel_dir, name, sort_name, base_name, ext, kind, auto_kind,
        size, mtime, ctime, first_seen, last_scan_token, series_key, series_title, volume)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(norm) DO UPDATE SET
        path = excluded.path,
        library_id = excluded.library_id,
        rel_dir = excluded.rel_dir,
        name = excluded.name,
        sort_name = excluded.sort_name,
        base_name = excluded.base_name,
        ext = excluded.ext,
        size = excluded.size,
        mtime = excluded.mtime,
        ctime = excluded.ctime,
        last_scan_token = excluded.last_scan_token,
        /* 文件没变、且已经判定过（meta_state=1）时，保留判定结果。
           因为 kind 可能来自内容分析（例如图集式 EPUB 判为漫画、图片型 ZIP 判为漫画），
           不能被扫描阶段的扩展名猜测覆盖掉；文件变动时 meta_state 会归零并重新判定。 */
        series_key = CASE
          WHEN resources.mtime = excluded.mtime AND resources.size = excluded.size AND resources.meta_state = 1
            THEN resources.series_key ELSE excluded.series_key END,
        series_title = CASE
          WHEN resources.mtime = excluded.mtime AND resources.size = excluded.size AND resources.meta_state = 1
            THEN resources.series_title ELSE excluded.series_title END,
        volume = CASE
          WHEN resources.mtime = excluded.mtime AND resources.size = excluded.size AND resources.meta_state = 1
            THEN resources.volume ELSE excluded.volume END,
        kind = CASE
          WHEN resources.overridden = 1 THEN resources.kind
          WHEN resources.mtime = excluded.mtime AND resources.size = excluded.size AND resources.meta_state = 1
            THEN resources.kind
          ELSE excluded.kind END,
        auto_kind = CASE
          WHEN resources.mtime = excluded.mtime AND resources.size = excluded.size AND resources.meta_state = 1
            THEN resources.auto_kind ELSE excluded.auto_kind END,
        thumb_key = CASE WHEN resources.mtime = excluded.mtime AND resources.size = excluded.size
                         THEN resources.thumb_key ELSE '' END,
        thumb_state = CASE WHEN resources.mtime = excluded.mtime AND resources.size = excluded.size
                           THEN resources.thumb_state ELSE 0 END,
        meta_state = CASE WHEN resources.mtime = excluded.mtime AND resources.size = excluded.size
                          THEN resources.meta_state ELSE 0 END,
        hash = CASE WHEN resources.mtime = excluded.mtime AND resources.size = excluded.size
                    THEN resources.hash ELSE '' END,
        hash_state = CASE WHEN resources.mtime = excluded.mtime AND resources.size = excluded.size
                          THEN resources.hash_state ELSE 0 END
    `),
    byNorm: db.prepare(`SELECT ${RESOURCE_COLUMNS} FROM resources WHERE norm = ?`),
    byId: db.prepare(`SELECT ${RESOURCE_COLUMNS} FROM resources WHERE id = ?`),
    setMeta: db.prepare(`
      UPDATE resources SET width = ?, height = ?, duration_ms = ?, bitrate = ?, title = ?, artist = ?,
        album = ?, year = ?, card_line = ?, meta_json = ? WHERE id = ?
    `),
    setThumb: db.prepare(`UPDATE resources SET thumb_key = ?, thumb_state = ? WHERE id = ?`),
    setHash: db.prepare(`UPDATE resources SET hash = ?, hash_state = ? WHERE id = ?`),
    setMetaState: db.prepare(`UPDATE resources SET meta_state = ? WHERE id = ?`),
    setKind: db.prepare(`UPDATE resources SET kind = ?, overridden = ?, card_line = ? WHERE id = ?`),
    /** 内容判定得出的类型（非用户手动）：同时刷新 auto_kind，让"自动识别"如实反映结果 */
    setAutoKind: db.prepare(`UPDATE resources SET kind = ?, auto_kind = ?, card_line = ? WHERE id = ?`),

    /* ---------- 元数据（作品级） ---------- */
    metaUpsert: db.prepare(`
      INSERT INTO metadata (series_key, kind, title, original_title, year, overview, genres, author, studio,
        country, language, rating, external_source, external_id, match_status, match_confidence,
        poster_path, backdrop_path, cover_path, extra_json, updated_at, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(series_key) DO UPDATE SET
        kind = excluded.kind,
        title = CASE WHEN excluded.title <> '' THEN excluded.title ELSE metadata.title END,
        original_title = CASE WHEN excluded.original_title <> '' THEN excluded.original_title ELSE metadata.original_title END,
        year = CASE WHEN excluded.year > 0 THEN excluded.year ELSE metadata.year END,
        overview = CASE WHEN excluded.overview <> '' THEN excluded.overview ELSE metadata.overview END,
        genres = CASE WHEN excluded.genres <> '[]' THEN excluded.genres ELSE metadata.genres END,
        author = CASE WHEN excluded.author <> '' THEN excluded.author ELSE metadata.author END,
        studio = CASE WHEN excluded.studio <> '' THEN excluded.studio ELSE metadata.studio END,
        country = CASE WHEN excluded.country <> '' THEN excluded.country ELSE metadata.country END,
        language = CASE WHEN excluded.language <> '' THEN excluded.language ELSE metadata.language END,
        rating = CASE WHEN excluded.rating > 0 THEN excluded.rating ELSE metadata.rating END,
        external_source = CASE WHEN excluded.external_source <> '' THEN excluded.external_source ELSE metadata.external_source END,
        external_id = CASE WHEN excluded.external_id <> '' THEN excluded.external_id ELSE metadata.external_id END,
        match_status = excluded.match_status,
        match_confidence = excluded.match_confidence,
        poster_path = CASE WHEN excluded.poster_path <> '' THEN excluded.poster_path ELSE metadata.poster_path END,
        backdrop_path = CASE WHEN excluded.backdrop_path <> '' THEN excluded.backdrop_path ELSE metadata.backdrop_path END,
        cover_path = CASE WHEN excluded.cover_path <> '' THEN excluded.cover_path ELSE metadata.cover_path END,
        extra_json = CASE WHEN excluded.extra_json <> '{}' THEN excluded.extra_json ELSE metadata.extra_json END,
        updated_at = excluded.updated_at
    `),
    metaByKey: db.prepare(`SELECT * FROM metadata WHERE series_key = ?`),
    metaAll: db.prepare(`SELECT * FROM metadata ORDER BY updated_at DESC`),
    metaByStatus: db.prepare(`SELECT * FROM metadata WHERE match_status = ? ORDER BY updated_at DESC`),
    metaDelete: db.prepare(`DELETE FROM metadata WHERE series_key = ?`),
    metaStats: db.prepare(`SELECT match_status AS status, COUNT(*) AS count FROM metadata GROUP BY match_status`),
    metaStatsSource: db.prepare(
      `SELECT external_source AS source, COUNT(*) AS count FROM metadata GROUP BY external_source`
    ),
    metaOrphans: db.prepare(
      `DELETE FROM metadata WHERE series_key NOT IN (SELECT DISTINCT series_key FROM resources WHERE series_key <> '')`
    ),
    toggleFav: db.prepare(`UPDATE resources SET is_favorite = ? WHERE id = ?`),
    markOpened: db.prepare(
      `UPDATE resources SET open_count = open_count + 1, last_opened = ? WHERE id = ?`
    ),
    count: db.prepare(`SELECT COUNT(*) AS c FROM resources r JOIN libraries l ON l.id = r.library_id WHERE l.enabled = 1`),
    kindCounts: db.prepare(
      `SELECT r.kind AS kind, COUNT(*) AS c FROM resources r JOIN libraries l ON l.id = r.library_id
       WHERE l.enabled = 1 GROUP BY r.kind`
    ),
    totalSize: db.prepare(
      `SELECT COALESCE(SUM(r.size), 0) AS s FROM resources r JOIN libraries l ON l.id = r.library_id WHERE l.enabled = 1`
    ),
    favCount: db.prepare(
      `SELECT COUNT(*) AS c FROM resources r JOIN libraries l ON l.id = r.library_id
       WHERE l.enabled = 1 AND r.is_favorite = 1`
    ),
    recentAddedCount: db.prepare(
      `SELECT COUNT(*) AS c FROM resources r JOIN libraries l ON l.id = r.library_id
       WHERE l.enabled = 1 AND r.first_seen >= ?`
    ),
    recentUsedCount: db.prepare(
      `SELECT COUNT(*) AS c FROM resources r JOIN libraries l ON l.id = r.library_id
       WHERE l.enabled = 1 AND r.last_opened > 0`
    ),
    folderCount: db.prepare(
      `SELECT COUNT(DISTINCT r.library_id || '|' || r.rel_dir) AS c FROM resources r
       JOIN libraries l ON l.id = r.library_id WHERE l.enabled = 1`
    ),
    subFolders: db.prepare(
      `SELECT rel_dir, name, COUNT(*) AS c, COALESCE(SUM(size), 0) AS s FROM resources
       WHERE library_id = ? AND (rel_dir = ? OR rel_dir LIKE ?) GROUP BY rel_dir`
    ),
    inFolder: db.prepare(
      `SELECT ${RESOURCE_COLUMNS} FROM resources WHERE library_id = ? AND rel_dir = ? ORDER BY sort_name ASC LIMIT 2000`
    ),
    byKindPrefix: db.prepare(
      `SELECT ${RESOURCE_COLUMNS} FROM resources WHERE library_id = ? AND rel_dir = ? AND kind = ? ORDER BY sort_name ASC LIMIT 500`
    ),
    hashCandidates: db.prepare(`
      SELECT ${RESOURCE_COLUMNS_JOINED} FROM resources r JOIN libraries l ON l.id = r.library_id
      WHERE l.enabled = 1 AND r.size > 0 AND r.size <= ? AND r.hash_state = 0
        AND r.size IN (SELECT size FROM resources r2 JOIN libraries l2 ON l2.id = r2.library_id
                       WHERE l2.enabled = 1 AND r2.size > 0 GROUP BY size HAVING COUNT(*) > 1)
      LIMIT ?
    `),
    duplicateCount: db.prepare(`
      SELECT COUNT(*) AS c FROM resources r JOIN libraries l ON l.id = r.library_id
      WHERE l.enabled = 1 AND r.hash <> ''
        AND (r.size, r.hash) IN (SELECT r2.size, r2.hash FROM resources r2
             JOIN libraries l2 ON l2.id = r2.library_id WHERE l2.enabled = 1 AND r2.hash <> ''
             GROUP BY r2.size, r2.hash HAVING COUNT(*) > 1)
    `),
    kvGet: db.prepare(`SELECT v FROM kv WHERE k = ?`),
    kvSet: db.prepare(`INSERT INTO kv (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v`)
  }

  // 缩略图管线升级时由 thumbs.ts 调用 resetThumbState() 清状态
}

function getDb(): DatabaseSync {
  if (!db) throw new Error('数据库尚未初始化')
  return db
}

/* ============================ 行 → 对象 ============================ */

function rowToItem(row: Row): ResourceItem {
  const ext = row.ext
  return {
    id: row.id,
    path: row.path,
    name: row.name,
    baseName: row.base_name,
    ext,
    kind: row.kind as ResourceKind,
    size: row.size,
    mtimeMs: row.mtime,
    addedMs: row.first_seen,
    libraryId: row.library_id,
    relDir: row.rel_dir,
    isFavorite: row.is_favorite === 1,
    lastOpenedMs: row.last_opened,
    openCount: row.open_count,
    title: row.title,
    subtitle: '',
    width: row.width,
    height: row.height,
    durationMs: row.duration_ms,
    cardLine: row.card_line,
    seriesKey: row.series_key ?? '',
    seriesTitle: row.series_title ?? '',
    volume: row.volume ?? 0
  }
}

function rowToDetail(row: Row): ResourceDetail {
  let meta: Record<string, string | number | boolean | null> = {}
  if (row.meta_json) {
    try {
      meta = JSON.parse(row.meta_json) as Record<string, string | number | boolean | null>
    } catch {
      meta = {}
    }
  }
  return {
    ...rowToItem(row),
    autoKind: row.auto_kind as ResourceKind,
    overridden: row.overridden === 1,
    hash: row.hash,
    hashState: row.hash_state,
    bitrate: row.bitrate,
    album: row.album,
    artist: row.artist,
    year: row.year,
    meta
  }
}

/* ============================ 资源库 ============================ */

export function listLibraries(): Library[] {
  const rows = stmts.allLibs.all() as unknown as (Row & {
    path: string
    label: string
    enabled: number
    max_depth: number
    created_at: number
    last_scanned: number
    resource_count: number
  })[]
  return rows.map((r) => ({
    id: r.id,
    path: r.path,
    label: r.label,
    enabled: r.enabled === 1,
    maxDepth: r.max_depth,
    createdAt: r.created_at,
    lastScanned: r.last_scanned,
    resourceCount: r.resource_count
  }))
}

export function findLibraryByPath(absPath: string): Library | null {
  const norm = normalizePath(absPath)
  const row = stmts.libByNorm.get(norm) as unknown as Record<string, unknown> | undefined
  if (!row) return null
  return listLibraries().find((l) => l.id === Number(row.id)) ?? null
}

export function getLibrary(id: number): Library | null {
  return listLibraries().find((l) => l.id === id) ?? null
}

export function addLibrary(absPath: string, label = ''): Library {
  const norm = normalizePath(absPath)
  const existing = stmts.libByNorm.get(norm) as unknown as { id: number } | undefined
  if (existing) {
    stmts.setLibEnabled.run(1, existing.id)
    return getLibrary(existing.id) as Library
  }
  stmts.insertLib.run(absPath, norm, label || path.basename(absPath), Date.now())
  const created = stmts.libByNorm.get(norm) as unknown as { id: number }
  return getLibrary(created.id) as Library
}

export function removeLibrary(id: number): void {
  stmts.deleteLibResources.run(id)
  stmts.deleteLib.run(id)
}

export function setLibraryEnabled(id: number, enabled: boolean): void {
  stmts.setLibEnabled.run(enabled ? 1 : 0, id)
}

export function nextScanToken(libraryId: number): number {
  stmts.bumpToken.run(libraryId)
  const row = stmts.libById.get(libraryId) as unknown as { scan_token: number } | undefined
  return row?.scan_token ?? 1
}

export function finishLibraryScan(libraryId: number, token: number): void {
  const removed = getDb().prepare(`DELETE FROM resources WHERE library_id = ? AND last_scan_token <> ?`).run(libraryId, token)
  stmts.setLibScanned.run(Date.now(), token, libraryId)
  void removed
}

export function deleteLibraryResources(libraryId: number): void {
  stmts.deleteLibResources.run(libraryId)
}

/* ============================ 写入 ============================ */

export function normalizePath(p: string): string {
  return path.resolve(p).toLowerCase()
}

export function upsertResource(input: UpsertInput): { id: number; inserted: boolean } {
  const norm = normalizePath(input.path)
  const before = stmts.byNorm.get(norm) as unknown as Row | undefined
  stmts.upsert.run(
    input.path,
    norm,
    input.libraryId,
    input.relDir,
    input.name,
    naturalKey(input.name),
    input.ext ? input.name.slice(0, input.name.length - input.ext.length) : input.name,
    input.ext,
    input.kind,
    input.autoKind,
    input.size,
    Math.round(input.mtime),
    Math.round(input.ctime),
    before ? before.first_seen : Date.now(),
    input.scanToken,
    input.seriesKey ?? '',
    input.seriesTitle ?? '',
    input.volume ?? 0
  )
  const after = stmts.byNorm.get(norm) as unknown as Row
  return { id: after.id, inserted: !before }
}

export function getResourceByPath(absPath: string): ResourceDetail | null {
  const row = stmts.byNorm.get(normalizePath(absPath)) as unknown as Row | undefined
  return row ? rowToDetail(row) : null
}

/** 重命名后同步索引（不用等下一次扫描） */
export function moveResource(oldPath: string, newPath: string): void {
  const oldNorm = normalizePath(oldPath)
  const row = stmts.byNorm.get(oldNorm) as unknown as Row | undefined
  if (!row) return
  const name = path.basename(newPath)
  const ext = name.includes('.') ? name.slice(name.lastIndexOf('.')).toLowerCase() : ''
  getDb()
    .prepare(
      `UPDATE resources SET path = ?, norm = ?, name = ?, sort_name = ?, base_name = ? WHERE id = ?`
    )
    .run(
      newPath,
      normalizePath(newPath),
      name,
      naturalKey(name),
      ext ? name.slice(0, name.length - ext.length) : name,
      row.id
    )
}

/** 删除后同步索引 */
export function deleteResourceByPath(absPath: string): void {
  getDb().prepare(`DELETE FROM resources WHERE norm = ?`).run(normalizePath(absPath))
}

export function getResourceById(id: number): ResourceDetail | null {
  const row = stmts.byId.get(id) as unknown as Row | undefined
  return row ? rowToDetail(row) : null
}

export interface MetaPatch {
  width?: number
  height?: number
  durationMs?: number
  bitrate?: number
  title?: string
  artist?: string
  album?: string
  year?: number
  cardLine?: string
  meta?: Record<string, unknown>
}

export function updateResourceMeta(id: number, patch: MetaPatch): void {
  const row = stmts.byId.get(id) as unknown as Row | undefined
  if (!row) return
  stmts.setMeta.run(
    patch.width ?? row.width,
    patch.height ?? row.height,
    patch.durationMs ?? row.duration_ms,
    patch.bitrate ?? row.bitrate,
    patch.title ?? row.title,
    patch.artist ?? row.artist,
    patch.album ?? row.album,
    patch.year ?? row.year,
    patch.cardLine ?? row.card_line,
    patch.meta ? JSON.stringify(patch.meta) : row.meta_json,
    id
  )
}

export function updateThumbState(id: number, thumbKey: string, state: number): void {
  stmts.setThumb.run(thumbKey, state, id)
}

export function updateHash(id: number, hash: string, state: number): void {
  stmts.setHash.run(hash, state, id)
}

export function markMetaState(id: number, state: number): void {
  stmts.setMetaState.run(state, id)
}

/** 缩略图管线升级后：把所有资源的缩略图状态清空，让它们重新生成 */
export function resetThumbState(): void {
  getDb().exec(`UPDATE resources SET thumb_state = 0, thumb_key = ''`)
}

/** 缩略图/元数据的处理情况（冒烟自检用） */
export function processStats(): { thumbOk: number; thumbFailed: number; thumbPending: number; metaDone: number; metaPending: number; hashed: number } {
  const one = (sql: string): number =>
    ((getDb().prepare(sql).get() as unknown as { c: number } | undefined)?.c ?? 0)
  return {
    thumbOk: one(`SELECT COUNT(*) AS c FROM resources WHERE thumb_state = 1`),
    thumbFailed: one(`SELECT COUNT(*) AS c FROM resources WHERE thumb_state = -1`),
    thumbPending: one(`SELECT COUNT(*) AS c FROM resources WHERE thumb_state = 0 AND size > 0`),
    metaDone: one(`SELECT COUNT(*) AS c FROM resources WHERE meta_state = 1`),
    metaPending: one(`SELECT COUNT(*) AS c FROM resources WHERE meta_state = 0 AND size > 0`),
    hashed: one(`SELECT COUNT(*) AS c FROM resources WHERE hash <> ''`)
  }
}

export function setResourceKind(id: number, kind: ResourceKind, overridden: boolean, cardLine: string): void {
  stmts.setKind.run(kind, overridden ? 1 : 0, cardLine, id)
}

/** 内容判定得出的类型（图集式 EPUB / 图片型 ZIP → 漫画），保留用户手动覆盖 */
export function setAutoKind(id: number, kind: ResourceKind, cardLine: string): void {
  stmts.setAutoKind.run(kind, kind, cardLine, id)
}

/** 作品聚合信息（内容判定为漫画后补写，或每次扫描刷新） */
export function updateSeries(id: number, seriesKey: string, seriesTitle: string, volume: number): void {
  getDb()
    .prepare(`UPDATE resources SET series_key = ?, series_title = ?, volume = ? WHERE id = ?`)
    .run(seriesKey, seriesTitle, volume, id)
}

export function setFavorite(id: number, favorite: boolean): void {
  stmts.toggleFav.run(favorite ? 1 : 0, id)
}

export function markOpened(id: number): void {
  stmts.markOpened.run(Date.now(), id)
}

export function hashCandidates(maxSizeBytes: number, limit: number): ResourceDetail[] {
  return (stmts.hashCandidates.all(maxSizeBytes, limit) as unknown as Row[]).map(rowToDetail)
}

export function pendingThumbCandidates(libraryId: number, limit: number): ResourceDetail[] {
  const rows = getDb()
    .prepare(
      `SELECT ${RESOURCE_COLUMNS} FROM resources
       WHERE library_id = ? AND thumb_state = 0 AND size > 0 ORDER BY mtime DESC LIMIT ?`
    )
    .all(libraryId, limit) as unknown as Row[]
  return rows.map(rowToDetail)
}

/** 还没读取过元数据的资源（音乐标签 / 视频宽高 / 压缩包内容判定） */
export function pendingMetaCandidates(libraryId: number, limit: number): ResourceDetail[] {
  const rows = getDb()
    .prepare(
      `SELECT ${RESOURCE_COLUMNS} FROM resources
       WHERE library_id = ? AND meta_state = 0 AND size > 0
         AND kind IN ('music','movie','tv','anime','novel','comic','archive','document','image','wallpaper')
       ORDER BY size DESC LIMIT ?`
    )
    .all(libraryId, limit) as unknown as Row[]
  return rows.map(rowToDetail)
}

/* ============================ 查询 ============================ */

function recentAddedSince(): number {
  return Date.now() - RECENT_ADDED_DAYS * 24 * 3600 * 1000
}

function buildWhere(query: ResourceQuery): { sql: string; params: (string | number)[] } {
  const clauses: string[] = ['l.enabled = 1']
  const params: (string | number)[] = []

  if (query.libraryId) {
    clauses.push('r.library_id = ?')
    params.push(query.libraryId)
  }
  if (query.kind) {
    clauses.push('r.kind = ?')
    params.push(query.kind)
  }
  if (query.folder) {
    clauses.push('r.library_id = ? AND r.rel_dir = ?')
    params.push(query.folder.libraryId, query.folder.relDir)
  }
  const search = (query.search ?? '').trim().toLowerCase()
  if (search) {
    clauses.push('(lower(r.name) LIKE ? OR lower(r.title) LIKE ? OR lower(r.rel_dir) LIKE ?)')
    const like = `%${search}%`
    params.push(like, like, like)
  }

  switch (query.view) {
    case 'favorites':
      clauses.push('r.is_favorite = 1')
      break
    case 'recent-added':
      clauses.push('r.first_seen >= ?')
      params.push(recentAddedSince())
      break
    case 'recent-used':
      clauses.push('r.last_opened > 0')
      break
    case 'duplicates':
      clauses.push(
        `r.hash <> '' AND (r.size, r.hash) IN (SELECT r2.size, r2.hash FROM resources r2
         JOIN libraries l2 ON l2.id = r2.library_id WHERE l2.enabled = 1 AND r2.hash <> ''
         GROUP BY r2.size, r2.hash HAVING COUNT(*) > 1)`
      )
      break
    default:
      break
  }
  return { sql: clauses.join(' AND '), params }
}

function orderClause(query: ResourceQuery): string {
  const dir = query.order === 'desc' ? 'DESC' : 'ASC'
  const column =
    query.view === 'recent-added'
      ? 'r.first_seen'
      : query.view === 'recent-used'
        ? 'r.last_opened'
        : {
            name: 'r.sort_name',
            mtime: 'r.mtime',
            size: 'r.size',
            added: 'r.first_seen',
            kind: 'r.kind',
            opened: 'r.last_opened'
          }[query.sort] ?? 'r.sort_name'
  // 默认视图（最近添加/最近使用/重复）用降序更符合直觉
  const effectiveDir =
    query.view === 'recent-added' || query.view === 'recent-used'
      ? 'DESC'
      : query.view === 'duplicates' && query.sort === 'name'
        ? 'ASC'
        : dir
  return `ORDER BY ${column} ${effectiveDir}, r.sort_name ASC`
}

export function queryResources(query: ResourceQuery): ResourcePage {
  const { sql, params } = buildWhere(query)
  const totalRow = getDb()
    .prepare(`SELECT COUNT(*) AS c FROM resources r JOIN libraries l ON l.id = r.library_id WHERE ${sql}`)
    .get(...params) as unknown as { c: number }
  const limit = Math.max(1, Math.min(2000, query.limit || 300))
  const offset = Math.max(0, query.offset || 0)
  const rows = getDb()
    .prepare(
      `SELECT ${RESOURCE_COLUMNS_JOINED} FROM resources r JOIN libraries l ON l.id = r.library_id
       WHERE ${sql} ${orderClause(query)} LIMIT ? OFFSET ?`
    )
    .all(...params, limit, offset) as unknown as Row[]
  return { total: totalRow?.c ?? 0, items: rows.map(rowToItem) }
}

export function getStats(): LibraryStats {
  const kindRows = stmts.kindCounts.all() as unknown as { kind: string; c: number }[]
  const kinds: KindCount[] = kindRows.map((r) => ({ kind: r.kind as ResourceKind, count: r.c }))
  const total = kinds.reduce((sum, k) => sum + k.count, 0)
  const recentAdded = (stmts.recentAddedCount.get(recentAddedSince()) as unknown as { c: number })?.c ?? 0
  return {
    total,
    kinds,
    favorites: (stmts.favCount.get() as unknown as { c: number })?.c ?? 0,
    recentAdded,
    recentUsed: (stmts.recentUsedCount.get() as unknown as { c: number })?.c ?? 0,
    duplicates: (stmts.duplicateCount.get() as unknown as { c: number })?.c ?? 0,
    libraries: listLibraries().filter((l) => l.enabled).length,
    folderCount: (stmts.folderCount.get() as unknown as { c: number })?.c ?? 0,
    totalSize: (stmts.totalSize.get() as unknown as { s: number })?.s ?? 0
  }
}

/** 把 (rel_dir → 数量/大小) 聚合成绩效某目录下的一级子目录 */
function aggregateChildren(
  rows: { rel_dir: string; c: number; s: number }[],
  parent: string,
  libraryId: number
): FolderNode[] {
  const map = new Map<string, FolderNode & { subs: Set<string> }>()
  const prefix = parent ? `${parent}\\` : ''
  for (const row of rows) {
    const relDir = row.rel_dir ?? ''
    if (relDir === parent) continue
    if (parent && !relDir.startsWith(prefix)) continue
    const rest = parent ? relDir.slice(prefix.length) : relDir
    if (!rest) continue
    const segments = rest.split('\\')
    const childRel = parent ? `${parent}\\${segments[0]}` : segments[0]
    let node = map.get(childRel)
    if (!node) {
      node = {
        name: segments[0],
        path: '',
        relDir: childRel,
        libraryId,
        fileCount: 0,
        subFolderCount: 0,
        totalSize: 0,
        subs: new Set<string>()
      }
      map.set(childRel, node)
    }
    if (segments.length === 1) {
      node.fileCount += row.c
      node.totalSize += row.s
    } else {
      node.subs.add(segments[1])
    }
  }
  return [...map.values()]
    .map((node) => ({
      name: node.name,
      path: node.path,
      relDir: node.relDir,
      libraryId: node.libraryId,
      fileCount: node.fileCount,
      subFolderCount: node.subs.size,
      totalSize: node.totalSize
    }))
    .sort((a, b) => a.name.localeCompare(b.name, 'zh-Hans-CN', { numeric: true }))
}

/** 目录浏览：列出某个资源库目录下一层的子目录 */
export function listFolders(libraryId: number, relDir: string): FolderNode[] {
  const rows = getDb()
    .prepare(
      `SELECT rel_dir, COUNT(*) AS c, COALESCE(SUM(size), 0) AS s FROM resources
       WHERE library_id = ? GROUP BY rel_dir`
    )
    .all(libraryId) as unknown as { rel_dir: string; c: number; s: number }[]
  return aggregateChildren(rows, relDir, libraryId)
}

export function listFolderResources(libraryId: number, relDir: string): ResourceItem[] {
  return (stmts.inFolder.all(libraryId, relDir) as unknown as Row[]).map(rowToItem)
}

/** 每个资源库根下的一级目录（用于"目录"视图与首页概览） */
export function listTopFolders(): FolderNode[] {
  const result: FolderNode[] = []
  for (const lib of listLibraries()) {
    if (!lib.enabled) continue
    const rows = getDb()
      .prepare(
        `SELECT rel_dir, COUNT(*) AS c, COALESCE(SUM(size), 0) AS s FROM resources
         WHERE library_id = ? GROUP BY rel_dir`
      )
      .all(lib.id) as unknown as { rel_dir: string; c: number; s: number }[]
    for (const node of aggregateChildren(rows, '', lib.id)) {
      result.push(node)
    }
  }
  return result
}

/* ============================ 作品（系列）聚合 ============================ */

/** 某类型下按作品聚合（漫画墙 / 后续剧集、专辑复用） */
export function listSeries(kind: ResourceKind, libraryId?: number | null): SeriesItem[] {
  const rows = getDb()
    .prepare(
      `SELECT r.series_key AS key,
              r.kind AS kind,
              MIN(r.series_title) AS title,
              COUNT(*) AS volume_count,
              COALESCE(SUM(r.size), 0) AS total_size,
              MAX(r.mtime) AS mtime,
              MAX(r.first_seen) AS added,
              MAX(r.is_favorite) AS fav,
              SUM(CASE WHEN r.volume > 0 THEN 1 ELSE 0 END) AS numbered,
              (SELECT r2.path FROM resources r2
                 WHERE r2.series_key = r.series_key
                 ORDER BY CASE WHEN r2.volume > 0 THEN r2.volume ELSE 999999 END, r2.sort_name ASC
                 LIMIT 1) AS cover_path,
              (SELECT r3.id FROM resources r3
                 WHERE r3.series_key = r.series_key
                 ORDER BY CASE WHEN r3.volume > 0 THEN r3.volume ELSE 999999 END, r3.sort_name ASC
                 LIMIT 1) AS first_id
       FROM resources r
       JOIN libraries l ON l.id = r.library_id
       WHERE l.enabled = 1 AND r.kind = ? AND r.series_key <> ''
         ${libraryId ? 'AND r.library_id = ?' : ''}
       GROUP BY r.series_key
       ORDER BY MIN(r.series_title) COLLATE NOCASE ASC`
    )
    .all(...(libraryId ? [kind, libraryId] : [kind])) as unknown as {
    key: string
    kind: string
    title: string
    volume_count: number
    total_size: number
    mtime: number
    added: number
    fav: number
    numbered: number
    cover_path: string
    first_id: number
  }[]

  return rows.map((row) => ({
    key: row.key,
    kind: row.kind as ResourceKind,
    title: row.title ?? '',
    volumeCount: row.volume_count,
    totalSize: row.total_size,
    coverPath: row.cover_path ?? '',
    firstResourceId: row.first_id ?? 0,
    mtimeMs: row.mtime ?? 0,
    addedMs: row.added ?? 0,
    isFavorite: row.fav === 1,
    numberedCount: row.numbered ?? 0
  }))
}

/** 一部作品的所有卷（按卷号、再按文件名排序） */
export function seriesVolumes(key: string): ResourceDetail[] {
  const rows = getDb()
    .prepare(
      `SELECT ${RESOURCE_COLUMNS_JOINED} FROM resources r
       JOIN libraries l ON l.id = r.library_id
       WHERE l.enabled = 1 AND r.series_key = ?
       ORDER BY CASE WHEN r.volume > 0 THEN 0 ELSE 1 END, r.volume ASC, r.sort_name ASC`
    )
    .all(key) as unknown as (Row & { library_path?: string })[]
  return rows.map(rowToDetail)
}

/** 一部作品所在的资源库与目录（用于"打开目录"） */
export function seriesLocation(key: string): { libraryId: number; libraryPath: string; relDir: string } | null {
  const row = getDb()
    .prepare(
      `SELECT r.library_id AS library_id, l.path AS library_path, r.rel_dir AS rel_dir
       FROM resources r JOIN libraries l ON l.id = r.library_id
       WHERE r.series_key = ? AND l.enabled = 1 LIMIT 1`
    )
    .get(key) as unknown as { library_id: number; library_path: string; rel_dir: string } | undefined
  if (!row) return null
  return { libraryId: row.library_id, libraryPath: row.library_path, relDir: row.rel_dir }
}

/* ============================ 元数据（作品级） ============================ */

interface MetadataRow {
  series_key: string
  kind: string
  title: string
  original_title: string
  year: number
  overview: string
  genres: string
  author: string
  studio: string
  country: string
  language: string
  rating: number
  external_source: string
  external_id: string
  match_status: string
  match_confidence: number
  poster_path: string
  backdrop_path: string
  cover_path: string
  extra_json: string
  updated_at: number
  created_at: number
}

function parseJsonSafe<T>(value: string, fallback: T): T {
  try {
    const parsed = JSON.parse(value)
    return (parsed ?? fallback) as T
  } catch {
    return fallback
  }
}

function rowToMetadata(row: MetadataRow): MetadataRecord {
  return {
    seriesKey: row.series_key,
    kind: row.kind as ResourceKind,
    title: row.title,
    originalTitle: row.original_title,
    year: row.year,
    overview: row.overview,
    genres: parseJsonSafe<string[]>(row.genres, []),
    author: row.author,
    studio: row.studio,
    country: row.country,
    language: row.language,
    rating: row.rating,
    externalSource: row.external_source,
    externalId: row.external_id,
    matchStatus: row.match_status as MatchStatus,
    matchConfidence: row.match_confidence,
    posterPath: row.poster_path,
    backdropPath: row.backdrop_path,
    coverPath: row.cover_path,
    extra: parseJsonSafe<Record<string, unknown>>(row.extra_json, {}),
    updatedAt: row.updated_at,
    createdAt: row.created_at
  }
}

export function getMetadata(seriesKey: string): MetadataRecord | null {
  const row = stmts.metaByKey.get(seriesKey) as unknown as MetadataRow | undefined
  return row ? rowToMetadata(row) : null
}

export function saveMetadata(record: MetadataRecord): void {
  stmts.metaUpsert.run(
    record.seriesKey,
    record.kind,
    record.title,
    record.originalTitle,
    record.year,
    record.overview,
    JSON.stringify(record.genres ?? []),
    record.author,
    record.studio,
    record.country,
    record.language,
    record.rating,
    record.externalSource,
    record.externalId,
    record.matchStatus,
    record.matchConfidence,
    record.posterPath,
    record.backdropPath,
    record.coverPath,
    JSON.stringify(record.extra ?? {}),
    Date.now(),
    record.createdAt || Date.now()
  )
}

/**
 * 整体替换一行元数据（含清空字段）。
 * saveMetadata 走的是 upsert：空值不覆盖已有值——适合 Provider 补字段，
 * 但"重置为本地信息""手动清空某个字段"必须用这个，否则永远清不掉。
 */
export function replaceMetadata(record: MetadataRecord): void {
  getDb()
    .prepare(
      `UPDATE metadata SET kind = ?, title = ?, original_title = ?, year = ?, overview = ?, genres = ?,
         author = ?, studio = ?, country = ?, language = ?, rating = ?, external_source = ?, external_id = ?,
         match_status = ?, match_confidence = ?, poster_path = ?, backdrop_path = ?, cover_path = ?,
         extra_json = ?, updated_at = ?
       WHERE series_key = ?`
    )
    .run(
      record.kind,
      record.title,
      record.originalTitle,
      record.year,
      record.overview,
      JSON.stringify(record.genres ?? []),
      record.author,
      record.studio,
      record.country,
      record.language,
      record.rating,
      record.externalSource,
      record.externalId,
      record.matchStatus,
      record.matchConfidence,
      record.posterPath,
      record.backdropPath,
      record.coverPath,
      JSON.stringify(record.extra ?? {}),
      Date.now(),
      record.seriesKey
    )
}

export function listMetadata(status?: MatchStatus): MetadataRecord[] {
  const rows = (status ? stmts.metaByStatus.all(status) : stmts.metaAll.all()) as unknown as MetadataRow[]
  return rows.map(rowToMetadata)
}

export function metadataStats(): { total: number; byStatus: Record<string, number>; bySource: Record<string, number> } {
  const byStatus: Record<string, number> = {}
  const bySource: Record<string, number> = {}
  let total = 0
  for (const row of stmts.metaStats.all() as unknown as { status: string; count: number }[]) {
    byStatus[row.status] = row.count
    total += row.count
  }
  for (const row of stmts.metaStatsSource.all() as unknown as { source: string; count: number }[]) {
    bySource[row.source || '(空)'] = row.count
  }
  return { total, byStatus, bySource }
}

export function deleteMetadata(seriesKey: string): void {
  stmts.metaDelete.run(seriesKey)
}

/** 清理已经没有对应文件的作品元数据，返回删除条数 */
export function pruneMetadata(): number {
  const before = metadataStats().total
  stmts.metaOrphans.run()
  return before - metadataStats().total
}

export interface WorkRowRaw {
  series_key: string
  kind: string
  title: string
  volume_count: number
  total_size: number
  cover_path: string
  match_status: string | null
  external_source: string | null
  year: number | null
  author: string | null
  rating: number | null
  poster_path: string | null
  match_confidence: number | null
  updated_at: number | null
  extra_json: string | null
}

/** 散图漫画目录聚合用：所有图片/壁纸资源（带库与目录信息） */
export function listLooseImages(): {
  id: number
  name: string
  ext: string
  size: number
  libraryId: number
  relDir: string
  overridden: number
}[] {
  return getDb()
    .prepare(
      `SELECT r.id AS id, r.name AS name, r.ext AS ext, r.size AS size,
              r.library_id AS libraryId, r.rel_dir AS relDir, r.overridden AS overridden
       FROM resources r JOIN libraries l ON l.id = r.library_id
       WHERE l.enabled = 1 AND r.kind IN ('image', 'wallpaper')`
    )
    .all() as unknown as {
    id: number
    name: string
    ext: string
    size: number
    libraryId: number
    relDir: string
    overridden: number
  }[]
}

/** 匹配中心：所有作品（作品实体左连接元数据），待确认/失败排在前面 */export function listWorkRows(): WorkRowRaw[] {
  return getDb()
    .prepare(
      `SELECT r.series_key AS series_key,
              r.kind AS kind,
              MIN(r.series_title) AS title,
              COUNT(1) AS volume_count,
              COALESCE(SUM(r.size), 0) AS total_size,
              (SELECT r2.path FROM resources r2
                 WHERE r2.series_key = r.series_key
                 ORDER BY CASE WHEN r2.volume > 0 THEN r2.volume ELSE 999999 END, r2.sort_name ASC
                 LIMIT 1) AS cover_path,
              m.match_status AS match_status,
              m.external_source AS external_source,
              m.year AS year,
              m.author AS author,
              m.rating AS rating,
              m.poster_path AS poster_path,
              m.match_confidence AS match_confidence,
              m.updated_at AS updated_at,
              m.extra_json AS extra_json
       FROM resources r
       JOIN libraries l ON l.id = r.library_id
       LEFT JOIN metadata m ON m.series_key = r.series_key
       WHERE l.enabled = 1 AND r.series_key <> ''
       GROUP BY r.series_key
       ORDER BY CASE COALESCE(m.match_status, 'none')
                  WHEN 'pending' THEN 0
                  WHEN 'failed' THEN 1
                  WHEN 'local' THEN 2
                  WHEN 'none' THEN 2
                  WHEN 'matched' THEN 3
                  WHEN 'confirmed' THEN 4
                  ELSE 5
                END,
                MIN(r.series_title) COLLATE NOCASE ASC`
    )
    .all() as unknown as WorkRowRaw[]
}

/**
 * Phase 10：扫描结束后的数据库维护。
 * PRAGMA optimize 让查询计划器更新统计信息；WAL 截断避免日志无限增长。
 */
export function optimizeDatabase(): { walTruncated: boolean } {
  let walTruncated = false
  try {
    const database = getDb()
    database.exec(`PRAGMA optimize`)
    database.exec(`PRAGMA wal_checkpoint(TRUNCATE)`)
    walTruncated = true
  } catch {
    /* 维护失败不影响使用 */
  }
  return { walTruncated }
}

/** 数据库文件占用（MB），用于设置界面展示 */
export function databaseSizeMB(): number {
  try {
    const row = getDb().prepare(`PRAGMA page_count`).get() as unknown as { page_count: number }
    const page = getDb().prepare(`PRAGMA page_size`).get() as unknown as { page_size: number }
    return Math.round(((row?.page_count ?? 0) * (page?.page_size ?? 0)) / 1024 / 1024 * 10) / 10
  } catch {
    return 0
  }
}

/** 开发自检用：返回某条 SQL 的执行计划（看有没有走索引） */
export function explainPlan(sql: string): string[] {
  try {
    const rows = getDb().prepare(`EXPLAIN QUERY PLAN ${sql}`).all() as unknown as { detail: string }[]
    return rows.map((row) => row.detail)
  } catch (err) {
    return [`EXPLAIN 失败：${err instanceof Error ? err.message : String(err)}`]
  }
}

export function kvGet(key: string): string {  const row = stmts.kvGet.get(key) as unknown as { v: string } | undefined
  return row?.v ?? ''
}

export function kvSet(key: string, value: string): void {
  stmts.kvSet.run(key, value)
}

export function closeDatabase(): void {
  try {
    db?.close()
  } catch {
    /* ignore */
  }
  db = null
  stmts = {}
}
