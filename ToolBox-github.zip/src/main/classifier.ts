import { baseNameOf, extOf, kindOfExt } from '@shared/resource-kinds'
import { formatSize, formatDuration } from '@shared/format'
import type { ResourceKind } from '@shared/types'

export interface ClassifyInput {
  name: string
  relDir: string
  /** 同目录内其它文件的情况（用于"绿色软件目录"判定） */
  siblingFileCount: number
  siblingDllCount: number
  siblingExeCount: number
}

export interface ClassifyResult {
  kind: ResourceKind
  /** 判定依据，写进详情里方便用户理解为什么这么分类 */
  reason: string
}

const ANIME_DIR_HINTS = ['动漫', '动画', '番剧', '新番', 'anime', 'bangumi', '番组']
const ANIME_NAME_HINTS = ['bdrip', 'ncop', 'nced', 'webrip', 'hevc', '10bit', '简繁', '繁简', '字幕组', '喵萌', '桜都', 'lilith', 'vcb', 'sakurato', 'lolihouse', 'kisssub', '诸神', '幻樱', '千夏']
const TV_DIR_HINTS = ['电视剧', '美剧', '英剧', '日剧', '韩剧', '国产剧', '港剧', '台剧', '剧集', 'shows', 'series', 'season']
const MOVIE_DIR_HINTS = ['电影', '影片', 'movies', 'movie', 'film', 'films', '影视']
const WALLPAPER_DIR_HINTS = ['壁纸', 'wallpaper', 'wallpapers', 'desktop', '桌面壁纸']
const NOVEL_DIR_HINTS = ['小说', '轻小说', 'novel', 'novels', 'book', 'books', '电子书', 'ebook', '网文']
const COMIC_DIR_HINTS = ['漫画', 'comic', 'comics', 'manga', 'manhua', '同人志']
const DOC_DIR_HINTS = ['文档', 'documents', 'doc', '资料', '报表', '合同', '发票']

const TV_NAME_PATTERNS = [
  /s\d{1,2}\s*[.\-_ ]?\s*e\d{1,3}/i,
  /第\s*\d{1,4}\s*[集话話]/,
  /ep?\s*\d{1,3}\b/i,
  /season\s*\d{1,2}/i,
  /第\s*[一二三四五六七八九十\d]{1,3}\s*季/,
  /\b\d{1,2}x\d{2}\b/
]
const MOVIE_NAME_PATTERNS = [
  /(19|20)\d{2}/,
  /\b(2160p|1080p|720p|480p|4k|8k|bluray|blu-ray|bdremux|web-dl|webrip|hdrip|dvdrip|hdtv|remux)\b/i
]
const ANIME_NAME_PATTERNS = [/\[[^\]]{2,20}\]/, /【[^】]{2,20}】/]

function includesAny(haystack: string, needles: string[]): boolean {
  const lower = haystack.toLowerCase()
  return needles.some((n) => lower.includes(n))
}

function matchesAny(value: string, patterns: RegExp[]): boolean {
  return patterns.some((p) => p.test(value))
}

/** 基础分类 + 文件名/目录启发式细化 */
export function classify(input: ClassifyInput): ClassifyResult {
  const name = input.name
  const ext = extOf(name)
  const relDir = input.relDir ?? ''
  const parent = relDir ? (relDir.split('\\').pop() ?? '') : ''
  const scanText = `${relDir}\\${name}`
  const base = kindOfExt(ext)

  switch (base) {
    case 'movie': {
      if (includesAny(relDir, ANIME_DIR_HINTS) || includesAny(parent, ANIME_DIR_HINTS)) {
        return { kind: 'anime', reason: '所在目录是动漫目录' }
      }
      if (matchesAny(name, ANIME_NAME_PATTERNS) && /s\d{1,2}\s*e\d{1,3}/i.test(name)) {
        return { kind: 'anime', reason: '文件名符合番剧命名（字幕组 + 季集）' }
      }
      if (includesAny(name, ANIME_NAME_HINTS) && matchesAny(name, TV_NAME_PATTERNS)) {
        return { kind: 'anime', reason: '文件名带番剧特征关键字' }
      }
      if (includesAny(relDir, TV_DIR_HINTS) || matchesAny(name, TV_NAME_PATTERNS)) {
        return { kind: 'tv', reason: '文件名/目录符合剧集特征' }
      }
      if (includesAny(relDir, MOVIE_DIR_HINTS) || matchesAny(name, MOVIE_NAME_PATTERNS)) {
        return { kind: 'movie', reason: '文件名/目录符合电影特征' }
      }
      return { kind: 'movie', reason: '视频文件（未细分，默认电影）' }
    }
    case 'music':
      return { kind: 'music', reason: '音频扩展名' }
    case 'image': {
      if (includesAny(relDir, WALLPAPER_DIR_HINTS)) {
        return { kind: 'wallpaper', reason: '位于壁纸类目录' }
      }
      return { kind: 'image', reason: '图片扩展名' }
    }
    case 'novel':
      return { kind: 'novel', reason: '电子书扩展名' }
    case 'comic':
      return { kind: 'comic', reason: '漫画压缩格式' }
    case 'document': {
      if (includesAny(relDir, COMIC_DIR_HINTS) && (ext === '.pdf' || ext === '.zip')) {
        return { kind: 'comic', reason: '位于漫画目录的文档' }
      }
      if (ext === '.pdf' || ext === '.txt' || ext === '.md' || ext === '.rtf' || ext === '.html' || ext === '.htm') {
        if (includesAny(relDir, NOVEL_DIR_HINTS)) return { kind: 'novel', reason: '位于小说目录' }
        if (/[《【][^》】]{2,40}[》】]/.test(baseNameOf(name)) && ext !== '.pdf') {
          return { kind: 'novel', reason: '文件名是书名号形式' }
        }
        if (includesAny(relDir, DOC_DIR_HINTS)) return { kind: 'document', reason: '位于文档目录' }
      }
      return { kind: 'document', reason: '文档扩展名' }
    }
    case 'installer': {
      if (ext === '.exe') {
        const looksPortable = input.siblingDllCount > 0 || input.siblingFileCount >= 8
        if (looksPortable && input.siblingExeCount <= 3) {
          return { kind: 'software', reason: `绿色软件目录（同目录 ${input.siblingFileCount} 个文件、${input.siblingDllCount} 个 dll）` }
        }
        return { kind: 'installer', reason: '独立可执行文件' }
      }
      return { kind: 'installer', reason: '安装包扩展名' }
    }
    case 'archive':
      return { kind: 'archive', reason: '压缩包扩展名' }
    case 'software':
      return { kind: 'software', reason: '软件包扩展名' }
    default:
      // 常见无扩展名可执行体
      if (!ext && input.siblingDllCount > 0) return { kind: 'software', reason: '绿色软件目录内的文件' }
      void scanText
      return { kind: 'other', reason: '未识别的资源类型' }
  }
}

export interface CardLineInput {
  kind: ResourceKind
  ext: string
  size: number
  width?: number
  height?: number
  durationMs?: number
  year?: number
  artist?: string
  album?: string
  title?: string
  bitrate?: number
  innerKind?: string
}

/* ============================ 作品 / 卷号解析 ============================ */

export interface SeriesParse {
  /** 作品名（已剔除卷号、字幕组标签、作者字段等噪音） */
  seriesTitle: string
  /** 作品标识：同一部作品各卷一致 */
  seriesKey: string
  /** 卷号；0 表示没识别出卷号 */
  volume: number
  /** 从文件名里识别出的作者（没有就是空） */
  author: string
  /** 判定依据，写进详情便于用户理解 */
  reason: string
}

/** 字幕组 / 汉化组 / 网文站 之类的方括号标签（含 〔〕〖〗 全角括号） */
const BRACKET_RE = /[[【〔〖(（][^\]】〕〗)）]{0,48}[\]】〕〗)）]/g
/** 网文站域名 / 网址噪音：www.xxx.com、xxx.net/read 之类 */
const SITE_NOISE_RE = /(?:https?:\/\/)?(?:www\.)?[a-z0-9-]{2,}\.(?:com|net|org|cc|me|xyz|top|info|cn|la|tv)(?:\/[^\s]*)?/gi
/** 括号里是这类词就直接整组丢掉（跟其它括号一样处理，这里只是记录语义） */
const SITE_KEYWORDS = /^(?:全本|完本|完结|校对版|精校版|txt|txt下载|免费阅读|最新章节|笔趣阁|顶点小说|无弹窗|手打|全集|合集|首发|独家|会员|下载|小说|epub|mobi)$/i
void SITE_KEYWORDS
const VOLUME_RULES: { re: RegExp; label: string }[] = [
  { re: /第\s*(\d{1,4})\s*[卷巻册集部]/u, label: '第N卷' },
  { re: /(?:volume|vol)\.?\s*(\d{1,4})/i, label: 'Vol.N' },
  { re: /(?:chapter|chap|ch)\.?\s*(\d{1,4})/i, label: 'Chapter N' },
  { re: /第\s*(\d{1,4})\s*[话話回]/u, label: '第N话' },
  { re: /(?:^|[\s._\-])v\s?(\d{1,3})(?=$|[\s._\-])/i, label: 'vN' },
  { re: /(?:^|[\s._\-])0*(\d{1,4})\s*$/, label: '末尾数字' }
]

function normalizeTitle(value: string): string {
  return value
    .replace(BRACKET_RE, ' ')
    .replace(SITE_NOISE_RE, ' ')
    .replace(/[._]+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .replace(/^[\s\-–—·]+|[\s\-–—·]+$/g, '')
    .trim()
}

export function makeSeriesKey(title: string, kind: ResourceKind): string {
  const normalized = normalizeTitle(title)
    .toLowerCase()
    .replace(/[\s\-_·:：,，.。!！?？'"“”‘’()（）[\]【】]/g, '')
    .replace(/[卷巻册集部]$/u, '')
  return normalized ? `${kind}:${normalized}` : ''
}

/** 专辑 key：一张专辑 = 一个作品（音乐的作品实体是专辑，不是单曲） */
export function makeAlbumKey(artist: string, album: string): string {
  const part = (value: string): string =>
    normalizeTitle(value)
      .toLowerCase()
      .replace(/[\s\-_·:：,，.。!！?？'"“”‘’()（）[\]【】《》]/g, '')
      .replace(/\b(the|a|an)\b/g, '')
  const left = part(artist)
  const right = part(album)
  if (!right) return ''
  return `music:${left}:${right}`
}

export interface AlbumParse {
  seriesKey: string
  /** 专辑名（作为作品名） */
  seriesTitle: string
  artist: string
}

/**
 * 从标签解析专辑归属；没有专辑标签时退化成"单曲自成一部作品"。
 * 例：artist=示例歌手, album=示例专辑 → music:示例歌手:示例专辑
 */
export function parseAlbum(input: { name: string; artist: string; album: string; albumArtist?: string }): AlbumParse {
  const album = (input.album || '').trim()
  const artist = (input.albumArtist || input.artist || '').trim()
  if (album) {
    return { seriesKey: makeAlbumKey(artist, album), seriesTitle: album, artist }
  }
  const fallback = extractAuthor(input.name).title || baseNameOf(input.name)
  return { seriesKey: makeAlbumKey('', fallback) || `music:${fallback.toLowerCase()}`, seriesTitle: fallback, artist }
}

/**
 * 从文件名解析「作品名 + 卷号」：
 *   海贼王 第001卷.cbz        → 海贼王 / 1
 *   [汉化组] One Piece 001.cbz → One Piece / 1
 *   进击的巨人 Vol.12.cbz      → 进击的巨人 / 12
 *   某漫画 03.pdf              → 某漫画 / 3
 *   单卷作品.cbz               → 单卷作品 / 0（自成一部作品）
 */
/** 副标题噪音（精校版 / 全本 之类） */
const TITLE_NOISE_RE = /[（(](?:精校版|全本|全集|完结|校对版|未删减|校对|实体版|epub|txt)[^）)]{0,12}[）)]/g

/**
 * 从文件名拆出「书名 + 作者」。国内下载的小说常见三种写法：
 *   《示例书名》作者：示例作者.txt              → 示例书名 / 示例作者
 *   《示例书名》（精校版全书） 作者：示例作者   → 示例书名 / 示例作者
 *   《单本示例》.txt                          → 单本示例 / 空
 * 影视名里的书名号也会去掉（《示例影片》.mp4 → 示例影片）。
 */
export function extractAuthor(name: string): { title: string; author: string } {
  let base = normalizeTitle(baseNameOf(name)).replace(TITLE_NOISE_RE, ' ')
  base = base.replace(/\s{2,}/g, ' ').trim()
  const authorMatch = /(?:作者|著者|作者是|by)\s*[:：]?\s*([^|｜_\-–—]{1,40})\s*$/i.exec(base)
  const author = authorMatch ? authorMatch[1].trim() : ''
  let titlePart = authorMatch ? base.slice(0, authorMatch.index) : base

  const quoted = /《([^》]{1,80})》/.exec(titlePart)
  if (quoted && quoted[1].trim().length > 0) titlePart = quoted[1].trim()
  titlePart = titlePart
    .replace(/[（(]\s*[)）]/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .replace(/^[\s\-–—·]+|[\s\-–—·]+$/g, '')
    .trim()
  return { title: titlePart || normalizeTitle(baseNameOf(name)), author }
}

export function parseSeries(name: string, kind: ResourceKind): SeriesParse {
  const rawBase = baseNameOf(name)
  const authored = extractAuthor(name)
  const cleaned = normalizeTitle(rawBase)
  for (const rule of VOLUME_RULES) {
    const match = rule.re.exec(rawBase)
    if (!match) continue
    const raw = match[1]
    const volume = Number.parseInt(raw, 10)
    if (!Number.isFinite(volume) || volume <= 0) continue
    // 排除把年份（1900~2099）当卷号
    if (/^(19|20)\d{2}$/.test(raw)) continue
    // 先把卷号标记从原名里去掉，再拆作者/书名号，避免"第001卷"留在作品名里
    const withoutVolume = rawBase.replace(match[0], ' ')
    const authoredRest = extractAuthor(withoutVolume)
    const seriesTitle = authoredRest.title || normalizeTitle(withoutVolume) || cleaned || rawBase
    return {
      seriesTitle,
      seriesKey: makeSeriesKey(seriesTitle, kind),
      volume,
      author: authored.author,
      reason: `按「${rule.label}」识别出第 ${volume} 卷`
    }
  }
  const seriesTitle = authored.title || cleaned || rawBase
  return {
    seriesTitle,
    seriesKey: makeSeriesKey(seriesTitle, kind),
    volume: 0,
    author: authored.author,
    reason: '未识别出卷号，作为单卷作品'
  }
}

/** 漫画线索（目录路径里出现这些词才考虑散图聚合，避免误伤壁纸目录） */
export const COMIC_HINT_RE = /漫画|同人志|comic|manga|manhua/i

/**
 * 页码式文件名 → 页码；识别不出来返回 0。
 *   001.jpg / 12.png / p03.webp / page-7.jpg / 第05页.jpg
 */
export function pageNumberOf(name: string): number {
  const dot = name.lastIndexOf('.')
  const base = (dot > 0 ? name.slice(0, dot) : name).trim()
  const patterns = [
    /^0*(\d{1,4})$/,
    /(?:^|[\s._\-])p(?:age)?[\s._\-]?0*(\d{1,4})$/i,
    /第\s*0*(\d{1,4})\s*[页頁p話话回]/u,
    /(?:^|[\s._\-])0*(\d{1,4})(?:[\s._\-]|$)/
  ]
  for (const pattern of patterns) {
    const match = pattern.exec(base)
    if (!match) continue
    const value = Number.parseInt(match[1], 10)
    if (Number.isFinite(value) && value > 0 && value < 100000) return value
  }
  return 0
}

/** 卡片第二行文案：按类型给最有用的信息 */
export function makeCardLine(input: CardLineInput): string {
  const parts: string[] = []
  const resolution = input.width && input.height ? `${input.width}×${input.height}` : ''
  const duration = formatDuration(input.durationMs)
  switch (input.kind) {
    case 'movie':
    case 'tv':
    case 'anime':
      if (input.year) parts.push(String(input.year))
      if (input.width && input.height) {
        const short = input.height >= 2000 ? '4K' : input.height >= 1000 ? '1080P' : input.height >= 700 ? '720P' : resolution
        parts.push(short)
      }
      if (duration) parts.push(duration)
      if (parts.length === 0) parts.push(formatSize(input.size))
      return parts.join(' · ')
    case 'music':
      if (input.artist) parts.push(input.artist)
      if (input.album) parts.push(input.album)
      if (duration) parts.push(duration)
      if (parts.length === 0) parts.push(input.ext.replace('.', '').toUpperCase())
      return parts.join(' · ')
    case 'novel':
    case 'comic':
      if (input.artist) parts.push(input.artist)
      parts.push(input.ext.replace('.', '').toUpperCase())
      parts.push(formatSize(input.size))
      return parts.join(' · ')
    case 'image':
    case 'wallpaper':
      if (resolution) parts.push(resolution)
      parts.push(input.ext.replace('.', '').toUpperCase())
      if (parts.length <= 1) parts.push(formatSize(input.size))
      return parts.join(' · ')
    case 'archive':
      parts.push(input.innerKind === 'video' ? '影视资源压缩包' : input.ext.replace('.', '').toUpperCase())
      parts.push(formatSize(input.size))
      return parts.join(' · ')
    case 'installer':
      parts.push('安装包')
      parts.push(formatSize(input.size))
      return parts.join(' · ')
    case 'software':
      parts.push('软件')
      parts.push(formatSize(input.size))
      return parts.join(' · ')
    case 'document':
      parts.push(input.ext.replace('.', '').toUpperCase())
      parts.push(formatSize(input.size))
      return parts.join(' · ')
    default:
      return parts.length > 0 ? parts.join(' · ') : formatSize(input.size)
  }
}
