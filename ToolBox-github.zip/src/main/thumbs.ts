import { nativeImage } from 'electron'
import crypto from 'node:crypto'
import fsp from 'node:fs/promises'
import path from 'node:path'
import type { ResourceKind } from '@shared/types'
import { kvGet, kvSet, resetThumbState } from './db'
import { findSidecarCover, readAudioTags, readEpubMeta, readZipEntry, readZipEntries } from './mediainfo'
import { cleanupWorkerTemp, prepareShellWorker, runShellThumbnails } from './shell-worker'

/**
 * 缩略图调度：
 * 1. 图片/壁纸 → nativeImage 直接缩放
 * 2. 音乐 → 内嵌封面（ID3/FLAC/MP4 标签），没有就交给系统
 * 3. EPUB / CBZ → 包内封面 / 首页图片
 * 4. 视频 / PDF / 其它 → Windows Shell 缩略图（视频首帧、PDF 首页）
 * 全部结果落盘缓存，键 = 路径 + 修改时间，重启不重算。
 */

const THUMB_SIZE = 512
/** 高分辨率图标（exe 程序图标 / 压缩包关联图标）：256 比 app.getFileIcon 的 48 清晰得多 */
const ICON_SIZE = 256
/**
 * 多尺寸缓存（Phase 8）：
 *   card   —— 网格卡片用，256px：滚动更省内存、更快
 *   detail —— 详情抽屉用，1024px：放大也清楚
 *   icon   —— 程序/压缩包图标，256px
 * 每个尺寸各自一个子目录，按需生成。
 */
export type ThumbSizeName = 'card' | 'detail' | 'icon'
export const THUMB_SIZES: Record<ThumbSizeName, number> = { card: 256, detail: 1024, icon: ICON_SIZE }
/** 这些类型没有系统缩略图，直接用高分辨率图标 */
const ICON_FIRST_KINDS: ResourceKind[] = ['installer', 'software', 'archive', 'other']
const MAX_CACHE_FILES = 20000

/**
 * 缩略图生成管线版本。
 * 升级这个数字 = 清空缩略图缓存文件 + 重置索引状态，下次扫描全部重算。
 * v1：Shell 缩略图 + 图片缩放
 * v2：安装包/压缩包改用 256px 高分辨率图标
 * v3：改用 WPF 转换保留 alpha（图标透明底不再变黑）
 * v4：worker 脚本改用 UTF-8 BOM 写入（PowerShell 5.1 中文注释解析）
 * v5：修复上一条并把安装包/压缩包图标重新生成为 256px RGBA
 * v6：EPUB 封面提取重写（4 级回退），小说/漫画封面要重新提取
 * v7：多尺寸缓存（card 256 / detail 1024），缓存目录按尺寸分子目录
 */
const THUMB_PIPELINE_VERSION = 7

let cacheDir = ''
let ready = false
const memory = new Map<string, string | null>()

function sizeDir(name: ThumbSizeName): string {
  return path.join(cacheDir, name)
}

export async function initThumbs(dataDir: string): Promise<void> {
  cacheDir = path.join(dataDir, 'thumbnails')
  await fsp.mkdir(cacheDir, { recursive: true })
  for (const name of Object.keys(THUMB_SIZES) as ThumbSizeName[]) {
    await fsp.mkdir(sizeDir(name), { recursive: true })
  }
  await prepareShellWorker(dataDir)

  // 管线版本变化：清空缓存文件 + 重置索引里的缩略图状态，避免继续用旧图
  const storedVersion = kvGet('thumbVersion')
  if (storedVersion !== String(THUMB_PIPELINE_VERSION)) {
    try {
      await fsp.rm(cacheDir, { recursive: true, force: true })
    } catch {
      /* ignore */
    }
    for (const name of Object.keys(THUMB_SIZES) as ThumbSizeName[]) {
      await fsp.mkdir(sizeDir(name), { recursive: true })
    }
    resetThumbState()
    kvSet('thumbVersion', String(THUMB_PIPELINE_VERSION))
  }

  ready = true
  void sweepCache()
}

/* ---------------- Phase 8：缓存统计与清理 ---------------- */

export interface ThumbCacheStats {
  files: number
  bytes: number
  bySize: Record<string, { files: number; bytes: number }>
}

export async function thumbCacheStats(): Promise<ThumbCacheStats> {
  const result: ThumbCacheStats = { files: 0, bytes: 0, bySize: {} }
  for (const name of Object.keys(THUMB_SIZES) as ThumbSizeName[]) {
    let files = 0
    let bytes = 0
    try {
      for (const entry of await fsp.readdir(sizeDir(name), { withFileTypes: true })) {
        if (!entry.isFile()) continue
        const stat = await fsp.stat(path.join(sizeDir(name), entry.name)).catch(() => null)
        files++
        bytes += stat?.size ?? 0
      }
    } catch {
      /* ignore */
    }
    result.bySize[name] = { files, bytes }
    result.files += files
    result.bytes += bytes
  }
  return result
}

/** 清空缩略图缓存（文件 + 索引状态），之后浏览时按需重建 */
export async function clearThumbs(): Promise<{ removed: number; freedBytes: number }> {
  const before = await thumbCacheStats()
  for (const name of Object.keys(THUMB_SIZES) as ThumbSizeName[]) {
    try {
      await fsp.rm(sizeDir(name), { recursive: true, force: true })
    } catch {
      /* ignore */
    }
    await fsp.mkdir(sizeDir(name), { recursive: true })
  }
  memory.clear()
  resetThumbState()
  return { removed: before.files, freedBytes: before.bytes }
}

export function thumbCacheDir(): string {
  return cacheDir
}

function cacheKey(absPath: string, mtimeMs: number): string {
  return crypto.createHash('sha1').update(`${absPath.toLowerCase()}|${Math.round(mtimeMs)}`).digest('hex')
}

async function exists(file: string): Promise<boolean> {
  try {
    await fsp.access(file)
    return true
  } catch {
    return false
  }
}

/** 缓存文件太多时清掉最旧的一半（各尺寸目录一起算） */
async function sweepCache(): Promise<void> {
  try {
    const entries: { full: string; atime: number }[] = []
    for (const name of Object.keys(THUMB_SIZES) as ThumbSizeName[]) {
      for (const file of await fsp.readdir(sizeDir(name))) {
        const full = path.join(sizeDir(name), file)
        const stat = await fsp.stat(full).catch(() => null)
        entries.push({ full, atime: stat?.atimeMs ?? 0 })
      }
    }
    if (entries.length <= MAX_CACHE_FILES) return
    entries.sort((a, b) => a.atime - b.atime)
    for (const item of entries.slice(0, Math.floor(entries.length / 2))) {
      await fsp.rm(item.full, { force: true }).catch(() => undefined)
    }
  } catch {
    /* ignore */
  }
}

async function writePng(target: string, data: Buffer): Promise<boolean> {
  try {
    await fsp.mkdir(path.dirname(target), { recursive: true })
    await fsp.writeFile(target, data)
    return true
  } catch {
    return false
  }
}

function resizeToPng(image: Electron.NativeImage, size = THUMB_SIZE): Buffer | null {
  if (image.isEmpty()) return null
  const { width, height } = image.getSize()
  if (!width || !height) return null
  const longest = Math.max(width, height)
  const scale = longest > size ? size / longest : 1
  const resized =
    scale < 1
      ? image.resize({
          width: Math.max(1, Math.round(width * scale)),
          height: Math.max(1, Math.round(height * scale)),
          quality: 'good'
        })
      : image
  return (resized.isEmpty() ? image : resized).toPNG()
}

/* ---------------- Shell 批量队列（缩略图 / 高分辨率图标 两条通道） ---------------- */

interface ShellTask {
  /** 等待者键（同一资源的两条通道要区分） */
  waitKey: string
  /** 缓存文件名键（每个资源只有一份缓存） */
  cacheKey: string
  absPath: string
}

interface ShellLane {
  queue: ShellTask[]
  waiters: Map<string, ((value: string | null) => void)[]>
  timer: NodeJS.Timeout | null
  flushing: boolean
  size: number
  iconOnly: boolean
  /** 结果落到哪个尺寸目录 */
  sizeName: ThumbSizeName
}

let activeWorkers = 0
const MAX_WORKERS = 2

function makeLane(size: number, iconOnly: boolean, sizeName: ThumbSizeName): ShellLane {
  return { queue: [], waiters: new Map(), timer: null, flushing: false, size, iconOnly, sizeName }
}

const cardLane = makeLane(THUMB_SIZES.card, false, 'card')
const detailLane = makeLane(THUMB_SIZES.detail, false, 'detail')
const iconLane = makeLane(ICON_SIZE, true, 'icon')

function laneFor(sizeName: ThumbSizeName): ShellLane {
  if (sizeName === 'icon') return iconLane
  return sizeName === 'detail' ? detailLane : cardLane
}

function queueShell(lane: ShellLane, waitKey: string, cacheKey: string, absPath: string): Promise<string | null> {
  return new Promise((resolve) => {
    const list = lane.waiters.get(waitKey) ?? []
    list.push(resolve)
    lane.waiters.set(waitKey, list)
    lane.queue.push({ waitKey, cacheKey, absPath })
    if (lane.queue.length >= 16) {
      void flushLane(lane)
      return
    }
    if (!lane.timer) {
      lane.timer = setTimeout(() => void flushLane(lane), 150)
    }
  })
}

function settleLane(lane: ShellLane, task: ShellTask, value: string | null): void {
  const waiters = lane.waiters.get(task.waitKey) ?? []
  lane.waiters.delete(task.waitKey)
  memory.set(task.cacheKey, value)
  for (const resolve of waiters) resolve(value)
}

async function flushLane(lane: ShellLane): Promise<void> {
  if (lane.timer) {
    clearTimeout(lane.timer)
    lane.timer = null
  }
  if (lane.flushing || activeWorkers >= MAX_WORKERS || lane.queue.length === 0) return
  lane.flushing = true
  const batch = lane.queue.splice(0, Math.min(16, lane.queue.length))
  activeWorkers++
  try {
    const results = await runShellThumbnails(
      batch.map((task, index) => ({ id: String(index), path: task.absPath })),
      lane.size,
      lane.iconOnly
    )
    for (const result of results) {
      const task = batch[Number(result.id)]
      if (!task) continue
      let value: string | null = null
      if (result.ok && result.file) {
        const target = path.join(sizeDir(lane.sizeName), `${task.cacheKey}.png`)
        try {
          await fsp.mkdir(sizeDir(lane.sizeName), { recursive: true })
          await fsp.copyFile(result.file, target)
          await fsp.rm(result.file, { force: true })
          value = target
        } catch {
          value = null
        }
      }
      settleLane(lane, task, value)
    }
  } catch {
    for (const task of batch) settleLane(lane, task, null)
  } finally {
    activeWorkers--
    lane.flushing = false
    if (lane.queue.length > 0) setTimeout(() => void flushLane(lane), 10)
  }
}

/* ---------------- 单张缩略图 ---------------- */

async function generateThumbnail(
  absPath: string,
  kind: ResourceKind,
  ext: string,
  key: string,
  sizeName: ThumbSizeName
): Promise<string | null> {
  const target = path.join(sizeDir(sizeName), `${key}.png`)
  const size = THUMB_SIZES[sizeName]

  // 1. 图片 / 壁纸 / 散图漫画页：直接解码缩放
  if (kind === 'image' || kind === 'wallpaper' || (kind === 'comic' && /\.(jpe?g|png|webp|gif|bmp)$/i.test(ext))) {
    const image = nativeImage.createFromPath(absPath)
    const png = resizeToPng(image, size)
    if (png && (await writePng(target, png))) return target
  }

  // 2. 音乐：优先用内嵌封面
  if (kind === 'music') {
    try {
      const tags = await readAudioTags(absPath, ext)
      if (tags.coverData && tags.coverData.length > 0) {
        const image = nativeImage.createFromBuffer(tags.coverData)
        const png = resizeToPng(image, size)
        if (png && (await writePng(target, png))) return target
      }
    } catch {
      /* 交给系统缩略图 */
    }
  }

  // 3. EPUB / CBZ：包内封面
  //    漫画优先用"同目录本地封面"（cover.jpg / folder.jpg / 0.jpg…），其次才是包内首图
  if (kind === 'comic' || ext === '.cbz' || ext === '.cb7') {
    try {
      const sidecar = await findSidecarCover(absPath)
      if (sidecar) {
        const png = resizeToPng(nativeImage.createFromPath(sidecar), size)
        if (png && (await writePng(target, png))) return target
      }
    } catch {
      /* 继续尝试包内首图 */
    }
  }
  if (ext === '.epub') {
    try {
      const meta = await readEpubMeta(absPath)
      if (meta.coverData) {
        const image = nativeImage.createFromBuffer(meta.coverData)
        const png = resizeToPng(image, size)
        if (png && (await writePng(target, png))) return target
      }
    } catch {
      /* ignore */
    }
  }
  if (ext === '.cbz' || ext === '.zip') {
    try {
      const entries = await readZipEntries(absPath, 200)
      const firstImage = entries.find((entry) =>
        /\.(jpe?g|png|webp|gif|bmp)$/i.test(entry.name) && !entry.name.startsWith('__MACOSX')
      )
      if (firstImage) {
        const data = await readZipEntry(absPath, firstImage.name)
        if (data && data.length > 0) {
          const image = nativeImage.createFromBuffer(data)
          const png = resizeToPng(image, size)
          if (png && (await writePng(target, png))) return target
        }
      }
    } catch {
      /* ignore */
    }
  }

  // 4. Windows Shell：先按类型选通道
  //    安装包/压缩包/其它 → 直接取高分辨率图标（256px），避免 48px 图标被放大变糊
  //    影视/文档/音乐 → 先取真实缩略图（视频首帧 / PDF 首页 / 封面），失败再退回高分辨率图标
  if (!ready) return null
  const preferIcon = ICON_FIRST_KINDS.includes(kind)
  const lane = laneFor(sizeName)
  if (preferIcon) {
    const icon = await queueShell(iconLane, `${key}|icon`, key, absPath)
    if (icon) return icon
    return await queueShell(lane, `${key}|${sizeName}`, key, absPath)
  }
  const thumb = await queueShell(lane, `${key}|${sizeName}`, key, absPath)
  if (thumb) return thumb
  return await queueShell(iconLane, `${key}|icon`, key, absPath)
}

export interface ThumbRequestItem {
  path: string
  mtimeMs: number
  kind: ResourceKind
  ext: string
}

/** 取（必要时生成）缩略图的缓存文件路径；null 表示没有缩略图 */
export async function getThumbnail(item: ThumbRequestItem, sizeName: ThumbSizeName = 'card'): Promise<string | null> {
  if (!ready) return null
  const key = cacheKey(item.path, item.mtimeMs)
  const memoryKey = `${sizeName}:${key}`
  if (memory.has(memoryKey)) return memory.get(memoryKey) ?? null
  const target = path.join(sizeDir(sizeName), `${key}.png`)
  if (await exists(target)) {
    memory.set(memoryKey, target)
    return target
  }
  const produced = await generateThumbnail(item.path, item.kind, item.ext, key, sizeName)
  // 生成失败时退一步用别的尺寸（例如 icon 通道成的图），保证界面一定显示得出来
  if (!produced && sizeName !== 'card') {
    const fallback = path.join(sizeDir('card'), `${key}.png`)
    if (await exists(fallback)) {
      memory.set(memoryKey, fallback)
      return fallback
    }
  }
  memory.set(memoryKey, produced)
  return produced
}

/** 后台批量预热（扫描完成后按需生成） */
export async function warmThumbnails(items: ThumbRequestItem[], concurrency = 2): Promise<number> {
  let done = 0
  const queue = [...items]
  const workers = Array.from({ length: Math.min(concurrency, queue.length) }, async () => {
    for (;;) {
      const item = queue.shift()
      if (!item) return
      const result = await getThumbnail(item).catch(() => null)
      if (result) done++
    }
  })
  await Promise.all(workers)
  return done
}

export async function shutdownThumbs(): Promise<void> {
  await cleanupWorkerTemp()
  memory.clear()
  ready = false
}

/** 供冒烟自检使用 */
export function thumbsReady(): boolean {
  return ready
}

export const THUMBNAIL_SIZE = THUMB_SIZE
export { THUMB_PIPELINE_VERSION }
