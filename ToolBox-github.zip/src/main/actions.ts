import { clipboard, dialog, shell } from 'electron'
import { spawn } from 'node:child_process'
import fsSync from 'node:fs'
import fsp from 'node:fs/promises'
import path from 'node:path'
import { extOf, isExecutableExt } from '@shared/resource-kinds'
import type { BackgroundPickResult, OperationResult } from '@shared/types'
import { configDir, configStore } from './config'

function errText(err: unknown): string {
  return err instanceof Error ? err.message : String(err)
}

/** 确认框记录键：路径 + 大小 + 修改时间，文件变了会重新询问 */
function approvalKey(filePath: string, size: number, mtimeMs: number): string {
  return `${filePath}|${size}|${Math.round(mtimeMs)}`
}

/** 运行本地程序前的确认（可在配置里关闭；勾选“不再询问”后记住该文件） */
export async function confirmExecutable(filePath: string): Promise<OperationResult> {
  const config = configStore.all()
  const ext = extOf(path.basename(filePath))
  if (!isExecutableExt(ext)) return { ok: true }
  if (!config.confirmExecutables) return { ok: true }

  let size = 0
  let mtimeMs = 0
  try {
    const stat = await fsp.stat(filePath)
    size = stat.size
    mtimeMs = stat.mtimeMs
  } catch {
    /* 拿不到就仍然询问 */
  }
  const key = approvalKey(filePath, size, mtimeMs)
  if (config.approvedPrograms.includes(key)) return { ok: true }

  const { response, checkboxChecked } = await dialog.showMessageBox({
    type: 'warning',
    title: '运行本地程序',
    message: `即将运行本地程序：\n${path.basename(filePath)}`,
    detail: `路径：${filePath}\n\n工具箱只运行你自己放进资源目录的文件，不会自动提权。如果该程序需要管理员权限，Windows 会正常弹出 UAC 提示。`,
    buttons: ['继续', '取消'],
    defaultId: 1,
    cancelId: 1,
    noLink: true,
    checkboxLabel: '不再询问此文件',
    checkboxChecked: false
  })

  if (response !== 0) return { ok: false, error: '已取消' }
  if (checkboxChecked) {
    const list = [...config.approvedPrograms, key].slice(-200)
    configStore.patch({ approvedPrograms: list })
  }
  return { ok: true }
}

/** 双击的默认动作：文件夹 / exe / msi / ps1 / 其它交给系统默认关联程序 */
export async function openTarget(filePath: string): Promise<OperationResult> {
  try {
    const stat = await fsp.stat(filePath)
    if (stat.isDirectory()) {
      const err = await shell.openPath(filePath)
      return err ? { ok: false, error: err } : { ok: true, path: filePath, message: `已打开文件夹 ${path.basename(filePath)}` }
    }

    const ext = extOf(path.basename(filePath))
    if (ext === '.msi') {
      spawn('msiexec.exe', ['/i', filePath], { detached: true, stdio: 'ignore' }).unref()
      return { ok: true, path: filePath, message: `已启动 Windows Installer：${path.basename(filePath)}` }
    }
    if (ext === '.ps1') {
      spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', filePath], {
        detached: true,
        stdio: 'ignore',
        cwd: path.dirname(filePath)
      }).unref()
      return { ok: true, path: filePath, message: `已在 PowerShell 中运行：${path.basename(filePath)}` }
    }

    // 视频 / 音乐 / 小说 / 压缩包 / exe：全部交给 Windows 默认关联程序
    const err = await shell.openPath(filePath)
    return err ? { ok: false, error: err } : { ok: true, path: filePath, message: `已打开：${path.basename(filePath)}` }
  } catch (err) {
    return { ok: false, error: `打开失败：${errText(err)}` }
  }
}

export async function revealTarget(filePath: string): Promise<OperationResult> {
  try {
    shell.showItemInFolder(filePath)
    return { ok: true, message: '已在资源管理器中定位' }
  } catch (err) {
    return { ok: false, error: `无法打开所在文件夹：${errText(err)}` }
  }
}

export function copyPath(filePath: string): OperationResult {
  try {
    clipboard.writeText(filePath)
    return { ok: true, message: '路径已复制到剪贴板' }
  } catch (err) {
    return { ok: false, error: `复制失败：${errText(err)}` }
  }
}

export async function renameTarget(filePath: string, newName: string): Promise<OperationResult> {
  const trimmed = (newName ?? '').trim()
  if (!trimmed) return { ok: false, error: '名称不能为空' }
  if (trimmed === '.' || trimmed === '..') return { ok: false, error: '名称无效' }
  if (/[\\/:*?"<>|]/.test(trimmed)) return { ok: false, error: '名称不能包含 \\ / : * ? " < > | 这些字符' }
  if (trimmed.length > 200) return { ok: false, error: '名称太长' }

  const target = path.join(path.dirname(filePath), trimmed)
  if (target.toLowerCase() === filePath.toLowerCase()) return { ok: true, path: filePath }
  if (fsSync.existsSync(target)) return { ok: false, error: `已存在同名项目：${trimmed}` }

  try {
    await fsp.rename(filePath, target)
    return { ok: true, path: target, message: `已重命名为 ${trimmed}` }
  } catch (err) {
    return { ok: false, error: `重命名失败：${errText(err)}` }
  }
}

/** 删除：默认进回收站（可由用户从回收站还原），永久删除需要再确认一次 */
export async function deleteTarget(filePath: string, permanent: boolean): Promise<OperationResult> {
  const name = path.basename(filePath)
  const { response } = await dialog.showMessageBox({
    type: 'warning',
    title: permanent ? '永久删除' : '删除到回收站',
    message: permanent ? `确定要永久删除吗？\n${name}` : `确定要删除到回收站吗？\n${name}`,
    detail: permanent ? '此操作不可恢复。' : '文件会进入 Windows 回收站，可以随时还原。',
    buttons: ['删除', '取消'],
    defaultId: 1,
    cancelId: 1,
    noLink: true
  })
  if (response !== 0) return { ok: false, error: '已取消' }

  try {
    if (permanent) {
      await fsp.rm(filePath, { recursive: true, force: true })
      return { ok: true, message: `已永久删除 ${name}` }
    }
    await shell.trashItem(filePath)
    return { ok: true, message: `已把 ${name} 移入回收站` }
  } catch (err) {
    return { ok: false, error: `删除失败：${errText(err)}` }
  }
}

/** 选择工具箱背景图：复制到 config/backgrounds/ 保证绿色便携 */
export async function pickBackground(): Promise<BackgroundPickResult> {
  const { canceled, filePaths } = await dialog.showOpenDialog({
    title: '选择工具箱背景图片',
    properties: ['openFile'],
    filters: [
      { name: '图片', extensions: ['jpg', 'jpeg', 'png', 'webp', 'bmp', 'gif', 'jfif', 'avif', 'tif', 'tiff'] },
      { name: '所有文件', extensions: ['*'] }
    ]
  })
  if (canceled || filePaths.length === 0) return { ok: false, canceled: true }

  const source = filePaths[0]
  const ext = extOf(path.basename(source)) || '.png'
  const dir = path.join(configDir(), 'backgrounds')
  try {
    await fsp.mkdir(dir, { recursive: true })
    const dest = path.join(dir, `bg${ext}`)
    await fsp.copyFile(source, dest)
    for (const file of await fsp.readdir(dir)) {
      const full = path.join(dir, file)
      if (file.startsWith('bg') && full !== dest) await fsp.rm(full, { force: true })
    }
    const config = configStore.setBackground(dest)
    return { ok: true, config }
  } catch (err) {
    return { ok: false, error: `设置背景失败：${errText(err)}` }
  }
}

/** 恢复内置蓝色渐变背景 */
export async function resetBackground(): Promise<BackgroundPickResult> {
  try {
    const dir = path.join(configDir(), 'backgrounds')
    if (fsSync.existsSync(dir)) {
      for (const file of await fsp.readdir(dir)) {
        if (file.startsWith('bg')) await fsp.rm(path.join(dir, file), { force: true })
      }
    }
    const config = configStore.setBackground('')
    return { ok: true, config }
  } catch (err) {
    return { ok: false, error: `恢复默认背景失败：${errText(err)}` }
  }
}

/** 更换资源根目录（默认 = 程序所在目录） */
export async function pickResourceRoot(): Promise<BackgroundPickResult> {
  const { canceled, filePaths } = await dialog.showOpenDialog({
    title: '选择仓库目录（其中的一级文件夹会成为左侧分类）',
    properties: ['openDirectory']
  })
  if (canceled || filePaths.length === 0) return { ok: false, canceled: true }
  const config = configStore.patch({ resourceRoot: filePaths[0] })
  return { ok: true, config }
}
