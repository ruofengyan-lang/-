import crypto from 'node:crypto'
import type { Dirent } from 'node:fs'
import fs from 'node:fs/promises'
import { createReadStream } from 'node:fs'
import path from 'node:path'
import { nativeImage } from 'electron'
import { formatSize, formatDuration } from '@shared/format'
import { baseNameOf, extOf, WORK_KINDS } from '@shared/resource-kinds'
import type { KindCount, Library, ResourceKind, ScanOptions, ScanProgress } from '@shared/types'
import { classify, makeCardLine, makeSeriesKey, parseAlbum, parseSeries, pageNumberOf, COMIC_HINT_RE } from './classifier'
import * as metadata from './metadata'
import { configDir, dataDir, appRoot } from './config'
import * as db from './db'
import {
  guessZipContent,
  readAudioTags,
  readEpubMeta,
  readImageSize,
  readVideoInfo,
  readZipEntry,
  readZipEntries
} from './mediainfo'
import { isHiddenName, isNoiseFile, shouldSkipDir } from './scan-paths'
import { getThumbnail, warmThumbnails } from './thumbs'

interface DirStats {
  files: number
  dlls: number
  exes: number
}

const METADATA_LIMIT_PER_RUN = 1200
const THUMB_WARM_LIMIT_PER_RUN = 600
const HASH_ROUND_LIMIT = 12

let scanning = false
let paused = false
let cancelled = false
let progress: ScanProgress | null = null
let progressHandlers: ((p: ScanProgress) => void)[] = []
let changedHandlers: (() => void)[] = []
let lastEmit = 0

export function onScanProgress(handler: (p: ScanProgress) => void): void {
  progressHandlers.push(handler)
}
export function onIndexChanged(handler: () => void): void {
  changedHandlers.push(handler)
}
export function isScanning(): boolean {
  return scanning
}
export function isPaused(): boolean {
  return paused
}
export function currentProgress(): ScanProgress | null {
  return progress
}

function emitProgress(force = false): void {
  if (!progress) return
  const now = Date.now()
  if (!force && now - lastEmit < 120) return
  lastEmit = now
  const snapshot: ScanProgress = { ...progress, counts: [...progress.counts] }
  for (const handler of progressHandlers) {
    try {
      handler(snapshot)
    } catch {
      /* ignore */
    }
  }
}

function notifyChanged(): void {
  for (const handler of changedHandlers) {
    try {
      handler()
    } catch {
      /* ignore */
    }
  }
}

async function waitWhilePaused(): Promise<void> {
  while (paused && !cancelled) {
    await new Promise((resolve) => setTimeout(resolve, 200))
  }
}

function bumpCount(kind: ResourceKind): void {
  if (!progress) return
  const found = progress.counts.find((c) => c.kind === kind)
  if (found) found.count++
  else progress.counts.push({ kind, count: 1 })
}

/** 程序自己的 config / data 目录永远不参与索引 */
function isOwnDirectory(absPath: string): boolean {
  const target = path.resolve(absPath).toLowerCase()
  return [configDir(), dataDir()].some((own) => {
    const base = path.resolve(own).toLowerCase()
    return target === base || target.startsWith(`${base}${path.sep}`)
  })
}

/** 部署在资源目录里的程序自身文件（ToolBox.exe / 使用说明.txt）也不索引 */
function isOwnFile(absPath: string): boolean {
  const target = path.resolve(absPath).toLowerCase()
  const root = path.resolve(appRoot()).toLowerCase()
  return ['toolbox.exe', '使用说明.txt', 'readme.txt', 'uninstall toolbox.exe'].some(
    (name) => target === path.join(root, name).toLowerCase()
  )
}

/** 遍历目录树；onFile 在扫描阶段调用，onCounted 在统计阶段调用 */
async function walkDirectory(
  dir: string,
  relDir: string,
  depth: number,
  options: ScanOptions,
  hooks: {
    onCounted?: (absPath: string) => void
    onFile?: (absPath: string, relDir: string, stats: DirStats, name: string) => Promise<void>
  }
): Promise<void> {
  if (cancelled) return
  if (isOwnDirectory(dir)) return
  if (options.maxDepth > 0 && depth > options.maxDepth) return
  let entries: Dirent[]
  try {
    entries = await fs.readdir(dir, { withFileTypes: true })
  } catch {
    return
  }
  const stats: DirStats = { files: 0, dlls: 0, exes: 0 }
  const files: string[] = []
  const subdirs: { name: string; abs: string }[] = []

  for (const entry of entries) {
    if (entry.isSymbolicLink()) continue
    const abs = path.join(dir, entry.name)
    if (entry.isDirectory()) {
      if (!shouldSkipDir(entry.name, abs, options.includeHidden) && !isOwnDirectory(abs)) {
        subdirs.push({ name: entry.name, abs })
      }
      continue
    }
    if (!entry.isFile()) continue
    if (isNoiseFile(entry.name)) continue
    if (isOwnFile(abs)) continue
    if (!options.includeHidden && isHiddenName(entry.name)) continue
    stats.files++
    const ext = extOf(entry.name)
    if (ext === '.dll') stats.dlls++
    else if (ext === '.exe') stats.exes++
    files.push(entry.name)
  }

  for (const name of files) {
    if (cancelled) return
    const abs = path.join(dir, name)
    hooks.onCounted?.(abs)
    if (hooks.onFile) {
      await waitWhilePaused()
      if (cancelled) return
      await hooks.onFile(abs, relDir, stats, name)
    }
  }

  for (const sub of subdirs) {
    if (cancelled) return
    const childRel = relDir ? `${relDir}\\${sub.name}` : sub.name
    await walkDirectory(sub.abs, childRel, depth + 1, options, hooks)
  }
}

function startProgress(library: Library, phase: string): void {
  progress = {
    libraryId: library.id,
    libraryPath: library.path,
    phase,
    scanned: 0,
    total: 0,
    current: '',
    counts: [],
    startedAt: Date.now(),
    finishedAt: 0,
    error: ''
  }
  emitProgress(true)
}

/** 扫描一个资源库 */
async function scanLibrary(library: Library, options: ScanOptions): Promise<void> {
  const token = db.nextScanToken(library.id)
  startProgress(library, 'counting')

  // 第一遍：只统计数量，用于进度显示
  await walkDirectory(library.path, '', 1, options, {
    onCounted: () => {
      if (progress) progress.total++
    }
  })
  if (cancelled) return

  // 第二遍：真正入库
  if (progress) {
    progress.phase = 'scanning'
    progress.current = library.path
  }
  emitProgress(true)

  await walkDirectory(library.path, '', 1, options, {
    onFile: async (abs, relDir, stats, name) => {
      try {
        const stat = await fs.stat(abs)
        const ext = extOf(name)
        const result = classify({
          name,
          relDir,
          siblingFileCount: stats.files,
          siblingDllCount: stats.dlls,
          siblingExeCount: stats.exes
        })
        const before = db.getResourceByPath(abs)
        // 作品归属：漫画/小说/影视在扫描阶段就能定；
        // 音乐的作品是专辑，要等读到标签后才能归组（见 enrichMetadata）。
        const aggregated = WORK_KINDS.includes(result.kind) && result.kind !== 'music'
        const series = aggregated ? parseSeries(name, result.kind) : null
        const inserted = db.upsertResource({
          path: abs,
          libraryId: library.id,
          relDir,
          name,
          ext,
          kind: result.kind,
          autoKind: result.kind,
          size: stat.size,
          mtime: stat.mtimeMs,
          ctime: stat.birthtimeMs || stat.ctimeMs,
          scanToken: token,
          seriesKey: series?.seriesKey ?? '',
          seriesTitle: series?.seriesTitle ?? '',
          volume: series?.volume ?? 0
        })
        // 新记录或无元数据的老记录：先给一个基础卡片文案
        if (!before || before.cardLine === '') {
          const item = db.getResourceById(inserted.id)
          if (item) {
            db.updateResourceMeta(inserted.id, {
              cardLine: makeCardLine({
                kind: item.kind,
                ext,
                size: stat.size,
                width: item.width,
                height: item.height,
                durationMs: item.durationMs,
                year: item.year,
                artist: item.artist,
                album: item.album
              }),
              meta: { autoReason: result.reason }
            })
          }
        }
        if (progress) {
          progress.scanned++
          progress.current = abs
          bumpCount(before ? before.kind : result.kind)
        }
        emitProgress()
      } catch {
        /* 单个文件失败就跳过 */
      }
    }
  })

  if (cancelled) return

  // 收尾：删除索引里已经不存在的记录
  if (progress) progress.phase = 'indexing'
  emitProgress(true)
  db.finishLibraryScan(library.id, token)
  notifyChanged()

  // 元数据
  if (options.readMetadata) {
    await enrichMetadata(library.id, options)
  }
  if (cancelled) return

  // 缩略图预热
  if (options.generateThumbnails) {
    await warmLibraryThumbnails(library.id)
  }
  if (cancelled) return
}

/** 读取媒体元数据（标签 / 容器宽高时长 / 压缩包内容判定） */
async function enrichMetadata(libraryId: number, options: ScanOptions): Promise<void> {
  if (progress) progress.phase = 'metadata'
  emitProgress(true)
  let processed = 0
  for (let round = 0; round < 6; round++) {
    const candidates = db.pendingMetaCandidates(libraryId, 200)
    if (candidates.length === 0) break
    for (const item of candidates) {
      if (cancelled) return
      await waitWhilePaused()
      if (cancelled) return
      processed++
      if (processed > METADATA_LIMIT_PER_RUN) return
      try {
        let width = item.width
        let height = item.height
        let durationMs = item.durationMs
        let title = item.title
        let artist = item.artist
        let album = item.album
        let year = item.year
        let meta: Record<string, unknown> = { ...item.meta }
        const ext = item.ext
        // 内容判定可能改写类型与作品归属，这里记录下来供元数据填充使用
        let effectiveKind: ResourceKind | null = null
        let effectiveSeriesKey: string | null = null

        if (item.kind === 'music') {
          const tags = await readAudioTags(item.path, ext)
          title = title || tags.title
          artist = tags.artist || artist
          album = tags.album || album
          year = tags.year || year
          durationMs = durationMs || tags.durationMs
          if (!title) title = baseNameOf(item.name)
          // Phase 5：按专辑归组（一张专辑 = 一部作品），曲目号作为"卷号"用于排序
          const parsed = parseAlbum({
            name: item.name,
            artist: tags.artist || item.artist,
            album: tags.album || item.album,
            albumArtist: tags.albumArtist
          })
          if (parsed.seriesKey) {
            db.updateSeries(item.id, parsed.seriesKey, parsed.seriesTitle, tags.track || 0)
            effectiveKind = 'music'
            effectiveSeriesKey = parsed.seriesKey
          }
        } else if (['movie', 'tv', 'anime'].includes(item.kind)) {
          const info = await readVideoInfo(item.path, ext)
          width = info.width || width
          height = info.height || height
          durationMs = info.durationMs || durationMs
        } else if (item.kind === 'image' || item.kind === 'wallpaper') {
          const size = await readImageSize(item.path, ext)
          width = size.width || width
          height = size.height || height
        } else if (ext === '.epub') {
          const epub = await readEpubMeta(item.path)
          title = title || epub.title
          artist = epub.creator || artist
          meta = {
            ...meta,
            epubPages: epub.pages,
            epubImages: epub.imageCount,
            epubTextPerPage: epub.avgTextPerPage
          }
          // 图集式 EPUB（漫画常见：整页就是图，几乎没有文字）→ 归为漫画
          const imageBook = epub.imageCount >= 8 && epub.avgTextPerPage < 300 && epub.imgTags >= 3
          const hinted =
            /漫画|comic|manga|manhua/i.test(item.name) || /漫画|comic|manga|manhua/i.test(item.relDir ?? '')
          if ((imageBook || (hinted && epub.imageCount >= 3)) && !item.overridden && item.kind !== 'comic') {
            const series = parseSeries(item.name, 'comic')
            db.setAutoKind(item.id, 'comic', makeCardLine({ kind: 'comic', ext, size: item.size }))
            db.updateSeries(item.id, series.seriesKey, series.seriesTitle, series.volume)
            effectiveKind = 'comic'
            effectiveSeriesKey = series.seriesKey
            meta = {
              ...meta,
              comicReason: `EPUB 内容判定为漫画（${epub.imageCount} 张图 · 每页约 ${epub.avgTextPerPage} 字）`
            }
          } else if (item.kind === 'comic') {
            const series = parseSeries(item.name, 'comic')
            db.updateSeries(item.id, series.seriesKey, series.seriesTitle, series.volume)
          }
        } else if (['.zip', '.cbz', '.cb7', '.cbt'].includes(ext)) {
          const entries = await readZipEntries(item.path, 500)
          const guess = guessZipContent(entries)
          if (guess.kind) {
            meta = { ...meta, innerKind: guess.kind, innerSummary: guess.summary }
          }
          // 漫画综合判定：文件名/目录线索 + 包内图片占比 + 首图是否竖版
          const images = entries.filter((entry) => /\.(jpe?g|png|webp|gif|bmp|avif|tiff?)$/i.test(entry.name))
          const imageRatio = entries.length > 0 ? images.length / entries.length : 0
          let portrait = false
          if (images.length > 0) {
            const first = [...images].sort((a, b) =>
              a.name.localeCompare(b.name, 'zh-Hans-CN', { numeric: true })
            )[0]
            const data = await readZipEntry(item.path, first.name).catch(() => null)
            if (data && data.length > 0) {
              const image = nativeImage.createFromBuffer(data)
              if (!image.isEmpty()) {
                const size = image.getSize()
                portrait = size.height > size.width
              }
            }
          }
          const nameHint = /漫画|comic|manga|manhua|卷|vol\.?\s*\d|第\s*\d+\s*[话話卷]/i.test(item.name)
          const dirHint = /漫画|comic|manga|manhua/i.test(item.relDir ?? '')
          const contentLooksComic = imageRatio >= 0.6 && entries.length >= 5 && portrait
          const comicEvidence = imageRatio >= 0.5 && (contentLooksComic || nameHint || dirHint)
          meta = {
            ...meta,
            comicCheck: `图片 ${images.length}/${entries.length}（${Math.round(imageRatio * 100)}%）${
              portrait ? ' · 首图竖版' : ''
            }`
          }
          if (comicEvidence && !item.overridden && item.kind !== 'comic') {
            const series = parseSeries(item.name, 'comic')
            db.setAutoKind(item.id, 'comic', makeCardLine({ kind: 'comic', ext, size: item.size }))
            db.updateSeries(item.id, series.seriesKey, series.seriesTitle, series.volume)
            effectiveKind = 'comic'
            effectiveSeriesKey = series.seriesKey
            meta = { ...meta, comicReason: `内容判定为漫画（${series.reason}）` }
          } else if (item.kind === 'comic') {
            const series = parseSeries(item.name, 'comic')
            db.updateSeries(item.id, series.seriesKey, series.seriesTitle, series.volume)
          }
        } else if (item.kind === 'comic') {
          const series = parseSeries(item.name, 'comic')
          db.updateSeries(item.id, series.seriesKey, series.seriesTitle, series.volume)
        }
        const bitrate = durationMs > 0 ? Math.round((item.size * 8) / (durationMs / 1000)) : 0
        const innerKind = typeof meta.innerKind === 'string' ? meta.innerKind : ''
        db.updateResourceMeta(item.id, {
          width,
          height,
          durationMs,
          bitrate,
          title,
          artist,
          album,
          year,
          cardLine: makeCardLine({
            kind: item.kind,
            ext,
            size: item.size,
            width,
            height,
            durationMs,
            year,
            artist,
            album,
            innerKind
          }),
          meta: meta as Record<string, string | number | boolean | null>
        })
        db.markMetaState(item.id, 1)
        // Phase 3：把本地能读到的信息填进「作品元数据」（Provider 匹配结果优先，不会被覆盖）
        const seriesKey = effectiveSeriesKey ?? item.seriesKey
        if (seriesKey) {
          metadata.seedFromLocal({
            seriesKey,
            kind: (effectiveKind ?? item.kind) as ResourceKind,
            seriesTitle: item.seriesTitle || title || baseNameOf(item.name),
            localTitle: title,
            author: artist,
            year
          })
        }
      } catch {
        // 解析失败标记为已处理，避免每轮重复解析
        db.markMetaState(item.id, 1)
      }
      if (progress) progress.current = item.path
      emitProgress()
    }
  }
  void options
}

/** 后台生成缩略图（限量，避免首次扫描卡太久） */
async function warmLibraryThumbnails(libraryId: number): Promise<void> {
  if (progress) progress.phase = 'thumbnails'
  emitProgress(true)
  const candidates = db.pendingThumbCandidates(libraryId, THUMB_WARM_LIMIT_PER_RUN)
  if (candidates.length === 0) return
  let done = 0
  for (const item of candidates) {
    if (cancelled) return
    await waitWhilePaused()
    if (cancelled) return
    const file = await getThumbnail({
      path: item.path,
      mtimeMs: item.mtimeMs,
      kind: item.kind,
      ext: item.ext
    }).catch(() => null)
    db.updateThumbState(item.id, file ?? '', file ? 1 : -1)
    done++
    if (progress) progress.current = item.path
    if (done % 8 === 0) emitProgress()
  }
  emitProgress(true)
}

/** 上一次散图聚合的结果（自检用） */
let lastAggregate = { folders: 0, files: 0 }

export function lastAggregateResult(): { folders: number; files: number } {
  return lastAggregate
}

/**
 * 散图漫画目录聚合（Phase 6）：
 * 路径里带漫画线索的目录，如果有 ≥5 张"页码式"图片，就把整个目录当成一部作品：
 * 图片改成 comic 类型 + 同一个 series_key，卷号 = 页码。
 * 这样 `漫画/xxx/001.jpg` 这种散图目录不会散成一堆图片，而是墙上的一部作品。
 * 保守起见：只在路径含 漫画/comic/manga/manhua 时生效，绝不误伤壁纸目录；用户手动改过类型的不动。
 */
async function aggregateComicFolders(): Promise<{ folders: number; files: number }> {
  const images = db.listLooseImages()
  const groups = new Map<
    string,
    { libraryId: number; relDir: string; pages: { id: number; name: string; page: number }[] }
  >()
  for (const row of images) {
    if (row.overridden === 1) continue
    if (!COMIC_HINT_RE.test(row.relDir)) continue
    if (!row.relDir) continue // 漫画库根目录下的散图不算一个作品，避免把根目录整个吞掉
    const key = `${row.libraryId}|${row.relDir}`
    const group = groups.get(key) ?? { libraryId: row.libraryId, relDir: row.relDir, pages: [] }
    group.pages.push({ id: row.id, name: row.name, page: pageNumberOf(row.name) })
    groups.set(key, group)
  }

  let folders = 0
  let files = 0
  for (const group of groups.values()) {
    if (group.pages.length < 5) continue
    // 目录名可能带卷号（漫画/海贼王 第01卷/）——用它给作品命名，卷号优先于页码
    const folderName = group.relDir.split('\\').filter(Boolean).pop() ?? group.relDir
    const parsed = parseSeries(`${folderName}.cbz`, 'comic')
    const seriesTitle = parsed.seriesTitle || folderName
    const seriesKey = makeSeriesKey(seriesTitle, 'comic')
    if (!seriesKey) continue
    for (const page of group.pages) {
      db.setAutoKind(page.id, 'comic', makeCardLine({ kind: 'comic', ext: '.jpg', size: 0 }))
      db.updateSeries(page.id, seriesKey, seriesTitle, parsed.volume > 0 ? parsed.volume : page.page)
    }
    folders++
    files += group.pages.length
  }
  return { folders, files }
}

/** 去重：先按大小初筛，再对同大小的文件计算 SHA-256 */
export async function runDeduplication(options: ScanOptions): Promise<number> {  if (!options.computeHash) return 0
  const maxBytes = Math.max(1, options.hashMaxSizeMB) * 1024 * 1024
  if (progress) {
    progress.phase = 'hashing'
    emitProgress(true)
  }
  let hashed = 0
  for (let round = 0; round < HASH_ROUND_LIMIT; round++) {
    const candidates = db.hashCandidates(maxBytes, 200)
    if (candidates.length === 0) break
    for (const item of candidates) {
      if (cancelled) return hashed
      await waitWhilePaused()
      if (cancelled) return hashed
      try {
        const hash = await hashFile(item.path)
        db.updateHash(item.id, hash, 1)
      } catch {
        db.updateHash(item.id, '', -1)
      }
      hashed++
      if (progress) {
        progress.scanned++
        progress.current = item.path
        emitProgress()
      }
    }
  }
  notifyChanged()
  return hashed
}

function hashFile(file: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256')
    const stream = createReadStream(file, { highWaterMark: 1024 * 1024 })
    stream.on('data', (chunk) => hash.update(chunk))
    stream.on('error', reject)
    stream.on('end', () => resolve(hash.digest('hex')))
  })
}

/** 扫描全部启用的资源库（或指定一个），完成后做去重 */
export async function scanLibraries(options: ScanOptions, libraryId?: number): Promise<void> {
  if (scanning) return
  scanning = true
  paused = false
  cancelled = false
  try {
    const libraries = db.listLibraries().filter((l) => l.enabled && (libraryId ? l.id === libraryId : true))
    for (const library of libraries) {
      if (cancelled) break
      await scanLibrary(library, options)
    }
    if (!cancelled) {
      await runDeduplication(options)
      // Phase 6：先做散图漫画目录聚合，再按作品统一填充本地元数据
      if (progress) progress.phase = 'metadata'
      const aggregated = await aggregateComicFolders()
      lastAggregate = aggregated
      metadata.seedWorksFromResources()
      metadata.pruneOrphans()
      // Phase 10：更新查询计划统计 + 截断 WAL
      db.optimizeDatabase()
    }
  } finally {
    if (progress) {
      progress.phase = cancelled ? 'idle' : 'done'
      progress.finishedAt = Date.now()
      progress.current = ''
      emitProgress(true)
    }
    scanning = false
    notifyChanged()
  }
}

export function pauseScan(): void {
  if (scanning) {
    paused = true
    if (progress) {
      progress.phase = 'paused'
      emitProgress(true)
    }
  }
}

export function resumeScan(): void {
  if (scanning) {
    paused = false
    if (progress) {
      progress.phase = 'scanning'
      emitProgress(true)
    }
  }
}

export function cancelScan(): void {
  if (scanning) {
    cancelled = true
    paused = false
  }
}

/** 估算一个目录下的文件数（添加资源库前的预览，不写库） */
export async function estimateDirectory(root: string, options: ScanOptions): Promise<number> {
  let total = 0
  await walkDirectory(root, '', 1, { ...options, generateThumbnails: false, readMetadata: false, computeHash: false }, {
    onCounted: () => {
      total++
    }
  })
  return total
}

export function describeCounts(counts: KindCount[]): string {
  return counts
    .filter((c) => c.count > 0)
    .map((c) => `${c.kind}:${c.count}`)
    .join(' ')
}

export function summarizeSize(bytes: number): string {
  return formatSize(bytes)
}

export function summarizeDuration(ms: number): string {
  return formatDuration(ms)
}
