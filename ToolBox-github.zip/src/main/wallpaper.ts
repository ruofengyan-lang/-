import { spawn } from 'node:child_process'
import fs from 'node:fs'
import fsp from 'node:fs/promises'
import path from 'node:path'
import { extOf, wallpaperStyleNumbers } from '@shared/resource-kinds'
import type { OperationResult, WallpaperStyleId } from '@shared/types'
import { configDir } from './config'

/** Windows 能直接当壁纸用的格式，其它格式（webp/avif…）由渲染进程转成 PNG 再设置 */
const NATIVE_WALLPAPER_EXTS = ['.jpg', '.jpeg', '.png', '.bmp']

/**
 * 真正的壁纸设置脚本：
 * - 写入 HKCU 的 WallpaperStyle / TileWallpaper（用户级，可随时改回）
 * - 调用 user32!SystemParametersInfo(SPI_SETDESKWALLPAPER=20, ..., SPIF_UPDATEINIFILE|SPIF_SENDCHANGE=3)
 * 通过 -EncodedCommand(UTF-16LE, base64) 传入，避免执行策略与中文路径编码问题。
 */
const PS_SCRIPT = String.raw`
$ErrorActionPreference = 'Stop'
# 输出统一用 UTF-8，避免中文路径被系统代码页弄成乱码
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$image = $env:TOOLBOX_WP_IMAGE
$style = [int]$env:TOOLBOX_WP_STYLE
$tile  = [int]$env:TOOLBOX_WP_TILE
if ([string]::IsNullOrWhiteSpace($image)) { Write-Output 'ERR|empty image path'; exit 2 }
if (-not (Test-Path -LiteralPath $image)) { Write-Output 'ERR|image not found'; exit 3 }
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
namespace ToolBoxWallpaper {
  public static class Native {
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
  }
}
'@
try {
  Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name WallpaperStyle -Value ([string]$style) -ErrorAction Stop
  Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name TileWallpaper -Value ([string]$tile) -ErrorAction Stop
} catch {
  Write-Output ('WARN|registry:' + $_.Exception.Message)
}
$full = (Resolve-Path -LiteralPath $image).Path
$ok = [ToolBoxWallpaper.Native]::SystemParametersInfo(20, 0, $full, 3)
if ($ok -eq 0) {
  $code = [System.Runtime.InteropServices.Marshal]::GetLastWin32Error()
  Write-Output ('ERR|SystemParametersInfo failed win32=' + $code)
  exit 1
}
Write-Output ('OK|' + $full)
exit 0
`

const ENCODED_SCRIPT = Buffer.from(PS_SCRIPT, 'utf16le').toString('base64')

interface PsResult {
  code: number
  stdout: string
  stderr: string
}

function runPowerShell(image: string, style: number, tile: number): Promise<PsResult> {
  return new Promise((resolve) => {
    let stdout = ''
    let stderr = ''
    let settled = false
    const child = spawn(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', ENCODED_SCRIPT],
      {
        windowsHide: true,
        env: {
          ...process.env,
          TOOLBOX_WP_IMAGE: image,
          TOOLBOX_WP_STYLE: String(style),
          TOOLBOX_WP_TILE: String(tile)
        }
      }
    )
    const timer = setTimeout(() => {
      if (settled) return
      settled = true
      try {
        child.kill()
      } catch {
        /* ignore */
      }
      resolve({ code: -1, stdout, stderr: `${stderr}\n设置壁纸超时（20 秒）` })
    }, 20000)

    child.stdout?.on('data', (chunk: Buffer) => {
      stdout += chunk.toString('utf8')
    })
    child.stderr?.on('data', (chunk: Buffer) => {
      stderr += chunk.toString('utf8')
    })
    child.on('error', (err) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve({ code: -2, stdout, stderr: `无法启动 powershell.exe：${err.message}` })
    })
    child.on('close', (code) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve({ code: code ?? -3, stdout, stderr })
    })
  })
}

/** 把选中的图片复制到 config/wallpapers/current.<ext>，避免原文件移动后壁纸失效 */
async function stageImage(source: string): Promise<string> {
  const dir = path.join(configDir(), 'wallpapers')
  await fsp.mkdir(dir, { recursive: true })
  const ext = extOf(path.basename(source)) || '.png'
  const dest = path.join(dir, `current${ext}`)
  try {
    for (const file of await fsp.readdir(dir)) {
      if (file.startsWith('current') && path.join(dir, file) !== dest) {
        await fsp.rm(path.join(dir, file), { force: true })
      }
    }
    await fsp.copyFile(source, dest)
    return dest
  } catch {
    return source
  }
}

async function applyToWindows(imagePath: string, styleId: WallpaperStyleId): Promise<OperationResult> {
  const { style, tile } = wallpaperStyleNumbers(styleId)
  const result = await runPowerShell(imagePath, style, tile)
  const combined = `${result.stdout}\n${result.stderr}`.trim()
  if (result.code === 0 && /OK\|/.test(result.stdout)) {
    return { ok: true, path: imagePath, message: '壁纸设置成功' }
  }
  const errLine = combined.split(/\r?\n/).find((line) => line.startsWith('ERR|'))
  const warnLine = combined.split(/\r?\n/).find((line) => line.startsWith('WARN|'))
  const detail = errLine ?? (combined || `退出码 ${result.code}`)
  if (warnLine) {
    return { ok: true, path: imagePath, message: `壁纸设置成功（${warnLine.replace('WARN|', '注册表提示：')}）` }
  }
  return { ok: false, error: `设置壁纸失败：${detail}` }
}

/** 把指定图片设置为 Windows 桌面壁纸 */
export async function setDesktopWallpaper(
  filePath: string,
  styleId: WallpaperStyleId
): Promise<OperationResult> {
  try {
    const stat = await fsp.stat(filePath)
    if (!stat.isFile()) return { ok: false, error: '只能把文件设置为壁纸' }
    const ext = extOf(path.basename(filePath))
    if (!NATIVE_WALLPAPER_EXTS.includes(ext)) {
      // .webp / .avif 等 Windows 不认，交给渲染进程转 PNG
      return { ok: false, error: 'NEED_CONVERT' }
    }
    const staged = await stageImage(filePath)
    return await applyToWindows(staged, styleId)
  } catch (err) {
    return { ok: false, error: `设置壁纸失败：${err instanceof Error ? err.message : String(err)}` }
  }
}

/** 渲染进程把图片转成 PNG dataURL 后由主进程落盘并设置为壁纸 */
export async function setDesktopWallpaperFromData(
  dataUrl: string,
  styleId: WallpaperStyleId
): Promise<OperationResult> {
  try {
    const match = /^data:image\/png;base64,(.+)$/i.exec(dataUrl)
    if (!match) return { ok: false, error: '图片转换结果无效（需要 PNG dataURL）' }
    const dir = path.join(configDir(), 'wallpapers')
    await fsp.mkdir(dir, { recursive: true })
    const dest = path.join(dir, 'current.png')
    for (const file of await fsp.readdir(dir)) {
      if (file.startsWith('current')) await fsp.rm(path.join(dir, file), { force: true })
    }
    await fsp.writeFile(dest, Buffer.from(match[1], 'base64'))
    return await applyToWindows(dest, styleId)
  } catch (err) {
    return { ok: false, error: `设置壁纸失败：${err instanceof Error ? err.message : String(err)}` }
  }
}

/** 用系统 API 快速确认 powershell.exe 可用（冒烟测试用） */
export function powershellAvailable(): boolean {
  const systemRoot = process.env.SystemRoot ?? 'C:\\Windows'
  return fs.existsSync(path.join(systemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe'))
}

/** 直接把一个已经是壁纸的路径再设回去（测试恢复用，不做格式转换与复制） */
export async function setWallpaperRaw(imagePath: string, styleId: WallpaperStyleId): Promise<OperationResult> {
  return applyToWindows(imagePath, styleId)
}

/** 读取当前 Windows 桌面壁纸路径（冒烟测试设置壁纸后用于恢复原样） */
export function readDesktopWallpaper(): Promise<string> {
  return new Promise((resolve) => {
    let out = ''
    const child = spawn(
      'powershell.exe',
      [
        '-NoProfile',
        '-NonInteractive',
        '-Command',
        "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; (Get-ItemProperty -Path 'HKCU:\\Control Panel\\Desktop' -Name WallPaper -ErrorAction SilentlyContinue).WallPaper"
      ],
      { windowsHide: true }
    )
    child.stdout?.on('data', (chunk: Buffer) => {
      out += chunk.toString('utf8')
    })
    const done = (): void => resolve(out.trim())
    child.on('close', done)
    child.on('error', done)
  })
}
