import crypto from 'node:crypto'
import fsp from 'node:fs/promises'
import path from 'node:path'
import type { MetadataConfig } from '@shared/types'
import { httpGetImage } from './http'

/**
 * 海报 / 背景图本地缓存（Phase 4 先落地海报，多尺寸与背景图在 Phase 8 补齐）。
 * 缓存目录：<data>/metadata/posters|backdrops
 * 数据库里只存相对路径，断网时依然能显示。
 */

let cacheRoot = ''
let postersDir = ''
let backdropsDir = ''

/**
 * 封面源熔断表：某个图床一次连不通（例如 Cover Art Archive → archive.org 在国内被阻断），
 * 本次运行内就不再重试，避免批量匹配时每张图都白等超时。
 */
const blockedHosts = new Map<string, number>()
const BLOCK_MS = 30 * 60 * 1000

function hostOf(url: string): string {
  try {
    return new URL(url).host.toLowerCase()
  } catch {
    return ''
  }
}

export function isImageHostBlocked(url: string): boolean {
  const host = hostOf(url)
  return Boolean(host) && (blockedHosts.get(host) ?? 0) > Date.now()
}

export function blockedImageHosts(): string[] {
  const now = Date.now()
  return [...blockedHosts.entries()].filter(([, until]) => until > now).map(([host]) => host)
}

export async function initPosterCache(dataDir: string): Promise<void> {
  cacheRoot = path.join(dataDir, 'metadata')
  postersDir = path.join(cacheRoot, 'posters')
  backdropsDir = path.join(cacheRoot, 'backdrops')
  await fsp.mkdir(postersDir, { recursive: true })
  await fsp.mkdir(backdropsDir, { recursive: true })
}

export function posterAbsolute(relative: string): string {
  if (!relative) return ''
  return path.join(cacheRoot, relative)
}

function nameFor(seriesKey: string, suffix: string): string {
  const hash = crypto.createHash('sha1').update(seriesKey).digest('hex').slice(0, 16)
  return `${hash}${suffix}`
}

/**
 * 下载一张图并落盘，返回相对路径（失败返回空字符串，绝不抛给调用方）。
 * kind: posters / backdrops
 */
export async function cacheImage(
  seriesKey: string,
  url: string,
  kind: 'posters' | 'backdrops',
  config: MetadataConfig,
  timeoutMs = 25000
): Promise<string> {
  if (!url || !seriesKey) return ''
  const dir = kind === 'posters' ? postersDir : backdropsDir
  if (!dir) return ''
  const host = hostOf(url)
  // 已知不通的图床直接跳过，不再浪费超时时间
  if (host && isImageHostBlocked(url)) return ''
  const ext = url.toLowerCase().includes('.png') ? '.png' : '.jpg'
  const fileName = nameFor(seriesKey, ext)
  const target = path.join(dir, fileName)
  const relative = `${kind}/${fileName}`
  // 已经有缓存就直接用，避免重复下载
  try {
    const stat = await fsp.stat(target)
    if (stat.size > 1024) return relative
  } catch {
    /* 没有缓存，继续下载 */
  }
  const result = await httpGetImage(url, { proxy: config.proxy, maxBytes: 12 * 1024 * 1024, timeoutMs })
  if (!result.ok || !result.data) {
    // 连不上/超时：拉黑这个图床（本会话内），后续同类封面直接用本地图
    if (host && /超时|拒绝|阻断|失败/.test(result.error)) blockedHosts.set(host, Date.now() + BLOCK_MS)
    return ''
  }
  try {
    const temp = `${target}.part`
    await fsp.writeFile(temp, result.data)
    await fsp.rename(temp, target)
    return relative
  } catch {
    return ''
  }
}

/** 删除某部作品已缓存的图片（重置元数据时用） */
export function removeCachedImages(seriesKey: string): void {
  if (!cacheRoot || !seriesKey) return
  for (const dir of [postersDir, backdropsDir]) {
    for (const ext of ['.jpg', '.png']) {
      void fsp.rm(path.join(dir, nameFor(seriesKey, ext)), { force: true }).catch(() => undefined)
    }
  }
}

/** 缓存占用（文件数与 MB） */
export async function cacheStats(): Promise<{ imageFiles: number; imageMB: number }> {
  if (!cacheRoot) return { imageFiles: 0, imageMB: 0 }
  let files = 0
  let total = 0
  for (const dir of [postersDir, backdropsDir]) {
    try {
      for (const entry of await fsp.readdir(dir, { withFileTypes: true })) {
        if (!entry.isFile()) continue
        const stat = await fsp.stat(path.join(dir, entry.name))
        files++
        total += stat.size
      }
    } catch {
      /* ignore */
    }
  }
  return { imageFiles: files, imageMB: Math.round((total / 1024 / 1024) * 10) / 10 }
}

/** 清空在线海报/背景图缓存，并把索引里的引用一起清掉（否则会指向不存在的文件） */
export async function clearAllImages(): Promise<{ removed: number; freedBytes: number }> {
  const before = await cacheStats()
  let bytes = 0
  let removed = 0
  for (const dir of [postersDir, backdropsDir]) {
    try {
      for (const entry of await fsp.readdir(dir, { withFileTypes: true })) {
        if (!entry.isFile()) continue
        const file = path.join(dir, entry.name)
        const stat = await fsp.stat(file).catch(() => null)
        bytes += stat?.size ?? 0
        await fsp.rm(file, { force: true })
        removed++
      }
    } catch {
      /* ignore */
    }
  }
  void before
  return { removed, freedBytes: bytes }
}

/** 超过上限时按修改时间清理旧图 */
export async function pruneImageCache(limitMB: number): Promise<number> {
  if (!cacheRoot || limitMB <= 0) return 0
  const files: { file: string; size: number; mtime: number }[] = []
  for (const dir of [postersDir, backdropsDir]) {
    try {
      for (const entry of await fsp.readdir(dir, { withFileTypes: true })) {
        if (!entry.isFile()) continue
        const file = path.join(dir, entry.name)
        const stat = await fsp.stat(file)
        files.push({ file, size: stat.size, mtime: stat.mtimeMs })
      }
    } catch {
      /* ignore */
    }
  }
  let total = files.reduce((sum, item) => sum + item.size, 0)
  if (total <= limitMB * 1024 * 1024) return 0
  files.sort((a, b) => a.mtime - b.mtime)
  let removed = 0
  for (const item of files) {
    if (total <= limitMB * 1024 * 1024) break
    try {
      await fsp.rm(item.file, { force: true })
      total -= item.size
      removed++
    } catch {
      /* ignore */
    }
  }
  return removed
}
