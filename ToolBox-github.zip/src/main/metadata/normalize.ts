import type { ResourceKind } from '@shared/types'
import type { MatchDecision, ProviderCandidate, ProviderQuery } from './types'

/**
 * 文件名清洗与候选打分：纯函数，无 IO、无网络。
 * Phase 4~7 的 Provider 只要拿到 ProviderQuery 就能查，不用关心文件名有多脏。
 */

/** 常见的画质 / 编码 / 音轨噪音 */
const NOISE_WORDS = [
  '1080p', '720p', '2160p', '480p', '4k', '8k',
  'bluray', 'blu-ray', 'bdrip', 'brrip', 'web-dl', 'webdl', 'webrip', 'hdrip', 'dvdrip', 'hdtv', 'tvrip',
  'x264', 'x265', 'h264', 'h265', 'hevc', 'avc', '10bit', '8bit', 'hdr', 'hdr10', 'dolby', 'dv',
  'aac', 'ac3', 'eac3', 'dts', 'dts-hd', 'truehd', 'atmos', 'flac', 'mp3', 'ddp', 'dd5', '5.1', '7.1',
  'remux', 'repack', 'proper', 'internal', 'complete', 'extended', 'uncut', 'unrated',
  '简繁', '繁体', '简体', '中字', '字幕', '国语', '双语', '无修', '合集', '全彩', '汉化', '生肉'
]

const BRACKET_RE = /[[【(（][^\]】)）]{0,60}[\]】)）]/g
const VOLUME_MARK_RE =
  /(?:第\s*\d{1,4}\s*[卷巻册集部话話回]|(?:vol|volume|chapter|chap|ch)\.?\s*\d{1,4}|(?:^|[\s._\-])v\s?\d{1,3}(?=$|[\s._\-]))/gi

/** 去掉扩展名 */
export function stripExtension(name: string): string {
  return name.replace(/\.[a-z0-9]{1,6}$/i, '')
}

/** 从文件名里挑一个像年份的数字（1900~2099），找不到返回 0 */
export function guessYear(name: string): number {
  const withoutVolume = name.replace(VOLUME_MARK_RE, ' ')
  const matches = withoutVolume.match(/(?:19|20)\d{2}/g)
  if (!matches || matches.length === 0) return 0
  const years = matches
    .map((value) => Number.parseInt(value, 10))
    .filter((value) => value >= 1900 && value <= 2099 && value <= new Date().getFullYear() + 1)
  return years.length > 0 ? years[years.length - 1] : 0
}

/**
 * 清洗文件名成一个适合作品名的字符串：
 *   去掉 [..] 【..】 (..) 标签、画质噪音、卷号标记、扩展名，统一分隔符
 */
export function cleanTitle(name: string): string {
  let value = stripExtension(name)
  value = value.replace(BRACKET_RE, ' ')
  value = value.replace(VOLUME_MARK_RE, ' ')
  for (const word of NOISE_WORDS) {
    value = value.replace(new RegExp(`(^|[\\s._\\-\\[])${word}(?=$|[\\s._\\-\\]])`, 'gi'), ' ')
  }
  value = value.replace(/[._]+/g, ' ')
  value = value.replace(/\s{2,}/g, ' ')
  value = value.replace(/^[\s\-–—·]+|[\s\-–—·]+$/g, '')
  return value.trim()
}

/** 生成检索用的候选标题（去重、保留顺序） */
export function buildAlternates(name: string, primary: string): string[] {
  const cleaned = cleanTitle(name)
  const candidates = [
    cleaned,
    stripExtension(name).replace(BRACKET_RE, ' ').replace(/\s{2,}/g, ' ').trim(),
    cleaned.replace(/[（(][^）)]*[）)]/g, ' ').replace(/\s{2,}/g, ' ').trim()
  ]
  // 分隔符前的短标题：数据库里常常只收录主标题
  //   ONE PIECE - 海贼王 → ONE PIECE
  //   示例作品 - 副标题 → 示例作品
  for (const part of cleaned.split(/[\s]*[-–—～~·:：|/][\s]*/)) {
    const value = part.trim()
    if (value.length >= 2 && value !== cleaned) candidates.push(value)
  }
  const seen = new Set<string>([primary.trim().toLowerCase()])
  const result: string[] = []
  for (const candidate of candidates) {
    const value = candidate.trim()
    if (value.length < 2) continue
    const key = value.toLowerCase()
    if (seen.has(key)) continue
    seen.add(key)
    result.push(value)
  }
  return result
}

/** Provider 查询输入 */
export function buildQuery(input: {
  name: string
  seriesTitle?: string
  kind: ResourceKind
  author?: string
}): ProviderQuery {
  const primary = (input.seriesTitle && input.seriesTitle.trim()) || cleanTitle(input.name)
  return {
    kind: input.kind,
    title: primary,
    alternates: buildAlternates(input.name, primary),
    year: guessYear(input.name),
    author: (input.author ?? '').trim()
  }
}

/* ============================ 相似度 ============================ */

/** 归一化：小写、去掉标点与空白（中英文通用） */
export function normalizeForMatch(value: string): string {
  return value
    .toLowerCase()
    .replace(/[\s\-_·:：,，.。!！?？'"“”‘’()（）[\]【】《》<>｜|/\\]/g, '')
    .trim()
}

function bigrams(value: string): Map<string, number> {
  const map = new Map<string, number>()
  if (value.length <= 1) {
    if (value) map.set(value, 1)
    return map
  }
  for (let i = 0; i < value.length - 1; i++) {
    const gram = value.slice(i, i + 2)
    map.set(gram, (map.get(gram) ?? 0) + 1)
  }
  return map
}

/** Dice 系数 0~1，对中日韩文本用二元组，对英文同样适用 */
export function similarity(a: string, b: string): number {
  const left = normalizeForMatch(a)
  const right = normalizeForMatch(b)
  if (!left || !right) return 0
  if (left === right) return 1
  if (left.includes(right) || right.includes(left)) {
    const ratio = Math.min(left.length, right.length) / Math.max(left.length, right.length)
    return 0.82 + ratio * 0.15
  }
  const gramsA = bigrams(left)
  const gramsB = bigrams(right)
  let overlap = 0
  let totalA = 0
  let totalB = 0
  for (const count of gramsA.values()) totalA += count
  for (const count of gramsB.values()) totalB += count
  for (const [gram, count] of gramsA) {
    const other = gramsB.get(gram)
    if (other) overlap += Math.min(count, other)
  }
  if (totalA === 0 || totalB === 0) return 0
  return (2 * overlap) / (totalA + totalB)
}

/* ============================ 候选打分与决策 ============================ */

export interface ScoreBreakdown {
  score: number
  titleScore: number
  yearScore: number
  authorScore: number
}

/**
 * 候选打分（0~1）：
 *   标题相似度为主（权重 0.7），年份与作者各 0.15 —— 但只在双方都有该字段时才计入，
 *   否则按实际可用的权重归一化。否则"标题完全一致但缺年份"的候选会被中性分拖到 0.9 以下，永远进不了自动匹配。
 */
export function scoreCandidate(query: ProviderQuery, candidate: ProviderCandidate): ScoreBreakdown {
  const titles = [query.title, ...query.alternates].filter(Boolean)
  const candidateTitles = [candidate.title, candidate.originalTitle].filter(Boolean)
  let titleScore = 0
  for (const left of titles) {
    for (const right of candidateTitles) {
      titleScore = Math.max(titleScore, similarity(left, right))
    }
  }

  let weight = 0.7
  let total = titleScore * 0.7

  let yearScore = 0
  if (query.year > 0 && candidate.year > 0) {
    const diff = Math.abs(query.year - candidate.year)
    yearScore = diff === 0 ? 1 : diff <= 1 ? 0.9 : diff <= 2 ? 0.7 : diff <= 5 ? 0.4 : 0
    weight += 0.15
    total += yearScore * 0.15
  }

  let authorScore = 0
  if (query.author && candidate.author) {
    authorScore = similarity(query.author, candidate.author)
    weight += 0.15
    total += authorScore * 0.15
  }

  const base = total / weight
  const bonus = Math.max(0, Math.min(0.05, candidate.popularity * 0.05))
  return {
    score: Math.max(0, Math.min(1, base + bonus)),
    titleScore,
    yearScore,
    authorScore
  }
}

/**
 * 从候选里做决策：
 *   置信度 ≥0.90 且与第二名拉开 0.08 → 直接 matched
 *   ≥0.55 → pending（交用户确认）
 *   否则 failed
 */
export function decideMatch(query: ProviderQuery, candidates: ProviderCandidate[]): MatchDecision {
  if (candidates.length === 0) {
    return { status: 'failed', confidence: 0, candidate: null, alternatives: [], reason: '没有候选' }
  }
  const scored = candidates
    .map((candidate) => ({ candidate, ...scoreCandidate(query, candidate) }))
    .sort((a, b) => b.score - a.score)
  const best = scored[0]
  const second = scored[1]
  if (best.score >= 0.9 && (!second || best.score - second.score >= 0.08)) {
    return {
      status: 'matched',
      confidence: Number(best.score.toFixed(3)),
      candidate: best.candidate,
      alternatives: scored.slice(1, 6).map((entry) => entry.candidate),
      reason: `标题相似度 ${best.titleScore.toFixed(2)}，置信度 ${best.score.toFixed(2)}`
    }
  }
  if (best.score >= 0.55) {
    return {
      status: 'pending',
      confidence: Number(best.score.toFixed(3)),
      candidate: null,
      alternatives: scored.slice(0, 6).map((entry) => entry.candidate),
      reason: `候选最高仅 ${best.score.toFixed(2)}，需要人工确认`
    }
  }
  return {
    status: 'failed',
    confidence: Number(best.score.toFixed(3)),
    candidate: null,
    alternatives: scored.slice(0, 6).map((entry) => entry.candidate),
    reason: `最高候选仅 ${best.score.toFixed(2)}，判定不匹配`
  }
}
