import type {
  BatchProgress,
  MatchStatus,
  MetadataConfig,
  ResourceKind,
  SeriesItem,
  StoredCandidate,
  WorkRow
} from '@shared/types'
import { WORK_KINDS } from '@shared/resource-kinds'
import { extractAuthor } from '../classifier'
import * as db from '../db'
import { buildQuery, decideMatch } from './normalize'
import * as posterCache from './poster'
import { createTmdbProvider } from './providers/tmdb'
import { createAniListProvider } from './providers/anilist'
import { createOpenLibraryProvider } from './providers/openlibrary'
import { createMusicBrainzProvider } from './providers/musicbrainz'
import {
  allProviders,
  getProvider,
  hasTestProvider,
  providerOverview,
  providersFor,
  registerProvider,
  unregisterProvider
} from './registry'
import * as store from './store'
import type { MatchDecision, MetadataRecord, MetadataStats, ProviderCandidate, ProviderDetail } from './types'
import { MATCH_STATUS_LABEL } from './types'

export { registerProvider, unregisterProvider, providerOverview, MATCH_STATUS_LABEL, store as metadataStore, getProvider }
export { buildQuery, cleanTitle, decideMatch, guessYear, scoreCandidate, similarity } from './normalize'
export * from './types'

/** 主进程启动时注入：数据目录 + 配置读取器（配置里含 API Key，只在本机内存与 config.json 里） */
let readConfig: (() => MetadataConfig) | null = null
let initialized = false

export async function init(options: { dataDir: string; getConfig: () => MetadataConfig }): Promise<void> {
  readConfig = options.getConfig
  if (initialized) return
  initialized = true
  await posterCache.initPosterCache(options.dataDir)
  // 只注册真实实现；界面上的"已登记未实现"列表在 registry 里单独维护
  registerProvider(createTmdbProvider(() => options.getConfig()))
  registerProvider(createMusicBrainzProvider(() => options.getConfig()))
  registerProvider(createAniListProvider(() => options.getConfig()))
  registerProvider(createOpenLibraryProvider(() => options.getConfig()))
}

export function currentConfig(): MetadataConfig {
  return (
    readConfig?.() ?? {
      tmdbApiKey: '',
      online: false,
      proxy: '',
      tmdbApiBase: 'https://api.themoviedb.org/3',
      tmdbImageBase: 'https://image.tmdb.org/t/p',
      imageCacheMB: 512
    }
  )
}

/** 海报缓存的绝对路径（给界面取封面用） */
export function posterAbsolute(relative: string): string {
  return posterCache.posterAbsolute(relative)
}

export async function cacheStats(): Promise<{ posterCacheMB: number; imageFiles: number; imageMB: number }> {
  const stats = await posterCache.cacheStats()
  return { posterCacheMB: stats.imageMB, imageFiles: stats.imageFiles, imageMB: stats.imageMB }
}

/** 清空在线海报/背景图缓存（Phase 8 缓存管理） */
export async function clearCachedImages(): Promise<{ removed: number; freedBytes: number }> {
  const result = await posterCache.clearAllImages()
  // 顺手把元数据里的图片引用清掉，避免界面指向已删除的文件
  for (const record of db.listMetadata()) {
    if (record.posterPath || record.backdropPath) {
      db.saveMetadata({ ...record, posterPath: '', backdropPath: '' })
    }
  }
  return result
}

/** 本次运行内已判定不通的图床（封面源熔断状态，给自检/界面用） */
export function blockedImageHosts(): string[] {
  return posterCache.blockedImageHosts()
}

/**
 * 元数据模块门面。
 * Phase 3：表结构、Provider 接口、本地信息填充、匹配决策全部就绪；
 * 在线 Provider 属于 Phase 4~7，本阶段一个都没注册（注册表为空是预期状态）。
 */

export type OnlineState = 'offline' | 'online'

/** 当前可用的 Provider 情况（界面/自检都用它如实展示） */
export function overview(): {
  registered: ReturnType<typeof providerOverview>
  implemented: number
  planned: number
} {
  const registered = providerOverview()
  return {
    registered,
    implemented: registered.filter((item) => item.implemented).length,
    planned: registered.filter((item) => !item.implemented).length
  }
}

export function status(): MetadataStats {
  const stats = store.stats()
  return {
    total: stats.total,
    byStatus: stats.byStatus,
    bySource: stats.bySource,
    providers: providerOverview()
  }
}

/** 用本地信息填充一部作品的元数据（扫描阶段调用） */
export function seedFromLocal(input: {
  seriesKey: string
  kind: ResourceKind
  seriesTitle: string
  localTitle?: string
  author?: string
  year?: number
}): void {
  store.seedLocal(input)
}

/**
 * 扫描结束后按「作品」统一填充本地元数据。
 * 不走文件解析，直接复用 resources 里已经解析好的标题/作者/年份，成本极低且可反复执行。
 */
export function seedWorksFromResources(): number {
  let seeded = 0
  for (const kind of WORK_KINDS) {
    for (const series of db.listSeries(kind)) {
      const sample = db.seriesVolumes(series.key)[0]
      // 作者：优先用文件内标签（音乐/EPUB），其次从文件名解析（《书名》作者：XXX）
      const authored = sample ? extractAuthor(sample.name) : { title: '', author: '' }
      store.seedLocal({
        seriesKey: series.key,
        kind,
        seriesTitle: series.title,
        // 音乐的"作品名"就是专辑名，绝不能拿某一首歌的名字当专辑名
        localTitle: kind === 'music' ? '' : (sample?.title ?? ''),
        author: sample?.artist || authored.author || '',
        year: sample?.year ?? 0
      })
      seeded++
    }
  }
  return seeded
}

/**
 * 对一部作品执行匹配。
 * 目前没有注册任何在线 Provider，所以结果如实返回"没有可用 Provider"，
 * 本地信息仍然保留（match_status 保持 local）。
 */
export async function matchSeries(
  series: Pick<SeriesItem, 'key' | 'kind' | 'title'>,
  options: { online?: boolean; author?: string; sampleName?: string; includeTest?: boolean } = {}
): Promise<MatchDecision & { providerCount: number }> {
  const config = currentConfig()
  const online = options.online ?? false
  if (!online) {
    return {
      status: 'failed',
      confidence: 0,
      candidate: null,
      alternatives: [],
      providerCount: 0,
      reason: '在线匹配已关闭（设置 → 元数据 → 允许联网匹配）'
    }
  }
  const providers = providersFor(series.kind, true, options.includeTest ?? false)
  if (providers.length === 0) {
    return {
      status: 'failed',
      confidence: 0,
      candidate: null,
      alternatives: [],
      providerCount: 0,
      reason: allProviders().length === 0 ? '尚未接入在线元数据源（Phase 4~7）' : '当前分类没有可用的在线数据源'
    }
  }

  // 作者是判分的重要一环（权重 15%），没显式传就从作品的第一个文件里取
  const derivedAuthor = options.author || db.seriesVolumes(series.key)[0]?.artist || ''
  const query = buildQuery({
    name: options.sampleName ?? series.title,
    seriesTitle: series.title,
    kind: series.kind,
    author: derivedAuthor
  })
  const results: ProviderCandidate[] = []
  const errors: string[] = []
  for (const provider of providers) {
    try {
      results.push(...(await provider.search(query)))
    } catch (err) {
      // 单个 Provider 失败不影响其它 Provider，但原因要带给用户
      errors.push(err instanceof Error ? err.message : String(err))
    }
  }
  if (results.length === 0 && errors.length > 0) {
    store.applyProviderResult(series.key, series.kind, {}, 'failed')
    return { status: 'failed', confidence: 0, candidate: null, alternatives: [], providerCount: providers.length, reason: errors[0] }
  }

  const decision = decideMatch(query, results)
  // 候选持久化：匹配成功时存"命中的 + 落选的"，待确认时存全部，供匹配中心人工挑选
  const storedCandidates = toStoredCandidates(
    decision.candidate ? [decision.candidate, ...decision.alternatives] : decision.alternatives
  )
  if (decision.status === 'matched' && decision.candidate) {
    const chosen = decision.candidate
    const detail = await providers
      .find((provider) => provider.id === chosen.source)
      ?.detail?.(chosen)
      .catch(() => undefined)
    const images = await cacheDetailImages(series.key, detail, config)
    store.applyProviderResult(
      series.key,
      series.kind,
      {
        title: chosen.title,
        originalTitle: chosen.originalTitle || chosen.title,
        year: chosen.year,
        author: chosen.author,
        externalSource: chosen.source,
        externalId: chosen.id,
        overview: detail?.overview ?? '',
        genres: detail?.genres ?? [],
        studio: detail?.studio ?? '',
        country: detail?.country ?? '',
        language: detail?.language ?? '',
        rating: detail?.rating ?? 0,
        posterPath: images.posterPath,
        backdropPath: images.backdropPath,
        matchConfidence: decision.confidence,
        extra: { ...(detail?.extra ?? {}), ...chosen.extra, candidates: storedCandidates }
      },
      'matched'
    )
  } else if (decision.status === 'pending') {
    store.applyProviderResult(
      series.key,
      series.kind,
      { matchConfidence: decision.confidence, extra: { candidates: storedCandidates } },
      'pending'
    )
  } else {
    // 一次失败不该把上次成功匹配的结果丢掉
    const current = store.get(series.key)
    if (!current || (current.matchStatus !== 'matched' && current.matchStatus !== 'confirmed')) {
      store.applyProviderResult(
        series.key,
        series.kind,
        { matchConfidence: decision.confidence, extra: { candidates: storedCandidates } },
        'failed'
      )
    }
  }
  return { ...decision, providerCount: providers.length }
}

/* ============================ Phase 9：匹配中心 ============================ */

function toStoredCandidates(candidates: ProviderCandidate[]): StoredCandidate[] {
  const seen = new Set<string>()
  const result: StoredCandidate[] = []
  for (const candidate of candidates) {
    const key = `${candidate.source}:${candidate.id}`
    if (seen.has(key)) continue
    seen.add(key)
    result.push({
      source: candidate.source,
      id: candidate.id,
      title: candidate.title,
      originalTitle: candidate.originalTitle,
      year: candidate.year,
      author: candidate.author,
      popularity: candidate.popularity,
      extra: candidate.extra
    })
    if (result.length >= 8) break
  }
  return result
}

/** 海报/背景图落盘。Cover Art Archive 会 302 到 archive.org（国内常连不上），给短超时 */
async function cacheDetailImages(
  seriesKey: string,
  detail: ProviderDetail | undefined,
  config: MetadataConfig
): Promise<{ posterPath: string; backdropPath: string }> {
  const imageTimeout = (url: string): number => (/coverartarchive\.org|archive\.org/i.test(url) ? 6000 : 25000)
  let posterPath = ''
  let backdropPath = ''
  if (detail?.posterUrl) {
    posterPath = await posterCache.cacheImage(seriesKey, detail.posterUrl, 'posters', config, imageTimeout(detail.posterUrl))
  }
  if (detail?.backdropUrl) {
    backdropPath = await posterCache.cacheImage(
      seriesKey,
      detail.backdropUrl,
      'backdrops',
      config,
      imageTimeout(detail.backdropUrl)
    )
  }
  return { posterPath, backdropPath }
}

/** 匹配中心：所有作品 + 元数据状态 */
export function centerRows(): WorkRow[] {
  return db.listWorkRows().map((row) => {
    const extra = (() => {
      try {
        return JSON.parse(row.extra_json ?? '{}') as Record<string, unknown>
      } catch {
        return {}
      }
    })()
    const candidates = Array.isArray(extra.candidates) ? (extra.candidates as unknown[]) : []
    return {
      seriesKey: row.series_key,
      kind: row.kind as ResourceKind,
      title: row.title ?? '',
      volumeCount: row.volume_count,
      totalSize: row.total_size,
      coverPath: row.cover_path ?? '',
      matchStatus: (row.match_status ?? 'none') as MatchStatus,
      externalSource: row.external_source ?? '',
      year: row.year ?? 0,
      author: row.author ?? '',
      rating: row.rating ?? 0,
      hasPoster: Boolean(row.poster_path),
      confidence: row.match_confidence ?? 0,
      candidateCount: candidates.length,
      updatedAt: row.updated_at ?? 0
    }
  })
}

/** 取某部作品上次匹配留下的候选 */
export function candidatesOf(seriesKey: string): StoredCandidate[] {
  const record = store.get(seriesKey)
  const extra = (record?.extra ?? {}) as Record<string, unknown>
  return Array.isArray(extra.candidates) ? (extra.candidates as StoredCandidate[]) : []
}

/** 人工确认某个候选：拉详情 + 缓存封面 + 标记 confirmed */
export async function confirmCandidate(seriesKey: string, candidate: StoredCandidate): Promise<MetadataRecord | null> {
  const record = store.get(seriesKey)
  if (!record) return null
  const provider = getProvider(candidate.source)
  const asProviderCandidate: ProviderCandidate = {
    source: candidate.source,
    id: candidate.id,
    title: candidate.title,
    originalTitle: candidate.originalTitle,
    year: candidate.year,
    author: candidate.author,
    popularity: candidate.popularity,
    coverUrl: '',
    extra: candidate.extra ?? {}
  }
  const detail = await provider?.detail?.(asProviderCandidate).catch(() => undefined)
  const images = await cacheDetailImages(seriesKey, detail, currentConfig())
  const existing = candidatesOf(seriesKey)
  store.applyProviderResult(
    seriesKey,
    record.kind,
    {
      title: candidate.title,
      originalTitle: candidate.originalTitle || candidate.title,
      year: candidate.year,
      author: candidate.author,
      externalSource: candidate.source,
      externalId: candidate.id,
      overview: detail?.overview ?? record.overview,
      genres: detail?.genres?.length ? detail.genres : record.genres,
      rating: detail?.rating ?? record.rating,
      posterPath: images.posterPath || record.posterPath,
      backdropPath: images.backdropPath || record.backdropPath,
      matchConfidence: 1,
      extra: { ...(detail?.extra ?? {}), ...(candidate.extra ?? {}), candidates: existing }
    },
    'confirmed'
  )
  return store.get(seriesKey)
}

/** 用户判定"候选都不对"：标记为 failed，但保留候选，方便以后重看 */
export function rejectCandidates(seriesKey: string): MetadataRecord | null {
  const record = store.get(seriesKey)
  if (!record) return null
  return store.applyManual(
    seriesKey,
    record.kind,
    { matchConfidence: 0, extra: { ...(record.extra ?? {}), rejectedAt: Date.now() } },
    'failed'
  )
}

/** 手动填写并确认 */
export function saveManual(seriesKey: string, patch: Partial<MetadataRecord>): MetadataRecord | null {
  const record = store.get(seriesKey)
  if (!record) return null
  return store.applyManual(seriesKey, record.kind, patch, 'confirmed')
}

/** 重置为本地信息：清掉在线结果与缓存图，回到扫描时的本地状态 */
export function resetToLocal(seriesKey: string): MetadataRecord | null {
  const record = store.get(seriesKey)
  if (!record) return null
  posterCache.removeCachedImages(seriesKey)
  const volumes = db.seriesVolumes(seriesKey)
  const sample = volumes[0]
  const authored = sample ? extractAuthor(sample.name) : { title: '', author: '' }
  const next = store.applyManual(
    seriesKey,
    record.kind,
    {
      title: record.kind === 'music' ? record.title : sample?.title || record.title,
      originalTitle: '',
      year: 0,
      overview: '',
      genres: [],
      studio: '',
      country: '',
      language: '',
      rating: 0,
      externalSource: 'local',
      externalId: '',
      matchConfidence: 0,
      posterPath: '',
      backdropPath: '',
      extra: {},
      author: sample?.artist || authored.author || ''
    },
    'local'
  )
  return next
}

/* ---------------- 批量匹配 ---------------- */

let batch: BatchProgress | null = null
type BatchListener = (progress: BatchProgress) => void
const batchListeners = new Set<BatchListener>()

export function onBatchProgress(listener: BatchListener): () => void {
  batchListeners.add(listener)
  return () => batchListeners.delete(listener)
}

export function batchProgress(): BatchProgress | null {
  return batch ? { ...batch } : null
}

function emitBatch(): void {
  if (!batch) return
  const snapshot = { ...batch }
  for (const listener of batchListeners) listener(snapshot)
}

function matchesFilter(row: WorkRow, status: MatchStatus | 'all', kind: ResourceKind | null): boolean {
  if (kind && row.kind !== kind) return false
  if (status === 'all') return row.matchStatus !== 'matched' && row.matchStatus !== 'confirmed'
  if (status === 'local') return row.matchStatus === 'local' || row.matchStatus === 'none'
  return row.matchStatus === status
}

/** 启动批量匹配（顺序执行，覆盖式进度；可取消） */
export function startBatch(options: {
  status: MatchStatus | 'all'
  kind: ResourceKind | null
  limit: number
}): BatchProgress {
  if (batch?.running) return { ...batch }
  // 保险丝：注册表里若有"仅自检"的假 Provider，绝不批量跑（会把自检数据写进真实库）
  if (hasTestProvider()) {
    batch = {
      running: false,
      total: 0,
      done: 0,
      matched: 0,
      pending: 0,
      failed: 0,
      skipped: 0,
      current: '',
      startedAt: Date.now(),
      finishedAt: Date.now(),
      cancelled: false,
      lastError: '检测到自检用临时 Provider，已拒绝批量匹配（请重启应用后重试）'
    }
    emitBatch()
    return { ...batch }
  }
  const rows = centerRows()
    .filter((row) => matchesFilter(row, options.status, options.kind))
    .slice(0, Math.max(1, Math.min(500, options.limit)))
  batch = {
    running: true,
    total: rows.length,
    done: 0,
    matched: 0,
    pending: 0,
    failed: 0,
    skipped: 0,
    current: '',
    startedAt: Date.now(),
    finishedAt: 0,
    cancelled: false,
    lastError: ''
  }
  emitBatch()

  void (async () => {
    for (const row of rows) {
      if (!batch || batch.cancelled) break
      batch.current = row.title
      emitBatch()
      try {
        const volumes = db.seriesVolumes(row.seriesKey)
        const decision = await matchSeries(
          { key: row.seriesKey, kind: row.kind, title: row.title },
          { online: true, sampleName: volumes[0]?.name }
        )
        if (decision.status === 'matched') batch.matched++
        else if (decision.status === 'pending') batch.pending++
        else batch.failed++
        if (decision.status !== 'matched' && decision.reason) batch.lastError = `${row.title}：${decision.reason}`
      } catch (err) {
        batch.failed++
        batch.lastError = `${row.title}：${err instanceof Error ? err.message : String(err)}`
      }
      batch.done++
      emitBatch()
    }
    batch.running = false
    batch.finishedAt = Date.now()
    batch.current = ''
    emitBatch()
  })()

  return { ...batch }
}

export function cancelBatch(): void {
  if (batch?.running) {
    batch.cancelled = true
    emitBatch()
  }
}

/** 清理孤儿元数据（作品文件已全部移除） */
export function pruneOrphans(): number {
  return store.prune()
}

/** 该作品当前在数据库里的元数据 */
export function get(seriesKey: string): MetadataRecord | null {
  return store.get(seriesKey)
}

export function list(status?: MatchStatus): MetadataRecord[] {
  return store.list(status)
}

/** 统计本地已填充的作品数量（自检用） */
export function localSeededCount(): number {
  return db.listMetadata('local').length
}
