import type { ResourceKind } from '@shared/types'
import * as db from '../db'
import { emptyMetadata, type MatchStatus, type MetadataRecord } from './types'

/**
 * 元数据读写 + 本地信息填充。
 * 规则：Provider 匹配结果（matched / confirmed）优先，本地信息只能填空白，绝不覆盖。
 */

/** 明显没意义的标题（EPUB 转换器常写 "Converted Ebook" 之类） */
const JUNK_TITLES = /^(untitled|unknown|no title|converted ebook|ebook|epub|book|document|\d{1,4})$/i

export function isUsefulTitle(value: string): boolean {
  const trimmed = (value ?? '').trim()
  if (trimmed.length < 2) return false
  if (JUNK_TITLES.test(trimmed)) return false
  return true
}

export function isUsefulAuthor(value: string): boolean {
  const trimmed = (value ?? '').trim()
  if (trimmed.length < 2) return false
  return !/^(unknown|anonymous|作者未知|佚名|n\/a)$/i.test(trimmed)
}

export function get(seriesKey: string): MetadataRecord | null {
  if (!seriesKey) return null
  return db.getMetadata(seriesKey)
}

export function list(status?: MatchStatus): MetadataRecord[] {
  return db.listMetadata(status)
}

export function stats(): { total: number; byStatus: Record<string, number>; bySource: Record<string, number> } {
  return db.metadataStats()
}

/** 清理已经没有本地文件的作品元数据 */
export function prune(): number {
  return db.pruneMetadata()
}

export interface LocalSeed {
  seriesKey: string
  kind: ResourceKind
  /** 作品名（通常来自文件名解析） */
  seriesTitle: string
  /** 本地能读到的标题（EPUB dc:title / 音频标签等） */
  localTitle?: string
  author?: string
  year?: number
}

/**
 * 用本地文件信息填充元数据。
 * 已 matched / confirmed 的作品不会被本地信息改写。
 */
export function seedLocal(seed: LocalSeed): void {
  if (!seed.seriesKey) return
  const existing = db.getMetadata(seed.seriesKey)
  if (existing && (existing.matchStatus === 'matched' || existing.matchStatus === 'confirmed')) return

  const record = existing ?? emptyMetadata(seed.seriesKey, seed.kind, seed.seriesTitle)
  const title = isUsefulTitle(seed.localTitle ?? '') ? (seed.localTitle as string).trim() : seed.seriesTitle
  const author = isUsefulAuthor(seed.author ?? '') ? (seed.author as string).trim() : ''

  const next: MetadataRecord = {
    ...record,
    kind: seed.kind,
    title: title || record.title,
    author: author || record.author,
    year: seed.year && seed.year > 0 ? seed.year : record.year,
    // 只有还没被 Provider 填过时才标记为"本地信息"
    matchStatus: record.matchStatus === 'none' || record.matchStatus === 'local' ? 'local' : record.matchStatus,
    externalSource: record.externalSource || 'local'
  }
  const changed =
    !existing ||
    next.title !== existing.title ||
    next.author !== existing.author ||
    next.year !== existing.year ||
    next.matchStatus !== existing.matchStatus
  if (changed) db.saveMetadata(next)
}

/** 写入 Provider 匹配结果 */
export function applyProviderResult(
  seriesKey: string,
  kind: ResourceKind,
  patch: Partial<MetadataRecord>,
  status: MatchStatus
): void {
  const record = db.getMetadata(seriesKey) ?? emptyMetadata(seriesKey, kind, patch.title ?? '')
  db.saveMetadata({ ...record, ...patch, kind, matchStatus: status })
}

/** 用户手动确认匹配 / 修改信息（整体替换：允许清空字段） */
export function applyManual(
  seriesKey: string,
  kind: ResourceKind,
  patch: Partial<MetadataRecord>,
  status: MatchStatus = 'confirmed'
): MetadataRecord {
  const record = db.getMetadata(seriesKey) ?? emptyMetadata(seriesKey, kind, patch.title ?? '')
  const next = { ...record, ...patch, kind, matchStatus: status }
  // 手动编辑与重置必须走整体替换，否则空值会被 upsert 当成"不修改"
  db.replaceMetadata(next)
  return next
}
