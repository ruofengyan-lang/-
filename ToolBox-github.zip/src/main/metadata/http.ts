import { session } from 'electron'
import type { Session } from 'electron'

/**
 * 主进程专用网络层。
 * 使用 Electron 的 net.fetch（Chromium 网络栈）：能走系统代理，也支持单独指定代理，
 * 不会像 Node 的 fetch 那样把请求发成一个孤立连接。
 *
 * 所有请求都在主进程发出，渲染进程永不直接触碰网络。
 */

let metadataSession: Session | null = null
let appliedProxy = '(未设置)'

function metadataNetSession(proxy: string): Session {
  if (!metadataSession) metadataSession = session.fromPartition('toolbox-metadata')
  const rules = proxy.trim() || 'direct://'
  if (appliedProxy !== rules) {
    appliedProxy = rules
    void metadataSession.setProxy({ proxyRules: rules })
  }
  return metadataSession
}

export interface HttpResult<T> {
  ok: boolean
  status: number
  data: T | null
  /** 失败原因（中文，直接给用户看） */
  error: string
}

function describeHttpStatus(status: number): string {
  if (status === 401 || status === 403) return `授权失败（HTTP ${status}）：API Key 无效或没有权限`
  if (status === 404) return '没有找到对应条目（HTTP 404）'
  if (status === 429) return '请求过于频繁（HTTP 429），请稍后再试'
  if (status === 503) return `数据源暂时不可用（HTTP ${status}），稍后重试`
  if (status >= 500) return `数据源服务异常（HTTP ${status}）`
  return `请求失败（HTTP ${status}）`
}

function describeError(err: unknown): string {
  const error = err as NodeJS.ErrnoException & { cause?: NodeJS.ErrnoException; name?: string }
  const code = error.cause?.code ?? error.code ?? ''
  if (error.name === 'TimeoutError' || error.name === 'AbortError') return '请求超时：网络不可达或需要代理'
  if (code === 'ENOTFOUND') return '域名解析失败：请检查网络'
  if (code === 'ECONNREFUSED') return '连接被拒绝：请检查代理设置'
  if (code === 'UND_ERR_CONNECT_TIMEOUT' || code === 'ETIMEDOUT' || code === 'ECONNRESET') {
    return '连接超时：目标被网络阻断，通常需要配置代理'
  }
  return `请求失败：${error.message ?? String(err)}`
}

export interface HttpOptions {
  token?: string
  proxy?: string
  timeoutMs?: number
  /** 额外请求头（例如 MusicBrainz 强制要求的 User-Agent） */
  headers?: Record<string, string>
  /** 非 JSON 响应（例如图片）时用 raw */
  raw?: boolean
}

export async function httpGetJson<T>(url: string, options: HttpOptions = {}): Promise<HttpResult<T>> {
  return requestJson<T>(url, options, undefined)
}

/** POST JSON（AniList GraphQL 这类接口需要） */
export async function httpPostJson<T>(url: string, body: unknown, options: HttpOptions = {}): Promise<HttpResult<T>> {
  return requestJson<T>(url, options, body)
}

async function requestJson<T>(url: string, options: HttpOptions, body: unknown): Promise<HttpResult<T>> {
  const sess = metadataNetSession(options.proxy ?? '')
  try {
    // 用会话自带的 fetch（session.fetch 才能指定走哪个 session/代理）
    const response = await sess.fetch(url, {
      method: body === undefined ? 'GET' : 'POST',
      headers: {
        accept: 'application/json',
        ...(body !== undefined ? { 'content-type': 'application/json' } : {}),
        ...(options.token ? { Authorization: `Bearer ${options.token}` } : {}),
        ...(options.headers ?? {})
      },
      ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
      signal: AbortSignal.timeout(options.timeoutMs ?? 15000)
    })
    const text = await response.text()
    if (!response.ok) {
      return { ok: false, status: response.status, data: null, error: describeHttpStatus(response.status) }
    }
    try {
      return { ok: true, status: response.status, data: JSON.parse(text) as T, error: '' }
    } catch {
      return { ok: false, status: response.status, data: null, error: '数据源返回了无法解析的内容' }
    }
  } catch (err) {
    return { ok: false, status: 0, data: null, error: describeError(err) }
  }
}

export interface ImageResult {
  ok: boolean
  data: Buffer | null
  bytes: number
  error: string
}

/** 下载图片（海报 / 背景图），带体积上限，避免被超大文件拖死 */
export async function httpGetImage(
  url: string,
  options: HttpOptions & { maxBytes?: number } = {}
): Promise<ImageResult> {
  const sess = metadataNetSession(options.proxy ?? '')
  const maxBytes = options.maxBytes ?? 12 * 1024 * 1024
  try {
    const response = await sess.fetch(url, {
      signal: AbortSignal.timeout(options.timeoutMs ?? 25000),
      headers: { ...(options.headers ?? {}) }
    })
    if (!response.ok) {
      return { ok: false, data: null, bytes: 0, error: describeHttpStatus(response.status) }
    }
    const buffer = Buffer.from(await response.arrayBuffer())
    if (buffer.length === 0) return { ok: false, data: null, bytes: 0, error: '图片为空' }
    if (buffer.length > maxBytes) {
      return { ok: false, data: null, bytes: buffer.length, error: `图片过大（${Math.round(buffer.length / 1024 / 1024)}MB）` }
    }
    return { ok: true, data: buffer, bytes: buffer.length, error: '' }
  } catch (err) {
    return { ok: false, data: null, bytes: 0, error: describeError(err) }
  }
}

/** 代理设置变化时清掉缓存的会话状态 */
export function resetHttpSession(): void {
  appliedProxy = '(未设置)'
  metadataSession = null
}
