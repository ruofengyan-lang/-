import type { MatchStatus, MetadataRecord, MetadataStats, ProviderInfo, ResourceKind } from '@shared/types'
import { MATCH_STATUS_LABEL } from '@shared/metadata-labels'

export type { MatchStatus, MetadataRecord, MetadataStats, ProviderInfo }
export { MATCH_STATUS_LABEL }

export function emptyMetadata(seriesKey: string, kind: ResourceKind, title: string): MetadataRecord {
  const now = Date.now()
  return {
    seriesKey,
    kind,
    title,
    originalTitle: '',
    year: 0,
    overview: '',
    genres: [],
    author: '',
    studio: '',
    country: '',
    language: '',
    rating: 0,
    externalSource: '',
    externalId: '',
    matchStatus: 'none',
    matchConfidence: 0,
    posterPath: '',
    backdropPath: '',
    coverPath: '',
    extra: {},
    updatedAt: now,
    createdAt: now
  }
}

/** Provider 搜索的输入 */
export interface ProviderQuery {
  kind: ResourceKind
  /** 首选标题（已清洗） */
  title: string
  /** 备选标题（原名、去掉季号/卷号等） */
  alternates: string[]
  year: number
  author: string
}

/** Provider 返回的候选作品 */
export interface ProviderCandidate {
  source: string
  id: string
  title: string
  originalTitle: string
  year: number
  author: string
  /** 0~1 的源内热度，用于同分排序 */
  popularity: number
  coverUrl: string
  extra: Record<string, unknown>
}

export interface ProviderDetail {
  overview?: string
  genres?: string[]
  studio?: string
  country?: string
  language?: string
  rating?: number
  posterUrl?: string
  backdropUrl?: string
  extra?: Record<string, unknown>
}

/**
 * 元数据提供方接口。Phase 4~7 只需要实现这个接口并注册，不需要改动业务层。
 * 约束：
 *  - 必须自己处理超时/重试/频率限制，失败只抛错，不影响调用方其它流程
 *  - 严禁在渲染进程直接发请求，一切走主进程
 *  - requiresNetwork=true 的 Provider 在离线模式下会被跳过，本地信息依然可用
 */
export interface MetadataProvider {
  id: string
  label: string
  /** 支持哪些资源类型 */
  kinds: ResourceKind[]
  requiresNetwork: boolean
  /**
   * 仅用于自检的假 Provider：正常匹配与批量匹配一律不会使用它，
   * 避免自检数据被写进真实库（这个坑踩过一次）。
   */
  test?: boolean
  search(query: ProviderQuery): Promise<ProviderCandidate[]>
  detail?(candidate: ProviderCandidate): Promise<ProviderDetail>
}

/** 匹配决策结果 */
export interface MatchDecision {
  status: MatchStatus
  confidence: number
  candidate: ProviderCandidate | null
  /** 落选候选，用于"待确认"时给用户挑 */
  alternatives: ProviderCandidate[]
  reason: string
}
