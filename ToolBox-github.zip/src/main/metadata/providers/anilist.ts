import type { MetadataConfig } from '@shared/types'
import { httpPostJson } from '../http'
import type { MetadataProvider, ProviderCandidate, ProviderDetail, ProviderQuery } from '../types'

/**
 * AniList Provider（漫画 / 动画）。
 * 免 Key、国内实测可直连（GraphQL 200，图片 CDN 有响应）。
 *
 * AniList 用 GraphQL，所以走 POST；官方限流较紧，这里做了轻量节流与 429/500 退避重试。
 */

const ENDPOINT = 'https://graphql.anilist.co'
const MIN_INTERVAL_MS = 900

interface AniListTitle {
  romaji?: string | null
  english?: string | null
  native?: string | null
}

interface AniListMedia {
  id: number
  title: AniListTitle
  format?: string | null
  status?: string | null
  startDate?: { year?: number | null } | null
  genres?: string[] | null
  averageScore?: number | null
  popularity?: number | null
  chapters?: number | null
  volumes?: number | null
  episodes?: number | null
  description?: string | null
  coverImage?: { extraLarge?: string | null; large?: string | null } | null
  bannerImage?: string | null
  staff?: { nodes: { name: { full?: string | null } }[] } | null
  studios?: { nodes: { name: string }[] } | null
}

interface AniListResponse {
  data?: { Page?: { media?: AniListMedia[] }; Media?: AniListMedia }
  errors?: { message: string }[]
}

const SEARCH_FIELDS = `
  id
  title { romaji english native }
  format
  startDate { year }
  genres
  averageScore
  popularity
  chapters
  volumes
  episodes
  coverImage { extraLarge large }
  description(asHtml: false)
  staff(perPage: 1) { nodes { name { full } } }
`

const DETAIL_FIELDS = `
  id
  title { romaji english native }
  format
  status
  startDate { year }
  genres
  averageScore
  popularity
  chapters
  volumes
  episodes
  coverImage { extraLarge large }
  bannerImage
  description(asHtml: false)
  staff(perPage: 3) { nodes { name { full } } }
  studios { nodes { name } }
`

let lastRequestAt = 0

async function throttled<T>(job: () => Promise<T>): Promise<T> {
  const wait = lastRequestAt + MIN_INTERVAL_MS - Date.now()
  if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait))
  lastRequestAt = Date.now()
  return job()
}

function pickTitle(title: AniListTitle): { display: string; original: string } {
  const native = (title.native ?? '').trim()
  const english = (title.english ?? '').trim()
  const romaji = (title.romaji ?? '').trim()
  // 中文用户优先看英文名，其次罗马音，最后原名
  const display = english || romaji || native
  const original = native || romaji || english
  return { display, original }
}

function cleanDescription(value: string | null | undefined): string {
  if (!value) return ''
  return value
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
}

function toCandidate(media: AniListMedia): ProviderCandidate {
  const { display, original } = pickTitle(media.title ?? {})
  const cover = media.coverImage?.extraLarge || media.coverImage?.large || ''
  return {
    source: 'anilist',
    id: String(media.id),
    title: display,
    originalTitle: original,
    year: media.startDate?.year ?? 0,
    author: media.staff?.nodes?.[0]?.name?.full ?? '',
    popularity: Math.max(0, Math.min(1, (media.popularity ?? 0) / 100000)),
    coverUrl: cover,
    extra: {
      format: media.format ?? '',
      genres: media.genres ?? [],
      averageScore: media.averageScore ?? 0,
      chapters: media.chapters ?? 0,
      volumes: media.volumes ?? 0,
      description: cleanDescription(media.description)
    }
  }
}

export function createAniListProvider(getConfig: () => MetadataConfig): MetadataProvider {
  const query = async <T,>(body: object): Promise<AniListResponse> => {
    const config = getConfig()
    let last: Awaited<ReturnType<typeof httpPostJson<AniListResponse>>> = {
      ok: false,
      status: 0,
      data: null,
      error: '未发起请求'
    }
    for (let attempt = 0; attempt < 3; attempt++) {
      last = await throttled(() =>
        httpPostJson<AniListResponse>(ENDPOINT, body, { proxy: config.proxy, timeoutMs: 20000 })
      )
      if (last.ok) break
      const retryable = last.status === 429 || last.status >= 500 || last.status === 0
      if (!retryable) break
      await new Promise((resolve) => setTimeout(resolve, 1200 * (attempt + 1)))
    }
    if (!last.ok || !last.data) throw new Error(last.error || 'AniList 请求失败')
    if (last.data.errors?.length) throw new Error(last.data.errors[0].message)
    return last.data
  }

  return {
    id: 'anilist',
    label: 'AniList（漫画 / 动画）',
    kinds: ['comic', 'anime'],
    requiresNetwork: true,

    async search(input: ProviderQuery): Promise<ProviderCandidate[]> {
      const type = input.kind === 'anime' ? 'ANIME' : 'MANGA'
      const body = {
        query: `query ($search: String, $type: MediaType) {
          Page(perPage: 8) { media(search: $search, type: $type, sort: SEARCH_MATCH) { ${SEARCH_FIELDS} } }
        }`,
        variables: { search: input.title, type }
      }
      const data = await query<AniListResponse>(body)
      let media = data.data?.Page?.media ?? []
      // 主标题搜不到就依次用候选标题（原名 / 分隔符前的短标题）再搜
      for (const alternate of input.alternates.slice(0, 3)) {
        if (media.length > 0) break
        const retry = await query<AniListResponse>({
          query: `query ($search: String, $type: MediaType) {
            Page(perPage: 8) { media(search: $search, type: $type, sort: SEARCH_MATCH) { ${SEARCH_FIELDS} } }
          }`,
          variables: { search: alternate, type }
        })
        media = retry.data?.Page?.media ?? []
      }
      return media.map(toCandidate)
    },

    async detail(candidate: ProviderCandidate): Promise<ProviderDetail> {
      const data = await query<AniListResponse>({
        query: `query ($id: Int) { Media(id: $id) { ${DETAIL_FIELDS} } }`,
        variables: { id: Number(candidate.id) }
      })
      const media = data.data?.Media
      if (!media) throw new Error('AniList 没有返回详情')
      const staff = (media.staff?.nodes ?? []).map((node) => node.name.full ?? '').filter(Boolean)
      const studios = (media.studios?.nodes ?? []).map((node) => node.name)
      return {
        overview: cleanDescription(media.description),
        genres: media.genres ?? [],
        studio: studios[0] ?? '',
        rating: media.averageScore ? Math.round((media.averageScore / 10) * 10) / 10 : 0,
        posterUrl: media.coverImage?.extraLarge || media.coverImage?.large || '',
        backdropUrl: media.bannerImage ?? '',
        extra: {
          anilistUrl: `https://anilist.co/${candidate.extra.format === 'ANIME' ? 'anime' : 'manga'}/${media.id}`,
          format: media.format ?? '',
          status: media.status ?? '',
          chapters: media.chapters ?? 0,
          volumes: media.volumes ?? 0,
          episodes: media.episodes ?? 0,
          staff: staff.join(', '),
          studios: studios.join(', ')
        }
      }
    }
  }
}
