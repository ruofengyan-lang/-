import type { MetadataConfig } from '@shared/types'
import { httpGetJson, type HttpResult } from '../http'
import type { MetadataProvider, ProviderCandidate, ProviderDetail, ProviderQuery } from '../types'

/**
 * MusicBrainz Provider（音乐专辑）。
 *
 * 两条硬性约束：
 *  1. MusicBrainz 要求带可识别的 User-Agent，否则会被限流甚至封禁；
 *  2. 官方限流是每秒 1 次请求，所以这里串行节流，批量匹配也不会打爆。
 *
 * 封面走 Cover Art Archive（coverartarchive.org）——它最终会 302 到 archive.org，
 * 国内通常连不上，所以封面是"尽力而为"：拿不到就继续用本地内嵌的专辑封面。
 */

const USER_AGENT = 'ToolBox/1.4.3 ( personal local media library; single local user )'
const MIN_INTERVAL_MS = 1100
const MB_ROOT = 'https://musicbrainz.org/ws/2'

interface MbArtistCredit {
  name?: string
  artist?: { id: string; name: string }
}

interface MbReleaseGroup {
  id: string
  title: string
  score?: number
  'first-release-date'?: string
  'primary-type'?: string | null
  'secondary-types'?: string[]
  'artist-credit'?: MbArtistCredit[]
  genres?: { id: string; name: string; count: number }[]
  tags?: { name: string; count: number }[]
  rating?: { value: number | null; 'votes-count': number }
  disambiguation?: string
  releases?: { id: string; title: string; date?: string }[]
}

interface MbSearchResponse {
  count: number
  'release-groups'?: MbReleaseGroup[]
}

let lastRequestAt = 0

/** 串行节流：两次 MusicBrainz 请求之间至少间隔 1.1 秒（官方限流 1 req/s） */
async function throttled<T>(job: () => Promise<T>): Promise<T> {
  const wait = lastRequestAt + MIN_INTERVAL_MS - Date.now()
  if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait))
  lastRequestAt = Date.now()
  return job()
}

function artistOf(item: MbReleaseGroup): string {
  return (item['artist-credit'] ?? [])
    .map((credit) => credit.name ?? credit.artist?.name ?? '')
    .filter(Boolean)
    .join(', ')
}

function yearOf(item: MbReleaseGroup): number {
  const year = Number.parseInt((item['first-release-date'] ?? '').slice(0, 4), 10)
  return Number.isFinite(year) && year > 1800 ? year : 0
}

/** MusicBrainz 评分是 0~5，换算成界面统一的 0~10 */
function ratingOf(value: number | null | undefined): number {
  if (!value || !Number.isFinite(value)) return 0
  return Math.round(value * 2 * 10) / 10
}

function coverUrlOf(id: string): string {
  return `https://coverartarchive.org/release-group/${id}/front-500`
}

function candidateOf(item: MbReleaseGroup): ProviderCandidate {
  const score = typeof item.score === 'number' ? item.score : 0
  return {
    source: 'musicbrainz',
    id: item.id,
    title: item.title,
    originalTitle: item.title,
    year: yearOf(item),
    author: artistOf(item),
    popularity: Math.max(0, Math.min(1, score / 100)),
    coverUrl: coverUrlOf(item.id),
    extra: {
      primaryType: item['primary-type'] ?? '',
      secondaryTypes: item['secondary-types'] ?? [],
      disambiguation: item.disambiguation ?? ''
    }
  }
}

export function createMusicBrainzProvider(getConfig: () => MetadataConfig): MetadataProvider {
  /** 带退避重试的请求：MusicBrainz 在请求稍快时会直接回 503/429 */
  const mbGet = async <T,>(url: string): Promise<HttpResult<T>> => {
    const config = getConfig()
    let last: HttpResult<T> = { ok: false, status: 0, data: null, error: '未发起请求' }
    for (let attempt = 0; attempt < 3; attempt++) {
      last = await throttled(() =>
        httpGetJson<T>(url, {
          proxy: config.proxy,
          timeoutMs: 20000,
          headers: { 'User-Agent': USER_AGENT }
        })
      )
      if (last.ok) return last
      const retryable = last.status === 503 || last.status === 429 || last.status === 0
      if (!retryable) return last
      await new Promise((resolve) => setTimeout(resolve, 1500 * (attempt + 1)))
    }
    return last
  }

  return {
    id: 'musicbrainz',
    label: 'MusicBrainz（音乐）',
    kinds: ['music'],
    requiresNetwork: true,

    async search(query: ProviderQuery): Promise<ProviderCandidate[]> {
      const titles = [query.title, ...query.alternates].slice(0, 2)
      const clauses = titles.map((title) => `releasegroup:"${title.replace(/"/g, '')}"`)
      const lucene = clauses.length > 1 ? `(${clauses.join(' OR ')})` : clauses[0]
      const withArtist = query.author ? `${lucene} AND artist:"${query.author.replace(/"/g, '')}"` : lucene

      let response = await mbGet<MbSearchResponse>(
        `${MB_ROOT}/release-group/?query=${encodeURIComponent(withArtist)}&fmt=json&limit=10`
      )
      if (!response.ok) throw new Error(response.error)
      let items = response.data?.['release-groups'] ?? []
      // 带艺术家搜不到时退一步：只用专辑名再搜一次，但要有结果宁多勿缺
      if (items.length === 0 && query.author) {
        response = await mbGet<MbSearchResponse>(
          `${MB_ROOT}/release-group/?query=${encodeURIComponent(lucene)}&fmt=json&limit=10`
        )
        if (response.ok) items = response.data?.['release-groups'] ?? []
      }
      return items.slice(0, 10).map(candidateOf)
    },

    async detail(candidate: ProviderCandidate): Promise<ProviderDetail> {
      const response = await mbGet<MbReleaseGroup>(
        `${MB_ROOT}/release-group/${candidate.id}?inc=artist-credits+genres+tags+ratings&fmt=json`
      )
      if (!response.ok || !response.data) throw new Error(response.error || '详情获取失败')
      const data = response.data
      const genres = (data.genres ?? []).map((genre) => genre.name)
      const tags = genres.length > 0 ? genres : (data.tags ?? []).map((tag) => tag.name)
      return {
        overview: data.disambiguation ? `MusicBrainz 说明：${data.disambiguation}` : '',
        genres: tags.slice(0, 8),
        rating: ratingOf(data.rating?.value),
        posterUrl: coverUrlOf(candidate.id),
        extra: {
          mbArtist: artistOf(data),
          primaryType: data['primary-type'] ?? '',
          secondaryTypes: data['secondary-types'] ?? [],
          releaseDate: data['first-release-date'] ?? '',
          releaseCount: (data.releases ?? []).length,
          mbUrl: `https://musicbrainz.org/release-group/${candidate.id}`
        }
      }
    }
  }
}
