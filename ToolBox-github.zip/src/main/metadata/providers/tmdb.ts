import type { MetadataConfig } from '@shared/types'
import { httpGetJson } from '../http'
import type { MetadataProvider, ProviderCandidate, ProviderDetail, ProviderQuery } from '../types'

/**
 * TMDB Provider（电影 / 电视剧 / 动漫）。
 * 只依赖 MetadataProvider 接口，业务层不需要知道 TMDB 的存在。
 *
 * 注意：TMDB 的 API 在国内网络下通常不可达，需要配置代理（设置里的「代理地址」）。
 * 失败时抛出中文原因，调用方会把它如实显示给用户，不会伪装成"没找到"。
 */

interface TmdbSearchItem {
  id: number
  title?: string
  name?: string
  original_title?: string
  original_name?: string
  release_date?: string
  first_air_date?: string
  vote_average?: number
  vote_count?: number
  popularity?: number
  overview?: string
  poster_path?: string | null
  backdrop_path?: string | null
  genre_ids?: number[]
  media_type?: string
}

interface TmdbSearchResponse {
  page: number
  total_results: number
  results: TmdbSearchItem[]
}

interface TmdbDetailResponse extends TmdbSearchItem {
  genres?: { id: number; name: string }[]
  runtime?: number
  episode_run_time?: number[]
  number_of_seasons?: number
  production_companies?: { name: string }[]
  production_countries?: { iso_3166_1: string; name: string }[]
  original_language?: string
  status?: string
  external_ids?: { imdb_id?: string | null; tvdb_id?: number | null }
}

const DEFAULT_IMAGE_BASE = 'https://image.tmdb.org/t/p'

function yearOf(item: TmdbSearchItem): number {
  const date = item.release_date || item.first_air_date || ''
  const year = Number.parseInt(date.slice(0, 4), 10)
  return Number.isFinite(year) && year > 1800 ? year : 0
}

function toCandidate(item: TmdbSearchItem, mediaType: 'movie' | 'tv', imageBase: string): ProviderCandidate {
  const popularity = Math.max(0, Math.min(1, (item.popularity ?? 0) / 200))
  const base = imageBase || DEFAULT_IMAGE_BASE
  return {
    source: 'tmdb',
    id: String(item.id),
    title: (item.title || item.name || '').trim(),
    originalTitle: (item.original_title || item.original_name || '').trim(),
    year: yearOf(item),
    author: '',
    popularity,
    coverUrl: item.poster_path ? `${base}/w500${item.poster_path}` : '',
    extra: {
      mediaType,
      posterPath: item.poster_path ?? '',
      backdropPath: item.backdrop_path ?? '',
      voteAverage: item.vote_average ?? 0,
      voteCount: item.vote_count ?? 0,
      overview: item.overview ?? '',
      genreIds: item.genre_ids ?? []
    }
  }
}

function mapDetail(data: TmdbDetailResponse, mediaType: 'movie' | 'tv', imageBase: string): ProviderDetail {
  const runtime = data.runtime ?? (data.episode_run_time && data.episode_run_time[0]) ?? 0
  const base = imageBase || DEFAULT_IMAGE_BASE
  return {
    overview: (data.overview || '').trim(),
    genres: (data.genres ?? []).map((genre) => genre.name),
    studio: data.production_companies?.[0]?.name ?? '',
    country: data.production_countries?.[0]?.iso_3166_1 ?? '',
    language: data.original_language ?? '',
    rating: data.vote_average ?? 0,
    posterUrl: data.poster_path ? `${base}/w500${data.poster_path}` : '',
    backdropUrl: data.backdrop_path ? `${base}/w1280${data.backdrop_path}` : '',
    extra: {
      tmdbId: data.id,
      mediaType,
      imdbId: data.external_ids?.imdb_id ?? '',
      runtime,
      seasons: data.number_of_seasons ?? 0,
      releaseDate: data.release_date || data.first_air_date || '',
      status: data.status ?? '',
      homepage: ''
    }
  }
}

export function createTmdbProvider(getConfig: () => MetadataConfig): MetadataProvider {
  const call = <T,>(url: string, config: MetadataConfig) =>
    httpGetJson<T>(url, { token: config.tmdbApiKey, proxy: config.proxy, timeoutMs: 15000 })

  return {
    id: 'tmdb',
    label: 'TMDB（影视）',
    kinds: ['movie', 'tv', 'anime'],
    requiresNetwork: true,

    async search(query: ProviderQuery): Promise<ProviderCandidate[]> {
      const config = getConfig()
      if (!config.tmdbApiKey) throw new Error('未配置 TMDB API Key（设置 → 元数据）')
      // 动漫在 TMDB 里就是 TV，用 tv 端点
      const mediaType: 'movie' | 'tv' = query.kind === 'movie' ? 'movie' : 'tv'
      const params = new URLSearchParams({ query: query.title, language: 'zh-CN', include_adult: 'false', page: '1' })
      if (query.year > 0) {
        params.set(mediaType === 'movie' ? 'primary_release_year' : 'first_air_date_year', String(query.year))
      }
      const first = await call<TmdbSearchResponse>(`${config.tmdbApiBase}/search/${mediaType}?${params}`, config)
      let items: TmdbSearchItem[] = []
      if (first.ok) {
        items = first.data?.results ?? []
      } else if (first.status !== 404) {
        // 401/429/超时等要如实抛出，不能当成"没找到"
        throw new Error(first.error)
      }
      // 带上年份没结果时退一步：不带年份再搜一次
      if (items.length === 0 && query.year > 0) {
        params.delete(mediaType === 'movie' ? 'primary_release_year' : 'first_air_date_year')
        const retry = await call<TmdbSearchResponse>(`${config.tmdbApiBase}/search/${mediaType}?${params}`, config)
        if (retry.ok) items = retry.data?.results ?? []
        else if (retry.status !== 404) throw new Error(retry.error)
      }
      return items.slice(0, 12).map((item) => toCandidate(item, mediaType, config.tmdbImageBase))
    },

    async detail(candidate: ProviderCandidate): Promise<ProviderDetail> {
      const config = getConfig()
      const mediaType = candidate.extra.mediaType === 'tv' ? 'tv' : 'movie'
      const url = `${config.tmdbApiBase}/${mediaType}/${candidate.id}?language=zh-CN&append_to_response=external_ids`
      const result = await call<TmdbDetailResponse>(url, config)
      if (!result.ok || !result.data) throw new Error(result.error || '详情获取失败')
      return mapDetail(result.data, mediaType, config.tmdbImageBase)
    }
  }
}
