import type { MetadataConfig } from '@shared/types'
import { httpGetJson } from '../http'
import type { MetadataProvider, ProviderCandidate, ProviderDetail, ProviderQuery } from '../types'

/**
 * Open Library Provider（小说）。
 *
 * ⚠️ 实测：本机网络下 openlibrary.org 与 covers.openlibrary.org **均连接超时**（被墙）。
 * 代码按接口写完整，挂上代理后即可生效；失败原因会如实回传给界面，不会假装"没找到"。
 */

const ROOT = 'https://openlibrary.org'
const COVER_ROOT = 'https://covers.openlibrary.org/b/id'

interface OpenLibraryDoc {
  key: string
  title?: string
  author_name?: string[]
  first_publish_year?: number
  cover_i?: number
  edition_count?: number
  language?: string[]
  subject?: string[]
  ia?: string[]
}

interface OpenLibrarySearch {
  numFound: number
  docs?: OpenLibraryDoc[]
}

interface OpenLibraryWork {
  title?: string
  description?: string | { value?: string }
  subjects?: string[]
  first_publish_date?: string
  covers?: number[]
  authors?: { author?: { key?: string } }[]
}

function yearOf(doc: { first_publish_year?: number; first_publish_date?: string }): number {
  if (doc.first_publish_year && doc.first_publish_year > 1800) return doc.first_publish_year
  const year = Number.parseInt((doc.first_publish_date ?? '').slice(-4), 10)
  return Number.isFinite(year) && year > 1800 ? year : 0
}

function toCandidate(doc: OpenLibraryDoc): ProviderCandidate {
  const coverId = doc.cover_i
  return {
    source: 'openlibrary',
    id: doc.key.replace('/works/', ''),
    title: (doc.title ?? '').trim(),
    originalTitle: (doc.title ?? '').trim(),
    year: yearOf(doc),
    author: (doc.author_name ?? []).join(', '),
    popularity: Math.max(0, Math.min(1, (doc.edition_count ?? 0) / 50)),
    coverUrl: coverId ? `${COVER_ROOT}/${coverId}-L.jpg` : '',
    extra: {
      workKey: doc.key,
      coverId: coverId ?? 0,
      languages: doc.language ?? [],
      subjects: (doc.subject ?? []).slice(0, 6),
      openLibraryUrl: `${ROOT}${doc.key}`
    }
  }
}

export function createOpenLibraryProvider(getConfig: () => MetadataConfig): MetadataProvider {
  const call = <T,>(url: string) => {
    const config = getConfig()
    return httpGetJson<T>(url, { proxy: config.proxy, timeoutMs: 20000 })
  }

  return {
    id: 'openlibrary',
    label: 'Open Library（小说）',
    kinds: ['novel'],
    requiresNetwork: true,

    async search(query: ProviderQuery): Promise<ProviderCandidate[]> {
      const params = new URLSearchParams({ title: query.title, limit: '8', fields: 'key,title,author_name,first_publish_year,cover_i,edition_count,language,subject' })
      if (query.author) params.set('author', query.author)
      let result = await call<OpenLibrarySearch>(`${ROOT}/search.json?${params}`)
      if (!result.ok) throw new Error(result.error)
      let docs = result.data?.docs ?? []
      // 标题+作者没结果时只用标题再搜一次
      if (docs.length === 0 && query.author) {
        params.delete('author')
        result = await call<OpenLibrarySearch>(`${ROOT}/search.json?${params}`)
        if (result.ok) docs = result.data?.docs ?? []
      }
      return docs.filter((doc) => doc.key && doc.title).map(toCandidate)
    },

    async detail(candidate: ProviderCandidate): Promise<ProviderDetail> {
      const workKey = (candidate.extra.workKey as string) || `/works/${candidate.id}`
      const result = await call<OpenLibraryWork>(`${ROOT}${workKey}.json`)
      if (!result.ok || !result.data) throw new Error(result.error || '详情获取失败')
      const data = result.data
      const description =
        typeof data.description === 'string' ? data.description : (data.description?.value ?? '')
      const coverId = (candidate.extra.coverId as number) || data.covers?.[0] || 0
      return {
        overview: description.slice(0, 1200),
        genres: (data.subjects ?? []).slice(0, 8),
        posterUrl: coverId ? `${COVER_ROOT}/${coverId}-L.jpg` : '',
        extra: {
          openLibraryUrl: `${ROOT}${workKey}`,
          subjects: (data.subjects ?? []).slice(0, 12)
        }
      }
    }
  }
}
