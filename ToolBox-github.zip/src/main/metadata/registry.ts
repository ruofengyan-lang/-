import type { ResourceKind } from '@shared/types'
import type { MetadataProvider, ProviderInfo } from './types'

/**
 * Provider 注册表。
 * Phase 3 只提供注册/查询能力，不注册任何真实 Provider —— 在线接口属于 Phase 4~7。
 * 业务层（匹配队列、匹配中心）只依赖这里的接口，接入新源不需要改业务代码。
 */
const providers = new Map<string, MetadataProvider>()

export function registerProvider(provider: MetadataProvider): void {
  providers.set(provider.id, provider)
}

export function unregisterProvider(id: string): void {
  providers.delete(id)
}

/** 是否注册了"仅自检"用的假 Provider（批量匹配会拒绝在这种状态下运行） */
export function hasTestProvider(): boolean {
  return [...providers.values()].some((provider) => provider.test === true)
}

export function getProvider(id: string): MetadataProvider | null {
  return providers.get(id) ?? null
}

export function allProviders(): MetadataProvider[] {
  return [...providers.values()]
}

/** 某类型可用的 Provider。includeTest=false 时排除自检用的假 Provider */
export function providersFor(kind: ResourceKind, online: boolean, includeTest = false): MetadataProvider[] {
  return allProviders().filter(
    (provider) =>
      (!provider.test || includeTest) && provider.kinds.includes(kind) && (online || !provider.requiresNetwork)
  )
}

/** 给界面/自检用的描述信息 */
export function describeProviders(): ProviderInfo[] {
  return allProviders().map((provider) => ({
    id: provider.id,
    label: provider.label,
    kinds: provider.kinds,
    requiresNetwork: provider.requiresNetwork,
    implemented: typeof provider.search === 'function'
  }))
}

/** 规划中的 Provider（还没实现时用于界面如实展示；现在四个都已实现） */
export const PLANNED_PROVIDERS: ProviderInfo[] = []

export function providerOverview(): ProviderInfo[] {
  return [...describeProviders(), ...PLANNED_PROVIDERS]
}
