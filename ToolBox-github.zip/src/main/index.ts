import { BrowserWindow, app, dialog, ipcMain, shell } from 'electron'
import fs from 'node:fs'
import fsp from 'node:fs/promises'
import path from 'node:path'
import type {
  AppConfig,
  LibraryPickResult,
  MatchStatus,
  MetadataRecord,
  ResourceKind,
  ResourceQuery,
  ScanProgress,
  StoredCandidate,
  ToastPayload,
  WallpaperStyleId
} from '@shared/types'
import * as actions from './actions'
import { appRoot, configDir, configPath, configStore, dataDir, publicConfig } from './config'
import * as db from './db'
import { clearIconCache, iconDataUrl } from './icons'
import * as library from './library'
import * as metadata from './metadata'
import { extractAuthor, pageNumberOf, parseSeries } from './classifier'
import { MEDIA_SCHEME, handleMediaProtocol, registerMediaSchemePrivileges, setAllowedRoots } from './protocol'
import * as resources from './resources'
import {
  clearThumbs,
  getThumbnail,
  initThumbs,
  shutdownThumbs,
  thumbCacheDir,
  thumbCacheStats,
  type ThumbSizeName
} from './thumbs'
import {
  powershellAvailable,
  readDesktopWallpaper,
  setDesktopWallpaper,
  setDesktopWallpaperFromData,
  setWallpaperRaw
} from './wallpaper'
import { readEpubMeta } from './mediainfo'

const isSmoke = process.argv.includes('--smoke')
const smokeWallpaper = process.argv.includes('--smoke-wallpaper')
const smokeScan = process.argv.includes('--smoke-scan')
const shotArg = process.argv.find((arg) => arg.startsWith('--shot='))
const shotPath = shotArg ? shotArg.slice('--shot='.length) : ''
const shotCategoryArg = process.argv.find((arg) => arg.startsWith('--shot-view='))
const shotView = shotCategoryArg ? shotCategoryArg.slice('--shot-view='.length) : ''
const shotSelectArg = process.argv.find((arg) => arg.startsWith('--shot-select='))
const shotSelect = shotSelectArg ? Number(shotSelectArg.slice('--shot-select='.length)) : -1
const shotClicks = process.argv
  .filter((arg) => arg.startsWith('--shot-click='))
  .map((arg) => arg.slice('--shot-click='.length))
const shotScrollArg = process.argv.find((arg) => arg.startsWith('--shot-scroll='))
const shotScroll = shotScrollArg ? shotScrollArg.slice('--shot-scroll='.length) : ''

let mainWindow: BrowserWindow | null = null
let boundsTimer: NodeJS.Timeout | null = null

registerMediaSchemePrivileges()

/* ============================ 路径安全 ============================ */

function managedRoots(): string[] {
  const roots = [appRoot(), configDir(), dataDir(), app.getPath('userData'), app.getPath('temp')]
  for (const lib of db.listLibraries()) roots.push(lib.path)
  return roots
}

function refreshAllowedRoots(): void {
  setAllowedRoots(managedRoots())
}

function isManagedPath(target: string): boolean {
  const normalized = path.resolve(target).toLowerCase()
  return managedRoots().some((root) => {
    const r = path.resolve(root).toLowerCase().replace(/[\\/]+$/, '')
    return normalized === r || normalized.startsWith(`${r}${path.sep}`)
  })
}

/* ============================ 窗口 ============================ */

function broadcastConfig(config: AppConfig): void {
  refreshAllowedRoots()
  // 发给渲染层的一律是脱敏副本（API Key 只写不读）
  mainWindow?.webContents.send('config:changed', publicConfig(config))
}

function sendToast(payload: ToastPayload): void {
  mainWindow?.webContents.send('toast', payload)
}

function sendIndexChanged(): void {
  // 索引变了：查询缓存必须失效，否则会读到旧列表
  resources.invalidateQueryCache()
  mainWindow?.webContents.send('index:changed')
}

function scheduleBoundsSave(): void {
  if (!mainWindow) return
  if (boundsTimer) clearTimeout(boundsTimer)
  boundsTimer = setTimeout(() => {
    if (!mainWindow || mainWindow.isDestroyed()) return
    const maximized = mainWindow.isMaximized()
    if (maximized || mainWindow.isMinimized() || mainWindow.isFullScreen()) {
      configStore.patch({ windowMaximized: maximized })
      return
    }
    const [width, height] = mainWindow.getSize()
    configStore.patch({ windowWidth: width, windowHeight: height, windowMaximized: false })
  }, 600)
}

function createWindow(): void {
  const config = configStore.all()
  const iconPath = path.join(app.getAppPath(), 'build', 'icon.ico')

  mainWindow = new BrowserWindow({
    width: config.windowWidth,
    height: config.windowHeight,
    minWidth: 960,
    minHeight: 620,
    show: false,
    title: '一站式本地资源管理中心',
    backgroundColor: '#0b356e',
    autoHideMenuBar: true,
    ...(fs.existsSync(iconPath) ? { icon: iconPath } : {}),
    webPreferences: {
      preload: path.join(__dirname, '../preload/index.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      spellcheck: false,
      devTools: !app.isPackaged
    }
  })

  mainWindow.once('ready-to-show', () => {
    if (config.windowMaximized) mainWindow?.maximize()
    mainWindow?.show()
    if (configStore.error) {
      sendToast({ type: 'error', text: `配置文件已损坏，已恢复默认设置（原文件已备份）：${configStore.error}` })
    }
  })

  mainWindow.on('resize', scheduleBoundsSave)
  mainWindow.on('move', scheduleBoundsSave)
  mainWindow.on('maximize', scheduleBoundsSave)
  mainWindow.on('unmaximize', scheduleBoundsSave)
  mainWindow.on('closed', () => {
    mainWindow = null
  })

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) void shell.openExternal(url)
    return { action: 'deny' }
  })
  mainWindow.webContents.on('will-navigate', (event, url) => {
    const devUrl = process.env.ELECTRON_RENDERER_URL
    if (devUrl && url.startsWith(devUrl)) return
    event.preventDefault()
  })

  const devUrl = process.env.ELECTRON_RENDERER_URL
  if (devUrl) void mainWindow.loadURL(devUrl)
  else void mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'))
}

/* ============================ IPC ============================ */

function registerIpc(): void {
  ipcMain.handle('app:info', () => {
    const stats = db.getStats()
    return {
      version: app.getVersion(),
      appRoot: appRoot(),
      configPath: configPath(),
      dataDir: dataDir(),
      packaged: app.isPackaged,
      platform: process.platform,
      powershell: powershellAvailable(),
      electron: process.versions.electron,
      chrome: process.versions.chrome,
      node: process.versions.node,
      resourceCount: stats.total
    }
  })

  ipcMain.handle('config:get', () => publicConfig(configStore.all()))
  ipcMain.handle('config:set', (_event, patch: Partial<AppConfig>) => {
    // API Key 不接受通用 patch 写入（避免渲染层用空值把它冲掉），只走 meta:setKey / meta:clearKey
    const safePatch: Partial<AppConfig> = { ...(patch && typeof patch === 'object' ? patch : {}) }
    if (safePatch.metadata) {
      const { tmdbApiKey: _ignored, ...rest } = safePatch.metadata
      safePatch.metadata = rest as AppConfig['metadata']
    }
    const config = configStore.patch(safePatch)
    broadcastConfig(config)
    return publicConfig(config)
  })

  /* ---------- API Key：只写不读 ---------- */

  ipcMain.handle('meta:setKey', (_event, value: unknown) => {
    const key = typeof value === 'string' ? value.trim() : ''
    const config = configStore.patch({ metadata: { ...configStore.all().metadata, tmdbApiKey: key } })
    broadcastConfig(config)
    return { ok: key.length > 0, hasKey: config.metadata.tmdbApiKey.length > 0 }
  })
  ipcMain.handle('meta:clearKey', () => {
    const config = configStore.patch({ metadata: { ...configStore.all().metadata, tmdbApiKey: '' } })
    broadcastConfig(config)
    return { ok: true, hasKey: false }
  })

  /* ---------- 资源库 ---------- */

  ipcMain.handle('library:list', () => db.listLibraries())

  ipcMain.handle('library:add', async (): Promise<LibraryPickResult> => {
    const { canceled, filePaths } = await dialog.showOpenDialog({
      title: '添加资源库目录（会递归扫描其中的所有文件）',
      properties: ['openDirectory', 'multiSelections']
    })
    if (canceled || filePaths.length === 0) return { ok: false, canceled: true }
    const added: string[] = []
    for (const dir of filePaths) {
      if (db.findLibraryByPath(dir)) continue
      db.addLibrary(dir)
      added.push(dir)
    }
    refreshAllowedRoots()
    sendIndexChanged()
    const libraries = db.listLibraries()
    if (added.length > 0) void startScan()
    return { ok: true, libraries, library: libraries[libraries.length - 1] }
  })

  ipcMain.handle('library:remove', (_event, id: unknown) => {
    if (typeof id !== 'number') return { ok: false, error: '参数无效' }
    db.removeLibrary(id)
    refreshAllowedRoots()
    sendIndexChanged()
    return { ok: true, message: '已移除资源库（只删除索引，不动磁盘文件）' }
  })

  ipcMain.handle('library:setEnabled', (_event, id: unknown, enabled: unknown) => {
    if (typeof id !== 'number') return { ok: false, error: '参数无效' }
    db.setLibraryEnabled(id, enabled === true)
    sendIndexChanged()
    return { ok: true }
  })

  /* ---------- 扫描 ---------- */

  const startScan = async (libraryId?: number): Promise<void> => {
    const config = configStore.all()
    await library.scanLibraries(config.scan, libraryId)
  }

  ipcMain.handle('scan:start', async (_event, libraryId: unknown) => {
    if (library.isScanning()) return { ok: false, error: '正在扫描中' }
    void startScan(typeof libraryId === 'number' ? libraryId : undefined)
    return { ok: true, message: '已开始扫描' }
  })
  ipcMain.handle('scan:pause', () => {
    library.pauseScan()
    return { ok: true }
  })
  ipcMain.handle('scan:resume', () => {
    library.resumeScan()
    return { ok: true }
  })
  ipcMain.handle('scan:cancel', () => {
    library.cancelScan()
    return { ok: true }
  })
  ipcMain.handle('scan:status', () => {
    const current = library.currentProgress()
    return current ? [current] : []
  })

  /* ---------- 资源查询 ---------- */

  ipcMain.handle('res:stats', () => resources.stats())
  ipcMain.handle('res:list', (_event, query: ResourceQuery) => resources.listResources(normalizeQuery(query)))
  ipcMain.handle('res:detail', (_event, id: unknown) =>
    typeof id === 'number' ? resources.detail(id) : null
  )
  ipcMain.handle('res:favorite', (_event, id: unknown) => {
    if (typeof id !== 'number') return { ok: false, error: '参数无效' }
    const item = resources.toggleFavorite(id)
    sendIndexChanged()
    return { ok: true, message: item?.isFavorite ? '已加入收藏' : '已取消收藏' }
  })
  ipcMain.handle('res:setKind', (_event, id: unknown, kind: unknown) => {
    if (typeof id !== 'number') return { ok: false, error: '参数无效' }
    const next = kind === null ? null : (kind as ResourceKind)
    const item = resources.setKind(id, next)
    sendIndexChanged()
    return { ok: true, message: item ? `已改为：${item.kind}` : '已恢复自动分类' }
  })
  ipcMain.handle('res:folders', (_event, libraryId: unknown, relDir: unknown) => {
    if (typeof libraryId !== 'number') return []
    return resources.folders(libraryId, typeof relDir === 'string' ? relDir : '')
  })
  ipcMain.handle('res:folderResources', (_event, libraryId: unknown, relDir: unknown) => {
    if (typeof libraryId !== 'number') return { total: 0, items: [] }
    return resources.folderResources(libraryId, typeof relDir === 'string' ? relDir : '')
  })
  ipcMain.handle('res:topFolders', () => resources.topFolders())

  /* ---------- 作品（系列）聚合：漫画墙 / 卷列表 ---------- */

  ipcMain.handle('res:series', (_event, kind: unknown, libraryId: unknown) =>
    resources.seriesList((kind as ResourceKind) ?? 'comic', typeof libraryId === 'number' ? libraryId : null)
  )
  ipcMain.handle('res:seriesDetail', async (_event, key: unknown) =>
    typeof key === 'string' && key ? resources.seriesDetail(key) : null
  )

  /* ---------- Phase 3：作品元数据（作品实体与本地文件分离） ---------- */

  ipcMain.handle('meta:get', (_event, seriesKey: unknown) =>
    typeof seriesKey === 'string' && seriesKey ? metadata.get(seriesKey) : null
  )
  ipcMain.handle('meta:overview', async () => {
    const stats = metadata.status()
    const view = metadata.overview()
    const config = configStore.all().metadata
    const cache = await metadata.cacheStats()
    return {
      ...stats,
      available: view.implemented,
      planned: view.planned,
      /** 只回报"有没有配置"，绝不把 Key 本身送到渲染层 */
      hasKey: config.tmdbApiKey.length > 0,
      online: config.online,
      proxy: config.proxy,
      apiBase: config.tmdbApiBase,
      posterCacheMB: cache.posterCacheMB
    }
  })
  ipcMain.handle('meta:list', (_event, status: unknown) =>
    metadata.list(typeof status === 'string' ? (status as MatchStatus) : undefined)
  )
  ipcMain.handle('meta:poster', (_event, seriesKey: unknown) => {
    if (typeof seriesKey !== 'string' || !seriesKey) return ''
    const record = metadata.get(seriesKey)
    return record?.posterPath ? metadata.posterAbsolute(record.posterPath) : ''
  })

  /* ---------- Phase 9：元数据匹配中心 ---------- */

  ipcMain.handle('matching:center', async () => {
    const stats = metadata.status()
    const view = metadata.overview()
    return {
      stats: { ...stats, available: view.implemented, planned: view.planned },
      rows: metadata.centerRows(),
      batch: metadata.batchProgress()
    }
  })
  ipcMain.handle('matching:candidates', (_event, seriesKey: unknown) =>
    typeof seriesKey === 'string' && seriesKey ? metadata.candidatesOf(seriesKey) : []
  )
  ipcMain.handle(
    'matching:confirm',
    async (_event, seriesKey: unknown, candidate: unknown) =>
      typeof seriesKey === 'string' && candidate && typeof candidate === 'object'
        ? metadata.confirmCandidate(seriesKey, candidate as StoredCandidate)
        : null
  )
  ipcMain.handle('matching:manual', (_event, seriesKey: unknown, patch: unknown) =>
    typeof seriesKey === 'string' && patch && typeof patch === 'object'
      ? metadata.saveManual(seriesKey, patch as Partial<MetadataRecord>)
      : null
  )
  ipcMain.handle('matching:reset', (_event, seriesKey: unknown) =>
    typeof seriesKey === 'string' && seriesKey ? metadata.resetToLocal(seriesKey) : null
  )
  ipcMain.handle('matching:reject', (_event, seriesKey: unknown) =>
    typeof seriesKey === 'string' && seriesKey ? metadata.rejectCandidates(seriesKey) : null
  )
  ipcMain.handle('matching:batchStart', (_event, options: unknown) => {
    const input = (options && typeof options === 'object' ? options : {}) as {
      status?: MatchStatus | 'all'
      kind?: ResourceKind | null
      limit?: number
    }
    return metadata.startBatch({
      status: input.status ?? 'all',
      kind: input.kind ?? null,
      limit: typeof input.limit === 'number' ? input.limit : 50
    })
  })
  ipcMain.handle('matching:batchCancel', () => {
    metadata.cancelBatch()
  })
  ipcMain.handle('meta:match', async (_event, seriesKey: unknown) => {
    if (typeof seriesKey !== 'string' || !seriesKey) return null
    const detail = await resources.seriesDetail(seriesKey)
    if (!detail) return null
    const decision = await metadata.matchSeries(
      { key: detail.series.key, kind: detail.series.kind, title: detail.series.title },
      { online: configStore.all().metadata.online, sampleName: detail.volumes[0]?.name }
    )
    return { decision, record: metadata.get(seriesKey) }
  })

  /* ---------- 缩略图 / 媒体信息 ---------- */

  ipcMain.handle(
    'thumb:get',
    async (_event, filePath: unknown, mtimeMs: unknown, kind: unknown, size: unknown) => {
      if (typeof filePath !== 'string' || !isManagedPath(filePath)) return null
      const ext = path.extname(filePath).toLowerCase()
      const sizeName: ThumbSizeName = size === 'detail' || size === 'icon' ? size : 'card'
      const file = await getThumbnail(
        {
          path: filePath,
          mtimeMs: typeof mtimeMs === 'number' ? mtimeMs : 0,
          kind: (kind as ResourceKind) ?? 'other',
          ext
        },
        sizeName
      ).catch(() => null)
      return file
    }
  )

  /* ---------- Phase 8：缓存统计与清理 ---------- */

  ipcMain.handle('cache:stats', async () => {
    const thumbs = await thumbCacheStats()
    const images = await metadata.cacheStats()
    return {
      thumbnailFiles: thumbs.files,
      thumbnailMB: Math.round((thumbs.bytes / 1024 / 1024) * 10) / 10,
      thumbnailBySize: Object.fromEntries(
        Object.entries(thumbs.bySize).map(([name, value]) => [
          name,
          { files: value.files, MB: Math.round((value.bytes / 1024 / 1024) * 10) / 10 }
        ])
      ),
      imageFiles: images.imageFiles,
      imageMB: images.imageMB,
      cacheDir: dataDir(),
      thumbDir: thumbCacheDir()
    }
  })
  ipcMain.handle('cache:clear', async (_event, target: unknown) => {
    if (target === 'images') return metadata.clearCachedImages()
    return clearThumbs()
  })

  ipcMain.handle('thumb:icon', async (_event, filePath: unknown, mtimeMs: unknown) => {
    if (typeof filePath !== 'string' || !isManagedPath(filePath)) return null
    return iconDataUrl(filePath, typeof mtimeMs === 'number' ? mtimeMs : 0)
  })

  ipcMain.handle('media:info', async (_event, filePath: unknown, kind: unknown) => {
    if (typeof filePath !== 'string' || !isManagedPath(filePath)) return null
    return resources.mediaInfo(filePath, (kind as ResourceKind) ?? 'other')
  })

  /* ---------- 文件操作 ---------- */

  ipcMain.handle('action:open', async (_event, idOrPath: unknown) => {
    let target = ''
    if (typeof idOrPath === 'number') {
      const item = resources.detail(idOrPath)
      if (!item) return { ok: false, error: '资源不存在' }
      target = item.path
      resources.markOpened(idOrPath)
    } else if (typeof idOrPath === 'string') {
      target = idOrPath
    } else {
      return { ok: false, error: '参数无效' }
    }
    if (!isManagedPath(target)) return { ok: false, error: '路径不在资源库内' }
    const confirm = await actions.confirmExecutable(target)
    if (!confirm.ok) return confirm
    return actions.openTarget(target)
  })

  ipcMain.handle('action:reveal', (_event, filePath: unknown) => {
    if (typeof filePath !== 'string' || !isManagedPath(filePath)) return { ok: false, error: '路径不在资源库内' }
    return actions.revealTarget(filePath)
  })

  ipcMain.handle('action:copyPath', (_event, filePath: unknown) => {
    if (typeof filePath !== 'string') return { ok: false, error: '路径无效' }
    return actions.copyPath(filePath)
  })

  ipcMain.handle('action:rename', async (_event, filePath: unknown, newName: unknown) => {
    if (typeof filePath !== 'string' || !isManagedPath(filePath)) return { ok: false, error: '路径不在资源库内' }
    if (typeof newName !== 'string') return { ok: false, error: '名称无效' }
    const result = await actions.renameTarget(filePath, newName)
    if (result.ok && result.path) {
      db.moveResource(filePath, result.path)
      clearIconCache()
      sendIndexChanged()
    }
    return result
  })

  ipcMain.handle('action:remove', async (_event, filePath: unknown, permanent: unknown) => {
    if (typeof filePath !== 'string' || !isManagedPath(filePath)) return { ok: false, error: '路径不在资源库内' }
    const result = await actions.deleteTarget(filePath, permanent === true)
    if (result.ok) {
      db.deleteResourceByPath(filePath)
      clearIconCache()
      sendIndexChanged()
    }
    return result
  })

  /* ---------- 桌面壁纸 / 工具箱背景 ---------- */

  ipcMain.handle('wallpaper:set', async (_event, filePath: unknown, style: unknown) => {
    if (typeof filePath !== 'string' || !isManagedPath(filePath)) return { ok: false, error: '路径不在资源库内' }
    return setDesktopWallpaper(filePath, (style ?? configStore.all().wallpaperStyle) as WallpaperStyleId)
  })

  ipcMain.handle('wallpaper:setData', async (_event, dataUrl: unknown, style: unknown) => {
    if (typeof dataUrl !== 'string') return { ok: false, error: '图片数据无效' }
    return setDesktopWallpaperFromData(dataUrl, (style ?? configStore.all().wallpaperStyle) as WallpaperStyleId)
  })

  ipcMain.handle('background:choose', async () => {
    const result = await actions.pickBackground()
    if (result.ok && result.config) broadcastConfig(result.config)
    return result
  })

  ipcMain.handle('background:reset', async () => {
    const result = await actions.resetBackground()
    if (result.ok && result.config) broadcastConfig(result.config)
    return result.config ?? configStore.all()
  })
}

function normalizeQuery(query: unknown): ResourceQuery {
  const raw = (query && typeof query === 'object' ? query : {}) as Partial<ResourceQuery>
  return {
    view: raw.view ?? 'all',
    kind: raw.kind ?? null,
    search: typeof raw.search === 'string' ? raw.search : '',
    libraryId: typeof raw.libraryId === 'number' ? raw.libraryId : null,
    folder: raw.folder ?? null,
    sort: raw.sort ?? 'name',
    order: raw.order ?? 'asc',
    offset: Math.max(0, Math.round(raw.offset ?? 0)),
    limit: Math.max(1, Math.min(2000, Math.round(raw.limit ?? 300)))
  }
}

/* ============================ 首次启动迁移 ============================ */

async function migrateLegacyLayout(): Promise<void> {
  refreshAllowedRoots()
  if (db.listLibraries().length > 0) return
  const config = configStore.all()
  const candidates: string[] = []
  const legacyRoot = (config.resourceRoot || '').trim()
  if (legacyRoot) candidates.push(path.isAbsolute(legacyRoot) ? legacyRoot : path.resolve(appRoot(), legacyRoot))
  candidates.push(appRoot())
  for (const candidate of candidates) {
    try {
      const stat = await fsp.stat(candidate)
      if (!stat.isDirectory()) continue
      db.addLibrary(candidate)
      void configStore.patch({ resourceRoot: '' })
      sendToast({ type: 'info', text: `已把 ${candidate} 设为资源库，开始建立索引…` })
      break
    } catch {
      /* 下一个候选 */
    }
  }
  refreshAllowedRoots()
}

/* ============================ 冒烟自检 ============================ */

/** 读 PNG 头拿到分辨率与颜色类型（验证图标清晰度与 alpha 是否保留） */
function pngResolution(file: string): string {
  try {
    const buffer = fs.readFileSync(file)
    if (buffer.length > 26 && buffer.toString('latin1', 1, 4) === 'PNG') {
      const width = buffer.readUInt32BE(16)
      const height = buffer.readUInt32BE(20)
      const colorType = buffer[25]
      const color = colorType === 6 ? 'RGBA' : colorType === 2 ? 'RGB' : `type${colorType}`
      return `${width}x${height} ${color}`
    }
  } catch {
    /* ignore */
  }
  return '?'
}

async function runSmoke(): Promise<void> {
  const report: Record<string, unknown> = {}
  const config = configStore.all()

  report.info = {
    version: app.getVersion(),
    appRoot: appRoot(),
    configDir: configDir(),
    dataDir: dataDir(),
    configPath: configPath(),
    packaged: app.isPackaged,
    powershell: powershellAvailable(),
    electron: process.versions.electron,
    node: process.versions.node
  }
  report.config = config
  report.libraries = db.listLibraries()

  if (smokeScan) {
    const before = Date.now()
    await library.scanLibraries(config.scan)
    report.scan = {
      ms: Date.now() - before,
      progress: library.currentProgress()
    }
  }

  report.stats = db.getStats()
  report.processStats = db.processStats()
  report.topFolders = db.listTopFolders().slice(0, 12)
  report.sampleMovie = db.queryResources({ view: 'all', kind: 'movie', sort: 'name', order: 'asc', offset: 0, limit: 3 })
  report.sampleMusic = db.queryResources({ view: 'all', kind: 'music', sort: 'name', order: 'asc', offset: 0, limit: 3 })
  report.sampleWallpaper = db.queryResources({ view: 'all', kind: 'wallpaper', sort: 'name', order: 'asc', offset: 0, limit: 2 })
  report.duplicates = db.queryResources({ view: 'duplicates', sort: 'size', order: 'desc', offset: 0, limit: 5 })
  report.search = db.queryResources({ view: 'all', search: 'DSC', sort: 'name', order: 'asc', offset: 0, limit: 3 })

  // Phase 2：漫画作品聚合抽检
  const comicSeries = db.listSeries('comic')
  report.comicSeries = comicSeries.map((item) => ({
    key: item.key,
    title: item.title,
    volumes: item.volumeCount,
    numbered: item.numberedCount,
    cover: item.coverPath
  }))
  if (comicSeries[0]) {
    const detail = await resources.seriesDetail(comicSeries[0].key).catch(() => null)
    report.comicSeriesDetail = detail
      ? {
          title: detail.series.title,
          volumes: detail.volumes.map((item) => `第${item.volume}卷 ${item.name}`),
          cover: detail.series.coverPath,
          location: `${detail.libraryPath}\\${detail.relDir}`
        }
      : null
  }
  report.zipKinds = db
    .queryResources({ view: 'all', kind: 'archive', sort: 'name', order: 'asc', offset: 0, limit: 20 })
    .items.map((item) => item.name)

  /* ---------- Phase 3：作品元数据 / Provider 层自检 ---------- */

  report.metadataStats = metadata.status()
  report.metadataProviders = metadata.overview()

  /* Provider 全链路自检：注册一个"只在自检里存在"的假 Provider，
     在一部**临时作品**上跑通 注册 → 搜索 → 打分 → 写库，跑完立刻删掉。
     绝不碰真实作品：早先版本用真实作品做靶子，结果脏数据写进了库里（踩过一次）。 */
  const testKey = 'smoke:provider-pipeline'
  db.deleteMetadata(testKey)
  metadata.registerProvider({
    id: 'smoke-only',
    label: '自检用临时 Provider（不会进入正式运行）',
    kinds: ['comic', 'novel'],
    requiresNetwork: false,
    test: true,
    async search(query) {
      return [
        {
          source: 'smoke-only',
          id: 'smoke-1',
          title: query.title,
          originalTitle: 'SMOKE ORIGINAL TITLE',
          year: 2020,
          author: '自检作者',
          popularity: 1,
          coverUrl: '',
          extra: {}
        }
      ]
    },
    async detail() {
      return { overview: '自检返回的简介', genres: ['自检'], rating: 8.5 }
    }
  })
  {
    const decision = await metadata.matchSeries(
      { key: testKey, kind: 'comic', title: 'Pipeline Test Title' },
      // online 必须为 true，否则 matchSeries 会直接返回"在线匹配已关闭"，
      // 这个自检就会静默变成空操作（踩过一次：从 Phase 4 起它其实一直在空跑）
      { online: true, includeTest: true }
    )
    const written = db.getMetadata(testKey)
    report.providerPipeline = {
      seriesKey: testKey,
      providerCount: decision.providerCount,
      status: decision.status,
      confidence: decision.confidence,
      /** 自检必须真的跑到链路：matched 才算通过 */
      ok: decision.status === 'matched' && Boolean(written),
      writtenSource: written?.externalSource ?? '',
      writtenTitle: written?.title ?? '',
      writtenOriginalTitle: written?.originalTitle ?? '',
      writtenAuthor: written?.author ?? '',
      writtenOverview: written?.overview ?? '',
      writtenRating: written?.rating ?? 0,
      writtenGenres: written?.genres ?? []
    }
    db.deleteMetadata(testKey)
    report.providerPipelineCleaned = db.getMetadata(testKey) === null
    // 用完立刻注销，绝不让它参与后续任何真实匹配
    metadata.unregisterProvider('smoke-only')
  }

  // 在线匹配全链路（需显式加 --smoke-online，且配置里开启联网）
  if (process.argv.includes('--smoke-online')) {
    const config = configStore.all().metadata
    const probeSeries = async (kind: ResourceKind, label: string, index = 0): Promise<void> => {
      const series = db.listSeries(kind)[index]
      if (!series) return
      const started = Date.now()
      const decision = await metadata.matchSeries(
        { key: series.key, kind, title: series.title },
        { online: true, sampleName: db.seriesVolumes(series.key)[0]?.name }
      )
      const record = db.getMetadata(series.key)
      let posterBytes = 0
      if (record?.posterPath) {
        try {
          posterBytes = fs.statSync(metadata.posterAbsolute(record.posterPath)).size
        } catch {
          posterBytes = -1
        }
      }
      report[`${label}OnlineMatch`] = {
        series: series.title,
        volumes: series.volumeCount,
        ms: Date.now() - started,
        onlineEnabled: config.online,
        hasKey: config.tmdbApiKey.length > 0,
        apiBase: config.tmdbApiBase,
        imageBase: config.tmdbImageBase,
        providerCount: decision.providerCount,
        status: decision.status,
        confidence: decision.confidence,
        reason: decision.reason,
        source: record?.externalSource ?? '',
        matchedTitle: record?.title ?? '',
        originalTitle: record?.originalTitle ?? '',
        year: record?.year ?? 0,
        rating: record?.rating ?? 0,
        genres: record?.genres ?? [],
        overview: (record?.overview ?? '').slice(0, 50),
        posterPath: record?.posterPath ?? '',
        posterBytes,
        backdropPath: record?.backdropPath ?? ''
      }
    }
    await probeSeries('movie', 'movie')
    await probeSeries('music', 'music')
    await probeSeries('comic', 'comic')
    // 第二张专辑：用来验证"封面源熔断"是否生效（第一次超时后不该再白等）
    await probeSeries('music', 'music2', 1)
    report.blockedImageHosts = metadata.blockedImageHosts()
  }

  /* ---------- Phase 9：匹配中心自检 ---------- */

  const centerRows = metadata.centerRows()
  const centerByStatus: Record<string, number> = {}
  for (const row of centerRows) centerByStatus[row.matchStatus] = (centerByStatus[row.matchStatus] ?? 0) + 1
  report.matchingCenter = {
    total: centerRows.length,
    byStatus: centerByStatus,
    rowsWithCandidates: centerRows.filter((row) => row.candidateCount > 0).length,
    sample: centerRows.slice(0, 4).map((row) => ({
      title: row.title,
      kind: row.kind,
      status: row.matchStatus,
      source: row.externalSource,
      candidates: row.candidateCount
    }))
  }

  // 只跑某一类作品的批量匹配（自检用）：--smoke-batch-kind=novel
  const batchKindArg = process.argv.find((arg) => arg.startsWith('--smoke-batch-kind='))
  if (batchKindArg) {
    const kind = batchKindArg.slice('--smoke-batch-kind='.length) as ResourceKind
    const started = metadata.startBatch({ status: 'all', kind, limit: 500 })
    const deadline = Date.now() + 20 * 60 * 1000
    while (metadata.batchProgress()?.running && Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 1000))
    }
    const finalProgress = metadata.batchProgress()
    report.batchKind = { kind, startedTotal: started.total, ...finalProgress }
    const rows = metadata.centerRows().filter((row) => row.kind === kind)
    report.batchKindRows = rows.map(
      (row) => `${row.title} | ${row.matchStatus} | ${row.externalSource} | ${row.year} | ${row.author}`
    )
  }

  if (process.argv.includes('--smoke-batch-all')) {
    // 全库批量匹配：所有类型、所有非已匹配作品，跑到底（自检用）
    const started = metadata.startBatch({ status: 'all', kind: null, limit: 500 })
    const deadline = Date.now() + 25 * 60 * 1000
    let lastDone = -1
    while (metadata.batchProgress()?.running && Date.now() < deadline) {
      const current = metadata.batchProgress()
      if (current && current.done !== lastDone && current.done % 5 === 0) {
        lastDone = current.done
        process.stdout.write(
          `[batch] ${current.done}/${current.total} 成功 ${current.matched} 待确认 ${current.pending} 失败 ${current.failed}\n`
        )
      }
      await new Promise((resolve) => setTimeout(resolve, 500))
    }
    const finalProgress = metadata.batchProgress()
    report.batchAll = { startedTotal: started.total, ...finalProgress }
    const byKindStatus: Record<string, Record<string, number>> = {}
    for (const row of metadata.centerRows()) {
      byKindStatus[row.kind] = byKindStatus[row.kind] ?? {}
      byKindStatus[row.kind][row.matchStatus] = (byKindStatus[row.kind][row.matchStatus] ?? 0) + 1
    }
    report.batchAllByKind = byKindStatus
    report.batchAllMatched = metadata
      .centerRows()
      .filter((row) => row.matchStatus === 'matched' || row.matchStatus === 'confirmed')
      .slice(0, 12)
      .map((row) => `${row.kind} | ${row.title} | ${row.externalSource} | ${row.year} | ${row.author}`)
  }

  if (process.argv.includes('--smoke-batch')) {
    const started = metadata.startBatch({ status: 'local', kind: 'music', limit: 4 })
    const deadline = Date.now() + 120000
    while (metadata.batchProgress()?.running && Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 500))
    }
    report.batchRun = metadata.batchProgress()
    report.batchResult = metadata
      .centerRows()
      .filter((row) => row.kind === 'music' && row.matchStatus !== 'local')
      .slice(0, 6)
      .map((row) => ({
        title: row.title,
        status: row.matchStatus,
        source: row.externalSource,
        year: row.year,
        author: row.author,
        candidates: row.candidateCount
      }))
    void started
  }

  if (process.argv.includes('--smoke-confirm')) {
    // 挑一部"待确认且有候选"的作品，人工确认第一个候选（验证匹配中心的人工挑选链路）
    const target = metadata.centerRows().find((row) => row.matchStatus === 'pending' && row.candidateCount > 0)
    if (target) {
      const list = metadata.candidatesOf(target.seriesKey)
      // 像人一样挑：只认作者对得上的候选；一个都对不上就保持"待确认"，不乱写数据
      const localAuthor = target.author
      const picked = list.find(
        (item) => localAuthor && item.author && (item.author.includes(localAuthor) || localAuthor.includes(item.author))
      )
      const confirmReport: Record<string, unknown> = {
        localTitle: target.title,
        localAuthor,
        candidatesBefore: list.length,
        candidatesSample: list.slice(0, 3).map((item) => `${item.title} / ${item.author || '-'} / ${item.year || '-'}`),
        picked: picked ? `${picked.title} / ${picked.author}` : '(没有作者对得上的候选 → 保持待确认)'
      }
      if (picked) {
        const record = await metadata.confirmCandidate(target.seriesKey, picked)
        confirmReport.afterStatus = record?.matchStatus ?? ''
        confirmReport.afterSource = record?.externalSource ?? ''
        confirmReport.afterAuthor = record?.author ?? ''
        confirmReport.afterYear = record?.year ?? 0
        confirmReport.afterGenres = record?.genres ?? []
      } else {
        confirmReport.afterStatus = metadata.get(target.seriesKey)?.matchStatus ?? ''
      }
      report.confirmRun = confirmReport
    } else {
      report.confirmRun = { skipped: '没有"待确认且有候选"的作品' }
    }
  }

  // 定向重置某部作品（开发自检用）：--smoke-reset-series=<seriesKey>
  const resetArg = process.argv.find((arg) => arg.startsWith('--smoke-reset-series='))
  if (resetArg) {
    const key = resetArg.slice('--smoke-reset-series='.length)
    const record = metadata.resetToLocal(key)
    report.resetRun = record
      ? { seriesKey: key, title: record.title, author: record.author, status: record.matchStatus }
      : { seriesKey: key, error: '找不到该作品' }
  }

  // 按来源批量重置（清理污染数据用）：--smoke-reset-source=<source>
  const resetSourceArg = process.argv.find((arg) => arg.startsWith('--smoke-reset-source='))
  if (resetSourceArg) {
    const source = resetSourceArg.slice('--smoke-reset-source='.length)
    const targets = metadata.list().filter((record) => record.externalSource === source)
    const cleaned: string[] = []
    for (const record of targets) {
      const next = metadata.resetToLocal(record.seriesKey)
      if (next) cleaned.push(`${record.seriesKey} → ${next.title} / ${next.author || '-'} / ${next.matchStatus}`)
    }
    report.resetSourceRun = { source, count: cleaned.length, cleaned: cleaned.slice(0, 20) }
  }

  /* ---------- Phase 8：多尺寸缩略图缓存自检 ---------- */

  const sizeSample =
    db.queryResources({ view: 'all', kind: 'wallpaper', sort: 'name', order: 'asc', offset: 0, limit: 1 }).items[0] ??
    db.queryResources({ view: 'all', kind: 'movie', sort: 'name', order: 'asc', offset: 0, limit: 1 }).items[0]
  if (sizeSample) {
    const req = { path: sizeSample.path, mtimeMs: sizeSample.mtimeMs, kind: sizeSample.kind, ext: sizeSample.ext }
    const card = await getThumbnail(req, 'card').catch(() => null)
    const detail = await getThumbnail(req, 'detail').catch(() => null)
    const describe = (file: string | null): string =>
      file ? `${pngResolution(file)} · ${Math.round(fs.statSync(file).size / 1024)}KB` : '(无)'
    report.thumbSizes = {
      name: sizeSample.name,
      card: describe(card),
      detail: describe(detail),
      cardPath: card ? path.relative(dataDir(), card) : '',
      detailPath: detail ? path.relative(dataDir(), detail) : ''
    }
  }
  report.thumbCache = await thumbCacheStats()

  /* ---------- Phase 6：文件名解析 + 散图聚合 + 新 Provider 自检 ---------- */

  // 文件名清洗/解析自检：脏名字应该被解析成干净的作品名与作者
  const nameCases = [
    '《示例书名》作者：示例作者.txt',
    '《示例书名》（精校版全书） 作者：示例作者.txt',
    '【全本】示例书名 作者：示例作者 www.example.com.txt',
    '[汉化组] ONE PIECE 第001卷 [1080p].cbz',
    '某漫画 Vol.12.cbz',
    '某漫画 03.pdf',
    'one piece 001.zip',
    '漫画\\第01卷\\001.jpg',
    'p07.webp'
  ]
  report.nameParsing = nameCases.map((sample) => {
    const kind: ResourceKind = /\.(jpg|webp|png)$/i.test(sample) ? 'comic' : 'comic'
    const parsed = parseSeries(sample.split('\\').pop() ?? sample, kind)
    const authored = extractAuthor(sample.split('\\').pop() ?? sample)
    return {
      输入: sample,
      作品名: parsed.seriesTitle,
      卷号: parsed.volume,
      作者: authored.author || '',
      页码: pageNumberOf(sample.split('\\').pop() ?? sample) || ''
    }
  })

  // 散图漫画目录聚合结果（扫描阶段跑的）
  report.comicAggregate = library.lastAggregateResult()
  report.comicSeries = db
    .listSeries('comic')
    .map((series) => ({ title: series.title, volumes: series.volumeCount, cover: series.coverPath.split('\\').pop() }))

  // 新 Provider 直连自检：需要 --smoke-providers（用真实网络查询已知条目）
  if (process.argv.includes('--smoke-providers')) {
    const probeProvider = async (id: string, title: string, kind: ResourceKind): Promise<unknown> => {
      const provider = metadata.getProvider(id)
      if (!provider) return { id, error: 'Provider 未注册' }
      const started = Date.now()
      try {
        const candidates = await provider.search({
          kind,
          title,
          alternates: [],
          year: 0,
          author: ''
        })
        return {
          id,
          label: provider.label,
          ms: Date.now() - started,
          count: candidates.length,
          top: candidates.slice(0, 3).map((item) => `${item.title} / ${item.originalTitle} / ${item.year} / ${item.author}`),
          cover: candidates[0]?.coverUrl ? '有' : '无'
        }
      } catch (err) {
        return { id, ms: Date.now() - started, error: err instanceof Error ? err.message : String(err) }
      }
    }
    report.providerProbes = [
      await probeProvider('anilist', 'ONE PIECE', 'comic'),
      await probeProvider('anilist', '進撃の巨人', 'anime'),
      await probeProvider('anilist', 'Naruto', 'comic'),
      await probeProvider('openlibrary', 'Pride and Prejudice', 'novel'),
      await probeProvider('musicbrainz', 'Thriller', 'music')
    ]
  }

  // 按标记批量重置（清理自检残留用）：--smoke-reset-mark=SMOKE
  const resetMarkArg = process.argv.find((arg) => arg.startsWith('--smoke-reset-mark='))
  if (resetMarkArg) {
    const mark = resetMarkArg.slice('--smoke-reset-mark='.length)
    const targets = metadata
      .list()
      .filter((record) => record.originalTitle.includes(mark) || record.overview.includes(mark))
    const cleaned: string[] = []
    for (const record of targets) {
      const next = metadata.resetToLocal(record.seriesKey)
      if (next) cleaned.push(`${record.seriesKey} → ${next.matchStatus} / 原名已清:${next.originalTitle === ''}`)
    }
    report.resetMarkRun = { mark, count: cleaned.length, cleaned: cleaned.slice(0, 20) }
  }

  /* ---------- Phase 10：性能自检 ---------- */

  const cacheQuery: ResourceQuery = { view: 'all', sort: 'name', order: 'asc', offset: 0, limit: 120 }
  const cacheStart = Date.now()
  const firstRead = resources.cachedList(cacheQuery)
  const firstMs = Date.now() - cacheStart
  const cacheSecondStart = Date.now()
  const secondRead = resources.cachedList(cacheQuery)
  const secondMs = Date.now() - cacheSecondStart
  report.queryCache = {
    firstMs,
    secondMs,
    sameTotal: firstRead.total === secondRead.total,
    ...resources.queryCacheStats()
  }
  report.queryPlans = {
    分类列表: db.explainPlan(
      `SELECT r.id FROM resources r JOIN libraries l ON l.id = r.library_id WHERE l.enabled = 1 AND r.kind = 'music' ORDER BY r.sort_name ASC LIMIT 120`
    ),
    最近使用: db.explainPlan(
      `SELECT r.id FROM resources r JOIN libraries l ON l.id = r.library_id WHERE l.enabled = 1 AND r.open_count > 0 ORDER BY r.last_opened DESC LIMIT 120`
    )
  }
  report.dbSizeMB = db.databaseSizeMB()

  report.metadataRows = db.listMetadata().slice(0, 12).map((record) => ({    seriesKey: record.seriesKey,
    title: record.title,
    author: record.author,
    status: record.matchStatus,
    source: record.externalSource || '(空)',
    confidence: record.matchConfidence
  }))
  report.works = db.listSeries('comic').length + db.listSeries('novel').length + db.listSeries('movie').length
  report.workSeriesSample = ['comic', 'novel', 'movie']
    .flatMap((kind) => db.listSeries(kind as ResourceKind).slice(0, 3))
    .map((series) => ({ kind: series.kind, title: series.title, volumes: series.volumeCount }))

  // 清洗 / 打分 / 决策：纯函数，离线就能验证
  const query = metadata.buildQuery({ name: '[汉化组] 海贼王 第001卷 [1080p].cbz', kind: 'comic' })
  const exact = {
    source: 'test',
    id: '1',
    title: '海贼王',
    originalTitle: 'ONE PIECE',
    year: 1999,
    author: '尾田荣一郎',
    popularity: 0.9,
    coverUrl: '',
    extra: {}
  }
  const medium = { ...exact, id: '2', title: '海贼王 剧场版', originalTitle: '', popularity: 0.1 }
  const wrong = { ...exact, id: '3', title: '完全无关的作品名', originalTitle: 'Unrelated Thing', year: 2015 }
  const twin = { ...exact, id: '4', source: 'test2' }
  const wrongYear = { ...exact, id: '5', year: 1980 }
  report.matcherTests = {
    cleaned: query.title,
    alternates: query.alternates,
    year: query.year,
    exactScore: Number(metadata.scoreCandidate(query, exact).score.toFixed(3)),
    mediumScore: Number(metadata.scoreCandidate(query, medium).score.toFixed(3)),
    wrongScore: Number(metadata.scoreCandidate(query, wrong).score.toFixed(3)),
    decisionExact: metadata.decideMatch(query, [exact]).status,
    decisionAmbiguous: metadata.decideMatch(query, [exact, medium]).status,
    decisionTie: metadata.decideMatch(query, [exact, twin]).status,
    decisionWrong: metadata.decideMatch(query, [wrong]).status,
    decisionEmpty: metadata.decideMatch(query, []).status,
    // 带年份的查询：年份差 19 分应明显掉下来
    yearAwareScore: Number(
      metadata.scoreCandidate({ ...query, year: 1999 }, exact).score.toFixed(3)
    ),
    yearMismatchScore: Number(
      metadata.scoreCandidate({ ...query, year: 1999 }, wrongYear).score.toFixed(3)
    )
  }

  // EPUB 判定抽检：小说与漫画的区分依据 + 封面提取结果
  const epubProbe = db
    .queryResources({ view: 'all', kind: 'novel', sort: 'name', order: 'asc', offset: 0, limit: 30 })
    .items.filter((item) => item.ext === '.epub')
  report.novelEpubs = []
  const novelEpubProbe: unknown[] = []
  for (const item of epubProbe.slice(0, 12)) {
    const meta = await readEpubMeta(item.path).catch(() => null)
    novelEpubProbe.push({
      name: item.name,
      coverBytes: meta?.coverData ? meta.coverData.length : 0,
      pages: meta?.pages ?? 0,
      images: meta?.imageCount ?? 0,
      avgTextPerPage: meta?.avgTextPerPage ?? 0
    })
  }
  report.novelEpubs = novelEpubProbe
  const comicEpubs = db
    .queryResources({ view: 'all', kind: 'comic', sort: 'name', order: 'asc', offset: 0, limit: 30 })
    .items.filter((item) => item.ext === '.epub')
  report.comicEpubs = []
  const comicEpubProbe: unknown[] = []
  for (const item of comicEpubs.slice(0, 12)) {
    const meta = await readEpubMeta(item.path).catch(() => null)
    comicEpubProbe.push({
      name: item.name,
      series: item.seriesTitle,
      volume: item.volume,
      coverBytes: meta?.coverData ? meta.coverData.length : 0,
      pages: meta?.pages ?? 0,
      images: meta?.imageCount ?? 0,
      avgTextPerPage: meta?.avgTextPerPage ?? 0
    })
  }
  report.comicEpubs = comicEpubProbe

  // 缩略图与元数据抽样
  const music = db.queryResources({ view: 'all', kind: 'music', sort: 'size', order: 'desc', offset: 0, limit: 1 }).items[0]
  if (music) {
    const thumb = await getThumbnail({ path: music.path, mtimeMs: music.mtimeMs, kind: 'music', ext: music.ext }).catch(() => null)
    const media = await resources.mediaInfo(music.path, 'music').catch(() => null)
    report.musicTest = { name: music.name, thumb: Boolean(thumb), title: media?.title, artist: media?.artist, album: media?.album, durationMs: media?.durationMs }
  }
  const movie = db.queryResources({ view: 'all', kind: 'movie', sort: 'size', order: 'desc', offset: 0, limit: 1 }).items[0]
  if (movie) {
    const thumb = await getThumbnail({ path: movie.path, mtimeMs: movie.mtimeMs, kind: 'movie', ext: movie.ext }).catch(() => null)
    const media = await resources.mediaInfo(movie.path, 'movie').catch(() => null)
    report.movieTest = { name: movie.name, thumb: Boolean(thumb), width: media?.width, height: media?.height, durationMs: media?.durationMs, cardLine: movie.cardLine }
  }
  const archives = db.queryResources({ view: 'all', kind: 'archive', sort: 'size', order: 'desc', offset: 0, limit: 1 }).items[0]
  if (archives) {
    const media = await resources.mediaInfo(archives.path, 'archive').catch(() => null)
    report.archiveTest = { name: archives.name, innerKind: media?.innerKind, innerSummary: media?.innerSummary }
  }

  // 图标/缩略图分辨率抽检：安装包与压缩包应该拿到 256px 高分辨率图标，而不是 48px
  const probeImage = async (kind: ResourceKind, label: string): Promise<void> => {
    const item = db.queryResources({ view: 'all', kind, sort: 'size', order: 'desc', offset: 0, limit: 1 }).items[0]
    if (!item) return
    const file = await getThumbnail({
      path: item.path,
      mtimeMs: item.mtimeMs,
      kind,
      ext: item.ext
    }).catch(() => null)
    report[`${label}ImageTest`] = {
      name: item.name,
      generated: Boolean(file),
      resolution: file ? pngResolution(file) : '',
      bytes: file ? fs.statSync(file).size : 0
    }
  }
  await probeImage('installer', 'installer')
  await probeImage('archive', 'archive')
  await probeImage('movie', 'movie')

  if (smokeWallpaper) {
    const wallpaper = db.queryResources({ view: 'all', kind: 'wallpaper', sort: 'name', order: 'asc', offset: 0, limit: 1 }).items[0]
    if (wallpaper) {
      const before = await readDesktopWallpaper()
      const applied = await setDesktopWallpaper(wallpaper.path, config.wallpaperStyle)
      report.wallpaperTest = { file: wallpaper.name, previous: before, result: applied } as Record<string, unknown>
      if (before) {
        const restored = await setWallpaperRaw(before, config.wallpaperStyle)
        ;(report.wallpaperTest as Record<string, unknown>).restore = restored
      }
    }
  }

  // 渲染进程自检
  const rendererErrors: string[] = []
  const renderer = new BrowserWindow({
    width: 1440,
    height: 900,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, '../preload/index.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  })
  renderer.webContents.on('console-message', (details) => {
    if (details.level === 'error' || details.level === 'warning') {
      rendererErrors.push(`[${details.level}] ${details.message}`)
    }
  })
  renderer.webContents.on('did-fail-load', (_e, code, desc) => {
    rendererErrors.push(`did-fail-load ${code} ${desc}`)
  })

  const loaded = new Promise<void>((resolve) => {
    renderer.webContents.once('did-finish-load', () => resolve())
    setTimeout(() => resolve(), 15000)
  })
  const devUrl = process.env.ELECTRON_RENDERER_URL
  if (devUrl) await renderer.loadURL(devUrl)
  else await renderer.loadFile(path.join(__dirname, '../renderer/index.html'))
  await loaded
  await new Promise((resolve) => setTimeout(resolve, 1500))

  const domProbe = await renderer.webContents
    .executeJavaScript(
      `(async () => {
         const deadline = Date.now() + 10000
         let nav = 0
         while (Date.now() < deadline) {
           nav = document.querySelectorAll('.nav-item').length
           if (nav > 0) break
           await new Promise((r) => setTimeout(r, 200))
         }
         return {
           nav,
           navLabels: Array.from(document.querySelectorAll('.nav-name')).map((el) => el.textContent),
           homeCards: document.querySelectorAll('.kind-tile').length,
           drawer: document.querySelector('.drawer') !== null,
           drawerTitle: document.querySelector('.drawer-title h2')?.textContent ?? '',
           tiles: document.querySelectorAll('.tile').length,
           hint: document.querySelector('.hint-text')?.textContent ?? '',
           version: document.querySelector('.status-version')?.textContent ?? '',
           api: typeof window.toolbox === 'object',
           toasts: Array.from(document.querySelectorAll('.toast')).map((el) => el.textContent)
         }
       })()`,
      true
    )
    .catch((err: Error) => ({ probeError: err.message }))

  report.renderer = { loaded: true, errors: rendererErrors, dom: domProbe }

  // 交互自检：点开一张卡片 → 详情抽屉应出现；再点「更多」→ 菜单应出现
  const interactProbe = await renderer.webContents
    .executeJavaScript(
      `(async () => {
         const out = { drawerOpened: false, drawerTitle: '', drawerRows: 0, drawerActions: 0, moreItems: [], drawerClosed: false }
         // 先切到「全部资源」，保证网格里有卡片
         const navItems = Array.from(document.querySelectorAll('.nav-item'))
         const allView = navItems.find((el) => (el.querySelector('.nav-name')?.textContent ?? '').trim() === '全部资源')
         if (allView) allView.dispatchEvent(new MouseEvent('click', { bubbles: true }))
         const gridDeadline = Date.now() + 5000
         while (Date.now() < gridDeadline) {
           if (document.querySelectorAll('.grid .tile').length > 0) break
           await new Promise((r) => setTimeout(r, 150))
         }
         out.gridTiles = document.querySelectorAll('.grid .tile').length
         // Phase 10：虚拟滚动自检——滚动前后渲染的卡片数应远小于总数，且窗口内容会变
         const scroller = (() => {
           let node = document.querySelector('.grid-wrap')
           while (node) {
             const style = getComputedStyle(node)
             if (/(auto|scroll)/.test(style.overflowY) && node.scrollHeight > node.clientHeight - 1) return node
             node = node.parentElement
           }
           return null
         })()
         if (scroller) {
           scroller.scrollTop = 0
           await new Promise((r) => setTimeout(r, 300))
           const beforeCount = document.querySelectorAll('.grid .tile').length
           const beforeFirst = document.querySelector('.grid .tile .tile-label')?.textContent ?? ''
           scroller.scrollTop = 2400
           await new Promise((r) => setTimeout(r, 400))
           out.virtualGrid = {
             virtualClass: document.querySelector('.grid-wrap.virtual') !== null,
             total: document.querySelector('.grid-foot')?.textContent?.trim() ?? '',
             beforeCount,
             afterCount: document.querySelectorAll('.grid .tile').length,
             beforeFirst,
             afterFirst: document.querySelector('.grid .tile .tile-label')?.textContent ?? ''
           }
           scroller.scrollTop = 0
           await new Promise((r) => setTimeout(r, 200))
         }
         const tiles = Array.from(document.querySelectorAll('.grid .tile'))
         if (tiles[0]) tiles[0].dispatchEvent(new MouseEvent('click', { bubbles: true }))
         const deadline = Date.now() + 4000
         while (Date.now() < deadline) {
           if (document.querySelector('.drawer')) break
           await new Promise((r) => setTimeout(r, 120))
         }
         const drawer = document.querySelector('.drawer')
         if (drawer) {
           out.drawerOpened = true
           out.drawerTitle = document.querySelector('.drawer-title h2')?.textContent ?? ''
           out.drawerRows = drawer.querySelectorAll('.info-row').length
           out.drawerActions = drawer.querySelectorAll('button').length
           // 抽屉里所有「键 → 值」，用来验证元数据区块确实渲染了
           out.drawerInfo = Array.from(drawer.querySelectorAll('.info-row')).map((row) => {
             const key = row.querySelector('.info-key')?.textContent ?? ''
             const value = row.querySelector('.info-val')?.textContent ?? ''
             return key + '=' + value
           })
           const posterBox = drawer.querySelector('.drawer-poster')
           const posterImg = drawer.querySelector('.drawer-poster img')
           if (posterBox) {
             const rect = posterBox.getBoundingClientRect()
             out.posterBox = { w: Math.round(rect.width), h: Math.round(rect.height) }
           }
           if (posterImg) {
             const rect = posterImg.getBoundingClientRect()
             out.posterImg = {
               w: Math.round(rect.width),
               h: Math.round(rect.height),
               natural: posterImg.naturalWidth + 'x' + posterImg.naturalHeight
             }
           }
           const cardImg = document.querySelector('.grid .tile .tile-thumb img')
           if (cardImg) {
             const rect = cardImg.getBoundingClientRect()
             out.cardImg = {
               w: Math.round(rect.width),
               h: Math.round(rect.height),
               natural: cardImg.naturalWidth + 'x' + cardImg.naturalHeight
             }
           }
           const closeBtn = drawer.querySelector('.drawer-close')
           if (closeBtn) closeBtn.dispatchEvent(new MouseEvent('click', { bubbles: true }))
           await new Promise((r) => setTimeout(r, 400))
           out.drawerClosed = document.querySelector('.drawer') === null
         }
         // 再切到「电影」看一次：影视属于作品实体，抽屉里应出现「作品信息」区块
         const movieNav = Array.from(document.querySelectorAll('.nav-item')).find(
           (el) => (el.querySelector('.nav-name')?.textContent ?? '').trim() === '电影'
         )
         if (movieNav) {
           movieNav.dispatchEvent(new MouseEvent('click', { bubbles: true }))
           const isMovieActive = () =>
             Array.from(document.querySelectorAll('.nav-item')).some(
               (el) =>
                 el.classList.contains('active') &&
                 (el.querySelector('.nav-name')?.textContent ?? '').trim() === '电影'
             )
           const deadline2 = Date.now() + 6000
           while (Date.now() < deadline2) {
             if (isMovieActive() && document.querySelectorAll('.grid .tile').length > 0) break
             await new Promise((r) => setTimeout(r, 150))
           }
           out.movieViewActive = isMovieActive()
           const movieTile = document.querySelector('.grid .tile')
           if (movieTile) movieTile.dispatchEvent(new MouseEvent('click', { bubbles: true }))
           const deadline3 = Date.now() + 4000
           while (Date.now() < deadline3) {
             if (document.querySelector('.drawer')) break
             await new Promise((r) => setTimeout(r, 120))
           }
           const workDrawer = document.querySelector('.drawer')
           if (workDrawer) {
             out.workDrawerRows = Array.from(workDrawer.querySelectorAll('.info-row')).map((row) => {
               const key = row.querySelector('.info-key')?.textContent ?? ''
               const value = row.querySelector('.info-val')?.textContent ?? ''
               return key + '=' + value
             })
             out.workDrawerSections = Array.from(workDrawer.querySelectorAll('.drawer-section-title')).map(
               (el) => el.textContent
             )
           }
         }
         const moreBtn = Array.from(document.querySelectorAll('.topbar-tools .tool-btn')).find((el) =>
           (el.textContent ?? '').includes('更多')
         )
         if (moreBtn) {
           moreBtn.dispatchEvent(new MouseEvent('click', { bubbles: true }))
           await new Promise((r) => setTimeout(r, 300))
           out.moreItems = Array.from(document.querySelectorAll('.ctx-item')).map((el) => (el.textContent ?? '').trim())
           window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }))
         }
         return out
       })()`,
      true
    )
    .catch((err: Error) => ({ probeError: err.message }))
  report.interactProbe = interactProbe

  // API Key「只写不读」自检：写进去、读回来必须是空，只有 hasKey 变化
  const keyProbe = await renderer.webContents
    .executeJavaScript(
      `(async () => {
         const before = await window.toolbox.getConfig()
         await window.toolbox.metaSetKey('smoke-key-not-a-real-secret-000000')
         const after = await window.toolbox.getConfig()
         const cleared = await window.toolbox.metaClearKey()
         const finalConfig = await window.toolbox.getConfig()
         return {
           beforeHasKey: before.metadata.tmdbKeySet === true,
           beforeValueLeaked: before.metadata.tmdbApiKey !== '',
           afterHasKey: after.metadata.tmdbKeySet === true,
           afterValueLeaked: after.metadata.tmdbApiKey !== '',
           clearedHasKey: cleared.hasKey,
           finalHasKey: finalConfig.metadata.tmdbKeySet === true,
           finalValueLeaked: finalConfig.metadata.tmdbApiKey !== ''
         }
       })()`,
      true
    )
    .catch((err: Error) => ({ probeError: err.message }))
  report.apiKeyProbe = keyProbe
  report.apiKeyInMainAfterProbe = configStore.all().metadata.tmdbApiKey.length > 0

  renderer.destroy()

  const text = `\n===== TOOLBOX_SMOKE =====\n${JSON.stringify(report, null, 2)}\n===== END =====\n`
  process.stdout.write(text)
  try {
    const outFile = path.join(app.getAppPath(), 'smoke-report.json')
    await fsp.writeFile(outFile, `${JSON.stringify(report, null, 2)}\n`, 'utf8')
    process.stdout.write(`SMOKE_REPORT_FILE ${outFile}\n`)
  } catch {
    /* 打包后 asar 内不可写，忽略 */
  }
  await new Promise((resolve) => setTimeout(resolve, 400))
}

/* ============================ 截图（验收用） ============================ */

async function captureWindowShot(window: BrowserWindow): Promise<void> {
  const waitFor = async (expression: string, timeoutMs = 12000): Promise<boolean> =>
    (await window.webContents.executeJavaScript(
      `(async () => {
         const deadline = Date.now() + ${timeoutMs}
         while (Date.now() < deadline) {
           if (${expression}) return true
           await new Promise((resolve) => setTimeout(resolve, 150))
         }
         return false
       })()`,
      true
    )) as boolean

  try {
    await waitFor(`document.querySelectorAll('.nav-item').length > 0`)
    if (shotView) {
      // 先等这个分类出现在侧栏（统计返回前分类项还没渲染，直接点会静默失败）
      await waitFor(
        `Array.from(document.querySelectorAll('.nav-name')).some((el) => (el.textContent ?? '').trim() === ${JSON.stringify(shotView)})`
      )
      await window.webContents.executeJavaScript(
        `(() => {
           const target = Array.from(document.querySelectorAll('.nav-item'))
             .find((el) => (el.querySelector('.nav-name')?.textContent ?? '').trim() === ${JSON.stringify(shotView)})
           if (target) target.dispatchEvent(new MouseEvent('click', { bubbles: true }))
           return Boolean(target)
         })()`,
        true
      )
      await waitFor(`(document.querySelector('.nav-item.active .nav-name')?.textContent ?? '').trim() === ${JSON.stringify(shotView)}`)
    }
    await waitFor(`document.querySelectorAll('.tile, .kind-tile').length > 0`)
    // 需要截"详情抽屉"状态时，先点开第 N 张卡片
    if (shotSelect >= 0) {
      await window.webContents.executeJavaScript(
        `(() => {
           const tiles = Array.from(document.querySelectorAll('.grid .tile'))
           const target = tiles[${shotSelect}]
           if (target) target.dispatchEvent(new MouseEvent('click', { bubbles: true }))
           return Boolean(target)
         })()`,
        true
      )
      await waitFor(`document.querySelector('.drawer') !== null`, 6000)
    }
    // 需要点击（可多次，按顺序；例如抽屉里的「刷新信息」、或 更多 → 设置…）
    for (const text of shotClicks) {
      await window.webContents.executeJavaScript(
        `(() => {
           const target = Array.from(document.querySelectorAll('button, .ctx-item')).find((el) =>
             (el.textContent ?? '').trim().includes(${JSON.stringify(text)})
           )
           if (target) target.dispatchEvent(new MouseEvent('click', { bubbles: true }))
           return Boolean(target)
         })()`,
        true
      )
      await new Promise((resolve) => setTimeout(resolve, 2500))
    }
    // 需要看抽屉下半部分时，先滚动到指定区块
    if (shotScroll) {
      await window.webContents.executeJavaScript(
        `(() => {
           const target = Array.from(document.querySelectorAll('.drawer-section-title, .drawer-section, div, section'))
             .find((el) => (el.textContent ?? '').trim().startsWith(${JSON.stringify(shotScroll)}))
           if (target) target.scrollIntoView({ block: 'center' })
           return Boolean(target)
         })()`,
        true
      )
      await new Promise((resolve) => setTimeout(resolve, 600))
    }
    await new Promise((resolve) => setTimeout(resolve, 3000))
    const image = await window.webContents.capturePage()
    await fsp.writeFile(shotPath, image.toPNG())
    process.stdout.write(`SHOT_SAVED ${shotPath}\n`)
  } catch (err) {
    process.stdout.write(`SHOT_FAILED ${err instanceof Error ? err.message : String(err)}\n`)
  }
  setTimeout(() => app.exit(0), 300)
}

/* ============================ 生命周期 ============================ */

app.setAppUserModelId('com.yx.toolbox')

// 兜底：任何未捕获的异常都要留下痕迹，不能静默挂住
process.on('unhandledRejection', (reason) => {
  const text = reason instanceof Error ? reason.stack ?? reason.message : String(reason)
  process.stderr.write(`[fatal] unhandledRejection: ${text}\n`)
  if (isSmoke) app.exit(1)
})
process.on('uncaughtException', (error) => {
  process.stderr.write(`[fatal] uncaughtException: ${error.stack ?? error.message}\n`)
  if (isSmoke) app.exit(1)
})

// 自检与截图模式绕开单实例锁：否则应用正在运行时，截图进程会被转交给已有窗口而拿不到画面
const gotLock = isSmoke || Boolean(shotPath) ? true : app.requestSingleInstanceLock()
if (!gotLock) {
  app.quit()
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore()
      mainWindow.focus()
    }
  })

  app.whenReady().then(async () => {
    const trace = (step: string): void => {
      if (isSmoke) process.stdout.write(`[boot] ${step}\n`)
    }
    trace('ready')
    handleMediaProtocol()
    configStore.load()
    trace(`config loaded: ${configPath()}`)
    db.initDatabase(dataDir())
    trace(`db ready: ${dataDir()}`)
    await initThumbs(dataDir())
    trace('thumbs ready')
    await metadata.init({ dataDir: dataDir(), getConfig: () => configStore.all().metadata })
    // 批量匹配进度转给渲染进程
    metadata.onBatchProgress((progress) => mainWindow?.webContents.send('matching:batch', progress))
    trace('metadata ready')
    library.onScanProgress((progress: ScanProgress) => {
      mainWindow?.webContents.send('scan:progress', progress)
    })
    library.onIndexChanged(() => sendIndexChanged())
    await migrateLegacyLayout()
    trace(`libraries: ${db.listLibraries().map((l) => l.path).join(' | ') || '(none)'}`)
    refreshAllowedRoots()
    registerIpc()
    trace('ipc registered')

    if (isSmoke) {
      try {
        await runSmoke()
      } catch (err) {
        process.stdout.write(`\nSMOKE_FAILED ${err instanceof Error ? err.stack ?? err.message : String(err)}\n`)
        app.exit(1)
        return
      }
      app.exit(0)
      return
    }

    createWindow()

    if (shotPath && mainWindow) {
      const window = mainWindow
      window.webContents.once('did-finish-load', () => {
        void captureWindowShot(window)
      })
    }

    // 启动后：先读索引（界面秒开），再后台增量扫描
    if (db.listLibraries().some((l) => l.enabled)) {
      setTimeout(() => {
        const config = configStore.all()
        void library.scanLibraries(config.scan)
      }, 1200)
    }

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow()
    })
  })

  app.on('window-all-closed', () => {
    app.quit()
  })

  app.on('before-quit', () => {
    library.cancelScan()
    void shutdownThumbs()
    db.closeDatabase()
  })
}

export { MEDIA_SCHEME }
