import { net, protocol } from 'electron'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

/**
 * 自定义协议 toolbox-media://local/?p=<绝对路径>
 * 渲染进程不能直接访问 file://（默认被 Electron 阻止），
 * 所以图片缩略图 / 背景图都通过这个协议读取，并且只允许资源根目录内的文件。
 */
export const MEDIA_SCHEME = 'toolbox-media'

export function registerMediaSchemePrivileges(): void {
  protocol.registerSchemesAsPrivileged([
    {
      scheme: MEDIA_SCHEME,
      privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true }
    }
  ])
}

let allowedRoots: string[] = []

export function setAllowedRoots(roots: string[]): void {
  allowedRoots = roots
    .filter((r) => typeof r === 'string' && r.trim().length > 0)
    .map((r) => path.resolve(r).toLowerCase().replace(/[\\/]+$/, ''))
}

function isInsideAllowed(target: string): boolean {
  const normalized = path.resolve(target).toLowerCase()
  return allowedRoots.some((root) => normalized === root || normalized.startsWith(`${root}${path.sep}`))
}

export function handleMediaProtocol(): void {
  protocol.handle(MEDIA_SCHEME, async (request) => {
    try {
      const url = new URL(request.url)
      const raw = url.searchParams.get('p')
      if (!raw) return new Response('missing path', { status: 400 })
      const target = path.resolve(decodeURIComponent(raw))
      if (!isInsideAllowed(target)) return new Response('forbidden', { status: 403 })
      return await net.fetch(pathToFileURL(target).toString())
    } catch (err) {
      return new Response(`media error: ${err instanceof Error ? err.message : String(err)}`, { status: 500 })
    }
  })
}
