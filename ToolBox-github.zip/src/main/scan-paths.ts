import os from 'node:os'
import path from 'node:path'

/** 程序自身的开发/构建/缓存目录，绝不当成资源 */
export const APP_DIR_NAMES = [
  'node_modules', 'out', 'dist', 'release', 'build', 'src', 'scripts',
  'toolbox', 'toolbox-src', '.git', '.github', '.vscode', '.idea', '.vite',
  '.cache', '.tmp', 'thumbnails', '__pycache__'
]

/** 兼容旧配置项的字段名 */
export const DEFAULT_EXCLUDE_DIRS = APP_DIR_NAMES

const denylistRaw = [
  process.env.SystemRoot ?? 'C:\\Windows',
  process.env.ProgramFiles ?? 'C:\\Program Files',
  process.env['ProgramFiles(x86)'] ?? 'C:\\Program Files (x86)',
  process.env.ProgramData ?? 'C:\\ProgramData',
  path.join(os.homedir(), 'AppData'),
  path.join(os.homedir(), 'Application Data'),
  'C:\\$Recycle.Bin',
  'C:\\Recovery',
  'C:\\PerfLogs',
  'C:\\System Volume Information'
]

/** 默认不扫描的 Windows 系统目录（用户主动添加资源库也不会进去） */
export const SYSTEM_DENY = denylistRaw.map((p) => path.resolve(p).toLowerCase().replace(/[\\/]+$/, ''))

export function isDeniedSystemPath(absPath: string): boolean {
  const p = path.resolve(absPath).toLowerCase()
  return SYSTEM_DENY.some((root) => p === root || p.startsWith(`${root}${path.sep}`))
}

const SKIP_FILE_NAMES = new Set(['desktop.ini', 'thumbs.db', '.ds_store', 'iconcache.db', 'ehthumbs.db'])

export function isHiddenName(name: string): boolean {
  return name.startsWith('.') || name.startsWith('$') || SKIP_FILE_NAMES.has(name.toLowerCase())
}

export function isNoiseFile(name: string): boolean {
  const lower = name.toLowerCase()
  return SKIP_FILE_NAMES.has(lower) || lower.startsWith('~$') || lower.endsWith('.tmp')
}

export function isVirtualDirName(name: string): boolean {
  return APP_DIR_NAMES.includes(name.toLowerCase())
}

/** 综合判断一个目录是否要跳过 */
export function shouldSkipDir(name: string, absPath: string, includeHidden: boolean): boolean {
  if (isVirtualDirName(name)) return true
  if (!includeHidden && isHiddenName(name)) return true
  if (isDeniedSystemPath(absPath)) return true
  return false
}
