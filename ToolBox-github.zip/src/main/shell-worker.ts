import { spawn } from 'node:child_process'
import fsp from 'node:fs/promises'
import path from 'node:path'

/**
 * Windows Shell 缩略图 worker（批量）：
 * 用 IShellItemImageFactory 取系统缩略图 —— 视频首帧、PDF 首页、音频专辑封面、
 * Office 文档预览等都由 Windows 自己的缩略图提供程序生成，不需要 ffmpeg。
 * 已验证：4 个文件（含 C# 编译）约 0.7 秒。
 */
const PS_SOURCE = String.raw`
param(
  [Parameter(Mandatory = $true)][string]$Batch,
  [Parameter(Mandatory = $true)][string]$OutDir,
  [Parameter(Mandatory = $false)][int]$Size = 512,
  [Parameter(Mandatory = $false)][switch]$IconOnly
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

namespace TBThumb {
  [StructLayout(LayoutKind.Sequential)]
  public struct SIZE { public int cx; public int cy; }

  [ComImport, Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  public interface IShellItemImageFactory {
    [PreserveSig] int GetImage(SIZE size, int flags, out IntPtr phbm);
  }

  public static class Native {
    [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
    public static extern void SHCreateItemFromParsingName(
      [MarshalAs(UnmanagedType.LPWStr)] string path, IntPtr pbc, ref Guid riid,
      [MarshalAs(UnmanagedType.Interface)] out object shellItem);

    [DllImport("gdi32.dll")]
    public static extern bool DeleteObject(IntPtr hObject);
  }

  public static class Api {
    static readonly Guid IID_IShellItemImageFactory = new Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b");

    /** 返回 HBITMAP 句柄，0 表示系统没有可用图像；flags=9 缩略图 / flags=5 仅图标（取高分辨率程序图标） */
    public static IntPtr ThumbHandle(string path, int size, int flags) {
      Guid iid = IID_IShellItemImageFactory;
      object factoryObj;
      Native.SHCreateItemFromParsingName(path, IntPtr.Zero, ref iid, out factoryObj);
      var factory = (IShellItemImageFactory)factoryObj;
      SIZE sz; sz.cx = size; sz.cy = size;
      // SIIGBF_RESIZETOFIT(0) | SIIGBF_BIGGERSIZEOK(1) | SIIGBF_THUMBNAILONLY(8)
      IntPtr hbm;
      int hr = factory.GetImage(sz, flags, out hbm);
      Marshal.ReleaseComObject(factoryObj);
      if (hr != 0) return IntPtr.Zero;
      return hbm;
    }
  }
}
'@

New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$items = Get-Content -LiteralPath $Batch -Raw -Encoding UTF8 | ConvertFrom-Json
# 9 = THUMBNAILONLY（真实缩略图：视频首帧、PDF 首页…）
# 5 = BIGGERSIZEOK|ICONONLY（高分辨率图标：exe 程序图标、压缩包关联图标…）
$flags = if ($IconOnly) { 5 } else { 9 }
$result = New-Object System.Collections.ArrayList
foreach ($it in $items) {
  $entry = [ordered]@{ id = $it.id; ok = $false; error = $null }
  try {
    if (-not (Test-Path -LiteralPath $it.path)) { throw 'file not found' }
    $file = Join-Path $OutDir ("$($it.id).png")
    $hbm = [TBThumb.Api]::ThumbHandle($it.path, $Size, $flags)
    if ($hbm -ne [IntPtr]::Zero) {
      try {
        # 优先用 WPF 转换：保留 alpha 通道（图标透明区域不会变黑）
        try {
          $src = [System.Windows.Interop.Imaging]::CreateBitmapSourceFromHBitmap(
            $hbm, [IntPtr]::Zero,
            [System.Windows.Int32Rect]::Empty,
            [System.Windows.Media.Imaging.BitmapSizeOptions]::FromEmptyOptions())
          $encoder = New-Object System.Windows.Media.Imaging.PngBitmapEncoder
          $encoder.Frames.Add([System.Windows.Media.Imaging.BitmapFrame]::Create($src))
          $stream = [System.IO.File]::Create($file)
          try { $encoder.Save($stream) } finally { $stream.Close() }
        } catch {
          # 退回 System.Drawing（无 alpha，但至少能出图）
          $img = [System.Drawing.Image]::FromHbitmap($hbm)
          try { $img.Save($file, [System.Drawing.Imaging.ImageFormat]::Png) } finally { $img.Dispose() }
        }
        $entry.ok = $true
      } finally {
        [TBThumb.Native]::DeleteObject($hbm) | Out-Null
      }
    }
  } catch {
    $entry.error = $_.Exception.Message
  }
  [void]$result.Add($entry)
}
$json = $result | ConvertTo-Json -Depth 4 -Compress
if ($result.Count -eq 1) { $json = "[$json]" }
[System.IO.File]::WriteAllText((Join-Path $OutDir 'result.json'), $json, (New-Object System.Text.UTF8Encoding($false)))
Write-Output "DONE $($result.Count)"
`

export interface ShellThumbRequest {
  id: string
  path: string
}

export interface ShellThumbResult {
  id: string
  ok: boolean
  file: string
  error: string
}

let scriptPath = ''
let workRoot = ''

/** 把 worker 脚本写到磁盘（只写一次），返回脚本路径 */
export async function prepareShellWorker(dataDir: string): Promise<string> {
  if (scriptPath) return scriptPath
  const dir = path.join(dataDir, 'workers')
  await fsp.mkdir(dir, { recursive: true })
  const file = path.join(dir, 'shell-thumbs.ps1')
  // 必须带 UTF-8 BOM：PowerShell 5.1 读取无 BOM 的 .ps1 会按 ANSI(GBK) 解码，
  // 脚本里的中文注释会被拆成乱码字节，进而破坏语法解析。
  await fsp.writeFile(file, `\ufeff${PS_SOURCE}`, 'utf8')
  scriptPath = file
  workRoot = path.join(dataDir, 'worker-tmp')
  await fsp.mkdir(workRoot, { recursive: true })
  return file
}

function runPowerShell(args: string[], timeoutMs: number): Promise<{ code: number; stdout: string; stderr: string }> {
  return new Promise((resolve) => {
    let stdout = ''
    let stderr = ''
    let settled = false
    const child = spawn('powershell.exe', args, { windowsHide: true })
    const timer = setTimeout(() => {
      if (settled) return
      settled = true
      try {
        child.kill()
      } catch {
        /* ignore */
      }
      resolve({ code: -1, stdout, stderr: `${stderr}\n缩略图 worker 超时` })
    }, timeoutMs)
    child.stdout?.on('data', (chunk: Buffer) => {
      stdout += chunk.toString('utf8')
    })
    child.stderr?.on('data', (chunk: Buffer) => {
      stderr += chunk.toString('utf8')
    })
    child.on('error', (err) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve({ code: -2, stdout, stderr: `无法启动 powershell.exe：${err.message}` })
    })
    child.on('close', (code) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve({ code: code ?? -3, stdout, stderr })
    })
  })
}

let batchSeq = 0

/** 批量生成缩略图或高分辨率图标，返回每个 id 对应的 PNG 文件路径 */
export async function runShellThumbnails(
  requests: ShellThumbRequest[],
  size = 512,
  iconOnly = false
): Promise<ShellThumbResult[]> {
  if (requests.length === 0) return []
  if (!scriptPath) throw new Error('Shell worker 尚未初始化')
  const outDir = path.join(workRoot, `batch-${Date.now()}-${batchSeq++}`)
  await fsp.mkdir(outDir, { recursive: true })
  const batchFile = path.join(outDir, 'batch.json')
  await fsp.writeFile(batchFile, JSON.stringify(requests), 'utf8')

  const timeout = Math.max(20000, requests.length * 4000)
  const result = await runPowerShell(
    [
      '-NoProfile',
      '-NonInteractive',
      '-ExecutionPolicy',
      'Bypass',
      '-File',
      scriptPath,
      '-Batch',
      batchFile,
      '-OutDir',
      outDir,
      '-Size',
      String(size),
      ...(iconOnly ? ['-IconOnly'] : [])
    ],
    timeout
  )

  const results: ShellThumbResult[] = []
  try {
    const raw = await fsp.readFile(path.join(outDir, 'result.json'), 'utf8')
    const parsed = JSON.parse(raw) as { id: string; ok: boolean; error: string | null }[]
    const list = Array.isArray(parsed) ? parsed : [parsed]
    for (const entry of list) {
      results.push({
        id: String(entry.id),
        ok: Boolean(entry.ok),
        file: path.join(outDir, `${entry.id}.png`),
        error: entry.error ?? ''
      })
    }
  } catch {
    // 整批失败：给每个请求返回失败，并把 stderr 带回去便于排查
    const detail = (result.stderr || result.stdout || '').trim().split(/\r?\n/).slice(-3).join(' | ')
    for (const request of requests) {
      results.push({ id: request.id, ok: false, file: '', error: detail || `worker 退出码 ${result.code}` })
    }
  }
  return results
}

export async function cleanupWorkerTemp(): Promise<void> {
  if (!workRoot) return
  try {
    await fsp.rm(workRoot, { recursive: true, force: true })
    await fsp.mkdir(workRoot, { recursive: true })
  } catch {
    /* ignore */
  }
}
