import { baseNameOf, extOf } from '@shared/resource-kinds'
import type {
  FolderNode,
  LibraryStats,
  MediaInfo,
  ResourceDetail,
  ResourceKind,
  ResourcePage,
  ResourceQuery,
  SeriesDetail,
  SeriesItem
} from '@shared/types'
import { makeCardLine } from './classifier'
import * as db from './db'
import { posterAbsolute } from './metadata'
import {
  findSidecarCover,
  guessZipContent,
  readAudioTags,
  readEpubMeta,
  readImageSize,
  readVideoInfo,
  readZipEntries
} from './mediainfo'

/** 查询层：视图 / 分类 / 搜索 / 收藏 / 最近 / 重复 */
export function listResources(query: ResourceQuery): ResourcePage {
  return cachedList(query)
}

/* ============================ Phase 10：查询缓存 ============================ */

const QUERY_CACHE_LIMIT = 40
let queryCache = new Map<string, ResourcePage>()
let cacheHits = 0
let cacheMisses = 0

/** 索引或数据变化时调用：清空缓存，下次查询重新读库 */
export function invalidateQueryCache(): void {
  queryCache = new Map()
}

export function queryCacheStats(): { size: number; hits: number; misses: number } {
  return { size: queryCache.size, hits: cacheHits, misses: cacheMisses }
}

/**
 * 列表查询 + LRU 缓存。
 * 同一个视图反复切换（或同一批分页重复请求）时不再重复打数据库；
 * 任何写操作都会清空缓存（见 invalidateQueryCache），保证不会读到旧数据。
 */
export function cachedList(query: ResourceQuery): ResourcePage {
  const key = JSON.stringify(query)
  const hit = queryCache.get(key)
  if (hit) {
    cacheHits++
    // LRU：命中后挪到末尾
    queryCache.delete(key)
    queryCache.set(key, hit)
    return hit
  }
  cacheMisses++
  const page = db.queryResources(query)
  queryCache.set(key, page)
  if (queryCache.size > QUERY_CACHE_LIMIT) {
    const oldest = queryCache.keys().next().value
    if (oldest !== undefined) queryCache.delete(oldest)
  }
  return page
}

export function stats(): LibraryStats {
  return db.getStats()
}

export function detail(id: number): ResourceDetail | null {
  return db.getResourceById(id)
}

export function toggleFavorite(id: number): ResourceDetail | null {
  const item = db.getResourceById(id)
  if (!item) return null
  db.setFavorite(id, !item.isFavorite)
  invalidateQueryCache()
  return db.getResourceById(id)
}

/** 手动修改分类：overridden=1 后扫描不会再覆盖；kind=null 表示恢复自动识别 */
export function setKind(id: number, kind: ResourceKind | null): ResourceDetail | null {
  const item = db.getResourceById(id)
  if (!item) return null
  const next = kind ?? item.autoKind
  const cardLine = makeCardLine({
    kind: next,
    ext: item.ext,
    size: item.size,
    width: item.width,
    height: item.height,
    durationMs: item.durationMs,
    year: item.year,
    artist: item.artist,
    album: item.album,
    innerKind: typeof item.meta.innerKind === 'string' ? item.meta.innerKind : ''
  })
  db.setResourceKind(id, next, kind !== null, cardLine)
  invalidateQueryCache()
  return db.getResourceById(id)
}

export function markOpened(id: number): void {
  db.markOpened(id)
  // 打开次数影响"最近使用"视图，缓存必须失效
  invalidateQueryCache()
}

export function folders(libraryId: number, relDir: string): FolderNode[] {
  return db.listFolders(libraryId, relDir)
}

export function folderResources(libraryId: number, relDir: string): ResourcePage {
  const items = db.listFolderResources(libraryId, relDir)
  return { total: items.length, items }
}

export function topFolders(): FolderNode[] {
  return db.listTopFolders()
}

/* ============================ 作品（系列） ============================ */

export function seriesList(kind: ResourceKind, libraryId?: number | null): SeriesItem[] {
  return db.listSeries(kind, libraryId)
}

/** 一部作品的详情：卷列表 + 封面 + 所在位置 */
export async function seriesDetail(key: string): Promise<SeriesDetail | null> {
  const volumes = db.seriesVolumes(key)
  if (volumes.length === 0) return null
  const location = db.seriesLocation(key)
  const first = volumes[0]

  // 封面优先级：在线海报（已缓存到本地）→ 本地同目录封面 → 第一卷（包内首图由缩略图管线处理）
  const record = db.getMetadata(key)
  let coverPath = record?.posterPath ? posterAbsolute(record.posterPath) : ''
  if (!coverPath) coverPath = await findSidecarCover(first.path).catch(() => '')
  if (!coverPath) coverPath = first.path

  return {
    series: {
      key,
      kind: first.kind,
      title: first.seriesTitle || first.baseName,
      volumeCount: volumes.length,
      totalSize: volumes.reduce((sum, item) => sum + item.size, 0),
      coverPath,
      firstResourceId: first.id,
      mtimeMs: volumes.reduce((max, item) => Math.max(max, item.mtimeMs), 0),
      addedMs: volumes.reduce((min, item) => Math.min(min, item.addedMs || Number.MAX_SAFE_INTEGER), Number.MAX_SAFE_INTEGER),
      isFavorite: volumes.some((item) => item.isFavorite),
      numberedCount: volumes.filter((item) => item.volume > 0).length
    },
    volumes,
    libraryId: location?.libraryId ?? 0,
    libraryPath: location?.libraryPath ?? '',
    relDir: location?.relDir ?? ''
  }
}

/** 按需读取一个文件的媒体信息（同时写回索引，之后就是秒开） */
export async function mediaInfo(filePath: string, kind: ResourceKind): Promise<MediaInfo | null> {
  const ext = extOf(filePath)
  const info: MediaInfo = {
    path: filePath,
    width: 0,
    height: 0,
    durationMs: 0,
    bitrate: 0,
    title: '',
    artist: '',
    album: '',
    year: 0,
    track: 0,
    genre: '',
    coverPath: '',
    innerKind: '',
    innerSummary: ''
  }

  try {
    if (kind === 'music') {
      const tags = await readAudioTags(filePath, ext)
      info.title = tags.title || baseNameOf(filePath.split('\\').pop() ?? '')
      info.artist = tags.artist
      info.album = tags.album
      info.year = tags.year
      info.track = tags.track
      info.genre = tags.genre
      info.durationMs = tags.durationMs
    } else if (kind === 'movie' || kind === 'tv' || kind === 'anime') {
      const video = await readVideoInfo(filePath, ext)
      info.width = video.width
      info.height = video.height
      info.durationMs = video.durationMs
    } else if (kind === 'image' || kind === 'wallpaper') {
      const size = await readImageSize(filePath, ext)
      info.width = size.width
      info.height = size.height
    } else if (ext === '.epub') {
      const epub = await readEpubMeta(filePath)
      info.title = epub.title
      info.artist = epub.creator
    } else if (ext === '.zip' || ext === '.cbz' || ext === '.cb7') {
      const entries = await readZipEntries(filePath, 500)
      const guess = guessZipContent(entries)
      info.innerKind = guess.kind
      info.innerSummary = guess.summary
    }
  } catch {
    /* 解析失败返回空信息 */
  }

  // 写回索引
  const indexed = db.getResourceByPath(filePath)
  if (indexed) {
    if (info.durationMs > 0 && indexed.size > 0) {
      info.bitrate = Math.round((indexed.size * 8) / (info.durationMs / 1000))
    }
    db.updateResourceMeta(indexed.id, {
      width: info.width || indexed.width,
      height: info.height || indexed.height,
      durationMs: info.durationMs || indexed.durationMs,
      bitrate: info.bitrate || indexed.bitrate,
      title: info.title || indexed.title,
      artist: info.artist || indexed.artist,
      album: info.album || indexed.album,
      year: info.year || indexed.year,
      cardLine: makeCardLine({
        kind: indexed.kind,
        ext: indexed.ext,
        size: indexed.size,
        width: info.width || indexed.width,
        height: info.height || indexed.height,
        durationMs: info.durationMs || indexed.durationMs,
        year: info.year || indexed.year,
        artist: info.artist || indexed.artist,
        album: info.album || indexed.album,
        innerKind: info.innerKind
      }),
      meta: {
        ...indexed.meta,
        ...(info.innerKind ? { innerKind: info.innerKind, innerSummary: info.innerSummary } : {}),
        ...(info.genre ? { genre: info.genre } : {}),
        ...(info.track ? { track: info.track } : {})
      }
    })
    db.markMetaState(indexed.id, 1)
  }

  return info
}
