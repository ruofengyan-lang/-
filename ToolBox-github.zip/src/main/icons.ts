import { app, nativeImage } from 'electron'

/** 文件图标缓存：key = 路径 + 修改时间，文件变了图标会重新取 */
const cache = new Map<string, string | null>()
const MAX_CACHE = 2000

/**
 * 取 Windows 真实图标（exe 的程序图标、系统关联图标、文件夹图标…）。
 * 使用 Electron 内置的 app.getFileIcon，不加载任何第三方原生模块。
 */
export async function iconDataUrl(filePath: string, mtimeMs = 0): Promise<string | null> {
  const key = `${filePath}|${mtimeMs}`
  if (cache.has(key)) return cache.get(key) ?? null

  let result: string | null = null
  try {
    const image = await app.getFileIcon(filePath, { size: 'large' })
    if (!image.isEmpty()) {
      const resized = image.resize({ width: 48, height: 48, quality: 'better' })
      result = (resized.isEmpty() ? image : resized).toDataURL()
    }
  } catch {
    result = null
  }

  if (cache.size >= MAX_CACHE) cache.clear()
  cache.set(key, result)
  return result
}

export function clearIconCache(): void {
  cache.clear()
  thumbCache.clear()
}

/** 图片缩略图缓存：壁纸文件夹里有几百张图，直接加载原图太重 */
const thumbCache = new Map<string, string | null>()
const MAX_THUMBS = 500

// 缩略图解码是同步的 C++ 调用，串行执行避免一次性卡住主进程
let thumbQueue: Promise<unknown> = Promise.resolve()

function decodeThumbnail(filePath: string, size: number): string | null {
  const image = nativeImage.createFromPath(filePath)
  if (image.isEmpty()) return null
  const { width, height } = image.getSize()
  const longest = Math.max(width, height)
  if (longest > size && longest > 0) {
    const scale = size / longest
    const resized = image.resize({
      width: Math.max(1, Math.round(width * scale)),
      height: Math.max(1, Math.round(height * scale)),
      quality: 'good'
    })
    return (resized.isEmpty() ? image : resized).toDataURL()
  }
  return image.toDataURL()
}

/**
 * 生成图片缩略图（PNG dataURL）。
 * 用 Electron 自带的 nativeImage 解码与缩放，不引入第三方图像库。
 */
export async function thumbnailDataUrl(filePath: string, mtimeMs = 0, size = 128): Promise<string | null> {
  const key = `${filePath}|${mtimeMs}|${size}`
  if (thumbCache.has(key)) return thumbCache.get(key) ?? null

  const job = thumbQueue.then(() => {
    try {
      return decodeThumbnail(filePath, size)
    } catch {
      return null
    }
  })
  thumbQueue = job.catch(() => undefined)

  const result = await job
  if (thumbCache.size >= MAX_THUMBS) thumbCache.clear()
  thumbCache.set(key, result)
  return result
}
