import { app } from 'electron'
import fs from 'node:fs'
import path from 'node:path'
import { DEFAULT_EXCLUDE_DIRS } from './scan-paths'
import type {
  AppConfig,
  BackgroundMode,
  MetadataConfig,
  ScanOptions,
  SortBy,
  SortOrder,
  WallpaperStyleId
} from '@shared/types'

const BACKGROUND_MODES: BackgroundMode[] = ['cover', 'contain', 'stretch', 'tile', 'center']
const SORT_BY_LIST: SortBy[] = ['name', 'mtime', 'size', 'added', 'kind', 'opened']
const SORT_ORDER_LIST: SortOrder[] = ['asc', 'desc']
const WALLPAPER_STYLE_IDS: WallpaperStyleId[] = ['fill', 'fit', 'stretch', 'tile', 'center', 'span']
const CARD_SIZES: AppConfig['cardSize'][] = ['compact', 'normal', 'large']

export const DEFAULT_SCAN_OPTIONS: ScanOptions = {
  /** 0 = 不限深度 */
  maxDepth: 0,
  includeHidden: false,
  generateThumbnails: true,
  readMetadata: true,
  computeHash: true,
  /** 超过这个大小不参与 SHA-256 去重（避免几 GB 的电影拖慢扫描） */
  hashMaxSizeMB: 2048
}

export const DEFAULT_METADATA_OPTIONS: MetadataConfig = {
  tmdbApiKey: '',
  online: false,
  proxy: '',
  tmdbApiBase: 'https://api.themoviedb.org/3',
  tmdbImageBase: 'https://image.tmdb.org/t/p',
  imageCacheMB: 512
}

export const DEFAULT_CONFIG: AppConfig = {
  background: '',
  overlay: 0.4,
  backgroundMode: 'cover',
  windowWidth: 1280,
  windowHeight: 720,
  windowMaximized: false,
  resourceRoot: '',
  excludeDirs: [],
  sortBy: 'name',
  sortOrder: 'asc',
  confirmExecutables: true,
  approvedPrograms: [],
  showFileExtensions: true,
  wallpaperStyle: 'fill',
  lastCategory: '',
  showEmptyCategories: false,
  cardSize: 'normal',
  scan: { ...DEFAULT_SCAN_OPTIONS },
  lastView: 'home',
  metadata: { ...DEFAULT_METADATA_OPTIONS }
}

let cachedRoot: string | null = null
let cachedConfigDir: string | null = null
let cachedDataDir: string | null = null

function isWritableDir(dir: string): boolean {
  try {
    fs.mkdirSync(dir, { recursive: true })
    const probe = path.join(dir, `.write-probe-${process.pid}`)
    fs.writeFileSync(probe, 'ok')
    fs.unlinkSync(probe)
    return true
  } catch {
    return false
  }
}

/**
 * 程序根目录（资源目录）：
 * 1. 环境变量 TOOLBOX_RESOURCE_ROOT
 * 2. 绿色便携版：electron-builder portable 注入的 PORTABLE_EXECUTABLE_DIR
 * 3. 打包后：exe 所在目录
 * 4. 开发模式：项目目录的上一级（也就是 ToolBox 文件夹旁边放分类文件夹）
 */
export function appRoot(): string {
  if (cachedRoot) return cachedRoot
  const envRoot = (process.env.TOOLBOX_RESOURCE_ROOT ?? '').trim()
  if (envRoot) {
    cachedRoot = path.resolve(envRoot)
    return cachedRoot
  }
  if (app.isPackaged) {
    const portable = (process.env.PORTABLE_EXECUTABLE_DIR ?? '').trim()
    cachedRoot = portable ? path.resolve(portable) : path.dirname(app.getPath('exe'))
    return cachedRoot
  }
  cachedRoot = path.resolve(app.getAppPath(), '..')
  return cachedRoot
}

/** config 目录：优先放在程序根目录（绿色便携），不可写时退回用户数据目录 */
export function configDir(): string {
  if (cachedConfigDir) return cachedConfigDir
  const beside = path.join(appRoot(), 'config')
  if (isWritableDir(beside)) {
    cachedConfigDir = beside
    return cachedConfigDir
  }
  const fallback = path.join(app.getPath('userData'), 'config')
  isWritableDir(fallback)
  cachedConfigDir = fallback
  return cachedConfigDir
}

export function configPath(): string {
  return path.join(configDir(), 'config.json')
}

/** 索引数据库 / 缩略图缓存 / worker 脚本都放这里（绿色便携：跟着程序目录走） */
export function dataDir(): string {
  if (cachedDataDir) return cachedDataDir
  const beside = path.join(appRoot(), 'data')
  if (isWritableDir(beside)) {
    cachedDataDir = beside
    return cachedDataDir
  }
  const fallback = path.join(app.getPath('userData'), 'data')
  isWritableDir(fallback)
  cachedDataDir = fallback
  return cachedDataDir
}

/** 资源根目录：config.resourceRoot 覆盖后即为它，否则为程序根目录 */
export function resourceRoot(): string {
  const custom = (configStore.all().resourceRoot || '').trim()
  if (custom) {
    const abs = path.isAbsolute(custom) ? custom : path.resolve(appRoot(), custom)
    try {
      if (fs.statSync(abs).isDirectory()) return abs
    } catch {
      /* 目录不存在则回退 */
    }
  }
  return appRoot()
}

function clampNumber(value: unknown, min: number, max: number, def: number): number {
  const n = typeof value === 'number' ? value : Number(value)
  if (!Number.isFinite(n)) return def
  return Math.min(max, Math.max(min, n))
}

function asString(value: unknown, def = ''): string {
  return typeof value === 'string' ? value : def
}

function asBoolean(value: unknown, def: boolean): boolean {
  return typeof value === 'boolean' ? value : def
}

function oneOf<T extends string>(value: unknown, allowed: T[], def: T): T {
  return typeof value === 'string' && (allowed as string[]).includes(value) ? (value as T) : def
}

function asStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return []
  return value.filter((v): v is string => typeof v === 'string' && v.trim().length > 0).map((v) => v.trim())
}

/** API Key 只做裁剪与长度限制，不写入任何日志 */
function sanitizeSecret(value: unknown): string {
  const raw = typeof value === 'string' ? value.trim() : ''
  return raw.length > 200 ? raw.slice(0, 200) : raw
}

/**
 * 发给渲染层的配置副本：**API Key 只写不读**，一律替换成空字符串，
 * 另外用只读的 tmdbKeySet 告诉界面"有没有配过"。
 */
export function publicConfig(config: AppConfig): AppConfig {
  return {
    ...config,
    metadata: { ...config.metadata, tmdbApiKey: '', tmdbKeySet: config.metadata.tmdbApiKey.length > 0 }
  }
}

function sanitizeBaseUrl(value: unknown, def: string): string {
  const raw = asString(value, def).trim()
  if (!/^https?:\/\//i.test(raw)) return def
  return raw.replace(/\/+$/, '')
}

/** 任何字段坏了都只影响它自己：其余字段继续用默认值，程序永远能启动 */
export function normalizeMetadata(raw: unknown): MetadataConfig {
  const input = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>
  return {
    tmdbApiKey: sanitizeSecret(input.tmdbApiKey),
    online: asBoolean(input.online, DEFAULT_METADATA_OPTIONS.online),
    proxy: asString(input.proxy, '').trim(),
    tmdbApiBase: sanitizeBaseUrl(input.tmdbApiBase, DEFAULT_METADATA_OPTIONS.tmdbApiBase),
    tmdbImageBase: sanitizeBaseUrl(input.tmdbImageBase, DEFAULT_METADATA_OPTIONS.tmdbImageBase),
    imageCacheMB: Math.round(clampNumber(input.imageCacheMB, 64, 8192, DEFAULT_METADATA_OPTIONS.imageCacheMB))
  }
}

export function normalizeConfig(raw: unknown): AppConfig {
  const input = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>
  const scanInput = (input.scan && typeof input.scan === 'object' ? input.scan : {}) as Record<string, unknown>
  const scan: ScanOptions = {
    maxDepth: Math.round(clampNumber(scanInput.maxDepth, 0, 64, DEFAULT_SCAN_OPTIONS.maxDepth)),
    includeHidden: asBoolean(scanInput.includeHidden, DEFAULT_SCAN_OPTIONS.includeHidden),
    generateThumbnails: asBoolean(scanInput.generateThumbnails, DEFAULT_SCAN_OPTIONS.generateThumbnails),
    readMetadata: asBoolean(scanInput.readMetadata, DEFAULT_SCAN_OPTIONS.readMetadata),
    computeHash: asBoolean(scanInput.computeHash, DEFAULT_SCAN_OPTIONS.computeHash),
    hashMaxSizeMB: Math.round(clampNumber(scanInput.hashMaxSizeMB, 1, 1024 * 64, DEFAULT_SCAN_OPTIONS.hashMaxSizeMB))
  }
  return {
    background: asString(input.background, ''),
    overlay: clampNumber(input.overlay, 0, 0.9, DEFAULT_CONFIG.overlay),
    backgroundMode: oneOf(input.backgroundMode, BACKGROUND_MODES, DEFAULT_CONFIG.backgroundMode),
    windowWidth: Math.round(clampNumber(input.windowWidth, 900, 10000, DEFAULT_CONFIG.windowWidth)),
    windowHeight: Math.round(clampNumber(input.windowHeight, 600, 10000, DEFAULT_CONFIG.windowHeight)),
    windowMaximized: asBoolean(input.windowMaximized, DEFAULT_CONFIG.windowMaximized),
    resourceRoot: asString(input.resourceRoot, ''),
    excludeDirs: asStringArray(input.excludeDirs).filter((n) => !DEFAULT_EXCLUDE_DIRS.includes(n)),
    sortBy: oneOf(input.sortBy, SORT_BY_LIST, DEFAULT_CONFIG.sortBy),
    sortOrder: oneOf(input.sortOrder, SORT_ORDER_LIST, DEFAULT_CONFIG.sortOrder),
    confirmExecutables: asBoolean(input.confirmExecutables, DEFAULT_CONFIG.confirmExecutables),
    approvedPrograms: asStringArray(input.approvedPrograms).slice(-200),
    showFileExtensions: asBoolean(input.showFileExtensions, DEFAULT_CONFIG.showFileExtensions),
    wallpaperStyle: oneOf(input.wallpaperStyle, WALLPAPER_STYLE_IDS, DEFAULT_CONFIG.wallpaperStyle),
    lastCategory: asString(input.lastCategory, ''),
    showEmptyCategories: asBoolean(input.showEmptyCategories, DEFAULT_CONFIG.showEmptyCategories),
    cardSize: oneOf(input.cardSize, CARD_SIZES, DEFAULT_CONFIG.cardSize),
    scan,
    lastView: asString(input.lastView, DEFAULT_CONFIG.lastView),
    metadata: normalizeMetadata(input.metadata)
  }
}

class ConfigStore {
  private data: AppConfig = { ...DEFAULT_CONFIG }
  private loaded = false
  private lastError = ''

  get error(): string {
    return this.lastError
  }

  all(): AppConfig {
    if (!this.loaded) this.load()
    return this.data
  }

  load(): AppConfig {
    const file = configPath()
    try {
      if (!fs.existsSync(file)) {
        this.data = { ...DEFAULT_CONFIG }
        this.save()
        this.loaded = true
        return this.data
      }
      const text = fs.readFileSync(file, 'utf8')
      this.data = normalizeConfig(JSON.parse(text))
      this.lastError = ''
    } catch (err) {
      // 配置损坏：备份坏文件，恢复默认配置，绝不让程序启动失败
      this.lastError = err instanceof Error ? err.message : String(err)
      try {
        if (fs.existsSync(file)) {
          fs.renameSync(file, `${file}.broken-${Date.now()}.bak`)
        }
      } catch {
        /* 备份失败也无所谓 */
      }
      this.data = { ...DEFAULT_CONFIG }
      this.save()
    }
    this.loaded = true
    return this.data
  }

  save(): AppConfig {
    const file = configPath()
    try {
      fs.mkdirSync(path.dirname(file), { recursive: true })
      const tmp = `${file}.tmp`
      fs.writeFileSync(tmp, `${JSON.stringify(this.data, null, 2)}\n`, 'utf8')
      fs.renameSync(tmp, file)
    } catch (err) {
      this.lastError = err instanceof Error ? err.message : String(err)
    }
    return this.data
  }

  patch(patch: Partial<AppConfig>): AppConfig {
    const merged = normalizeConfig({ ...this.all(), ...patch })
    this.data = merged
    this.loaded = true
    this.save()
    return this.data
  }

  /** 把某张图设为工具箱背景（绝对路径，空字符串表示恢复默认渐变） */
  setBackground(file: string): AppConfig {
    return this.patch({ background: file })
  }
}

export const configStore = new ConfigStore()
