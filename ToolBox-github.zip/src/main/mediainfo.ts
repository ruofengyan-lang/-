import fsp from 'node:fs/promises'
import zlib from 'node:zlib'
import type { FileHandle } from 'node:fs/promises'

/**
 * 本地媒体信息解析（纯 Node，不依赖 ffmpeg，不解压资源包）：
 * - 音频标签：ID3v2(ID3v1 兜底) / FLAC / MP4-M4A / OGG-Vorbis / WAV
 * - 内嵌封面：APIC / FLAC PICTURE / MP4 covr
 * - 视频容器：MP4(含 MOV) / MKV(含 WebM) / AVI 的宽高与时长
 * - ZIP：中央目录列表 + 单条目解压（用于 epub 封面 / cbz 首页 / 压缩包内容判定）
 */

export interface AudioTags {
  title: string
  artist: string
  /** 专辑艺术家（合作专辑/合辑用这个归组，拿不到就退回 artist） */
  albumArtist: string
  album: string
  year: number
  track: number
  genre: string
  durationMs: number
  coverData: Buffer | null
  coverExt: string
}

export interface VideoInfo {
  width: number
  height: number
  durationMs: number
}

export interface ZipEntryInfo {
  name: string
  size: number
  isDir: boolean
}

const EMPTY_TAGS: AudioTags = {
  title: '',
  artist: '',
  albumArtist: '',
  album: '',
  year: 0,
  track: 0,
  genre: '',
  durationMs: 0,
  coverData: null,
  coverExt: '.jpg'
}

const HEAD_LIMIT = 4 * 1024 * 1024

async function readAt(fh: FileHandle, length: number, position: number): Promise<Buffer> {
  const buffer = Buffer.alloc(length)
  const { bytesRead } = await fh.read(buffer, 0, length, position)
  return buffer.subarray(0, bytesRead)
}

async function openFile(file: string): Promise<FileHandle> {
  return fsp.open(file, 'r')
}

/** 同目录封面文件优先级：cover.jpg → cover.png → folder.jpg → 0.jpg → 001.jpg（大小写不敏感） */
const SIDECAR_COVER_PRIORITY = [
  'cover.jpg', 'cover.jpeg', 'cover.png', 'cover.webp',
  'folder.jpg', 'folder.png', '0.jpg', '0.png', '001.jpg', '001.png'
]

/** 在文件所在目录里找"本地封面"；找不到返回空字符串 */
export async function findSidecarCover(filePath: string): Promise<string> {
  try {
    const sep = filePath.includes('\\') ? '\\' : '/'
    const dir = filePath.slice(0, filePath.lastIndexOf(sep))
    if (!dir) return ''
    const entries = await fsp.readdir(dir)
    const lower = new Map(entries.map((name) => [name.toLowerCase(), name]))
    for (const candidate of SIDECAR_COVER_PRIORITY) {
      const found = lower.get(candidate)
      if (found) return `${dir}${sep}${found}`
    }
    // 与压缩包同名的封面：xxx.cbz → xxx.jpg / xxx.png
    const base = filePath.slice(filePath.lastIndexOf(sep) + 1).replace(/\.[^.]+$/, '')
    for (const candidate of [`${base}.jpg`, `${base}.png`]) {
      const found = lower.get(candidate.toLowerCase())
      if (found) return `${dir}${sep}${found}`
    }
  } catch {
    /* ignore */
  }
  return ''
}

/* ============================ 音频标签 ============================ */

function decodeText(buffer: Buffer, encoding: number): string {
  try {
    if (encoding === 0) return buffer.toString('latin1').replace(/\0+$/, '').trim()
    if (encoding === 3) return buffer.toString('utf8').replace(/\0+$/, '').trim()
    if (encoding === 1) {
      if (buffer.length >= 2 && buffer[0] === 0xff && buffer[1] === 0xfe) {
        return buffer.subarray(2).toString('utf16le').replace(/\0+$/, '').trim()
      }
      if (buffer.length >= 2 && buffer[0] === 0xfe && buffer[1] === 0xff) {
        const swapped = Buffer.from(buffer.subarray(2))
        swapped.swap16()
        return swapped.toString('utf16le').replace(/\0+$/, '').trim()
      }
      return buffer.toString('utf16le').replace(/\0+$/, '').trim()
    }
    if (encoding === 2) {
      const swapped = Buffer.from(buffer)
      if (swapped.length % 2 === 0) {
        swapped.swap16()
        return swapped.toString('utf16le').replace(/\0+$/, '').trim()
      }
      return buffer.toString('utf16le').replace(/\0+$/, '').trim()
    }
  } catch {
    /* 解析失败就当没有 */
  }
  return ''
}

function syncSafeToInt(buffer: Buffer, offset: number): number {
  return (
    ((buffer[offset] & 0x7f) << 21) |
    ((buffer[offset + 1] & 0x7f) << 14) |
    ((buffer[offset + 2] & 0x7f) << 7) |
    (buffer[offset + 3] & 0x7f)
  )
}

async function readId3v2(fh: FileHandle, tags: AudioTags): Promise<void> {
  const header = await readAt(fh, 10, 0)
  if (header.length < 10 || header.toString('latin1', 0, 3) !== 'ID3') return
  const version = header[3]
  const tagSize =
    version >= 4
      ? syncSafeToInt(header, 6)
      : (header[6] << 21) | (header[7] << 14) | (header[8] << 7) | header[9]
  const limit = Math.min(tagSize, HEAD_LIMIT)
  let body = await readAt(fh, limit, 10)
  let offset = 0
  // 跳过扩展头
  if (header[5] & 0x40) {
    if (body.length < 4) return
    const extSize = version >= 4 ? syncSafeToInt(body, 0) : body.readUInt32BE(0)
    offset += extSize + (version >= 4 ? 0 : 4)
  }
  while (offset + 10 <= body.length) {
    const id = body.toString('latin1', offset, offset + 4)
    if (!/^[A-Z0-9]{4}$/.test(id)) break
    const frameSize =
      version >= 4
        ? syncSafeToInt(body, offset + 4)
        : body.readUInt32BE(offset + 4)
    if (frameSize <= 0 || offset + 10 + frameSize > body.length) break
    const frame = body.subarray(offset + 10, offset + 10 + frameSize)
    applyId3Frame(id, frame, tags)
    offset += 10 + frameSize
  }
  // 释放大缓冲
  body = Buffer.alloc(0)
}

function applyId3Frame(id: string, frame: Buffer, tags: AudioTags): void {
  try {
    switch (id) {
      case 'TIT2':
        tags.title = decodeText(frame.subarray(1), frame[0]) || tags.title
        break
      case 'TPE1':
        tags.artist = decodeText(frame.subarray(1), frame[0]) || tags.artist
        break
      case 'TPE2':
        tags.albumArtist = decodeText(frame.subarray(1), frame[0]) || tags.albumArtist
        break
      case 'TALB':
        tags.album = decodeText(frame.subarray(1), frame[0]) || tags.album
        break
      case 'TCON':
        tags.genre = decodeText(frame.subarray(1), frame[0]).replace(/^\(\d+\)/, '') || tags.genre
        break
      case 'TYER':
      case 'TDRC': {
        const value = decodeText(frame.subarray(1), frame[0])
        const year = parseInt(value.slice(0, 4), 10)
        if (Number.isFinite(year)) tags.year = year
        break
      }
      case 'TRCK': {
        const value = decodeText(frame.subarray(1), frame[0])
        const track = parseInt(value.split('/')[0], 10)
        if (Number.isFinite(track)) tags.track = track
        break
      }
      case 'APIC': {
        if (tags.coverData) break
        const encoding = frame[0]
        let cursor = 1
        let mime = ''
        if (encoding === 1 || encoding === 2) {
          // UTF-16 的 mime 极少见，按 latin1 读
          const end = frame.indexOf(0, cursor)
          mime = frame.toString('latin1', cursor, end < 0 ? cursor : end)
          cursor = (end < 0 ? cursor : end) + 2
        } else {
          const end = frame.indexOf(0, cursor)
          mime = frame.toString('latin1', cursor, end < 0 ? cursor : end)
          cursor = (end < 0 ? cursor : end) + 1
        }
        cursor += 1 // picture type
        // 描述字段
        if (encoding === 1 || encoding === 2) {
          let end = cursor
          while (end + 1 < frame.length && !(frame[end] === 0 && frame[end + 1] === 0)) end += 2
          cursor = end + 2
        } else {
          const end = frame.indexOf(0, cursor)
          cursor = (end < 0 ? cursor : end) + 1
        }
        if (cursor < frame.length) {
          tags.coverData = Buffer.from(frame.subarray(cursor))
          tags.coverExt = mime.includes('png') ? '.png' : '.jpg'
        }
        break
      }
      default:
        break
    }
  } catch {
    /* 单个帧失败不影响整体 */
  }
}

async function readId3v1(fh: FileHandle, fileSize: number, tags: AudioTags): Promise<void> {
  if (fileSize < 128) return
  const buffer = await readAt(fh, 128, fileSize - 128)
  if (buffer.length < 128 || buffer.toString('latin1', 0, 3) !== 'TAG') return
  const pick = (start: number, length: number): string =>
    buffer.toString('latin1', start, start + length).replace(/\0.*$/, '').trim()
  tags.title = tags.title || pick(3, 30)
  tags.artist = tags.artist || pick(33, 30)
  tags.album = tags.album || pick(63, 30)
  if (!tags.year) {
    const year = parseInt(pick(93, 4), 10)
    if (Number.isFinite(year)) tags.year = year
  }
  tags.genre = tags.genre || pick(127, 1)
}

/** MP3 时长：优先 Xing/Info 帧数，其次按 CBR 码率估算 */
async function readMp3Duration(fh: FileHandle, fileSize: number): Promise<number> {
  const head = await readAt(fh, Math.min(64 * 1024, fileSize), 0)
  const bitrateTableV1L3 = [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0]
  const bitrateTableV2L3 = [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0]
  const sampleRates = [44100, 48000, 32000, 0]
  for (let i = 0; i + 4 < head.length; i++) {
    if (head[i] !== 0xff || (head[i + 1] & 0xe0) !== 0xe0) continue
    const versionBits = (head[i + 1] >> 3) & 0x03
    const layerBits = (head[i + 1] >> 1) & 0x03
    const bitrateIndex = (head[i + 2] >> 4) & 0x0f
    const sampleIndex = (head[i + 2] >> 2) & 0x03
    if (versionBits === 1 || layerBits === 0 || bitrateIndex === 0 || bitrateIndex === 15 || sampleIndex === 3) continue
    const isV1 = versionBits === 3
    const bitrate = (isV1 ? bitrateTableV1L3 : bitrateTableV2L3)[bitrateIndex] * 1000
    const sampleRate = isV1 ? sampleRates[sampleIndex] : sampleRates[sampleIndex] / 2
    // Xing / Info 头
    const sideInfo = isV1 ? 32 : 17
    const xingOffset = i + 4 + sideInfo
    const tag = head.toString('latin1', xingOffset, xingOffset + 4)
    if (tag === 'Xing' || tag === 'Info') {
      const flags = head.readUInt32BE(xingOffset + 4)
      if (flags & 0x0001) {
        const frames = head.readUInt32BE(xingOffset + 8)
        const samplesPerFrame = isV1 ? 1152 : 576
        return Math.round((frames * samplesPerFrame * 1000) / sampleRate)
      }
    }
    if (bitrate > 0) return Math.round((fileSize * 8 * 1000) / bitrate)
    return 0
  }
  return 0
}

/** FLAC：STREAMINFO 精确时长 + VORBIS_COMMENT + PICTURE */
async function readFlac(fh: FileHandle, tags: AudioTags): Promise<void> {
  const marker = await readAt(fh, 4, 0)
  if (marker.toString('latin1') !== 'fLaC') return
  let offset = 4
  for (let guard = 0; guard < 64; guard++) {
    const header = await readAt(fh, 4, offset)
    if (header.length < 4) break
    const isLast = (header[0] & 0x80) !== 0
    const type = header[0] & 0x7f
    const size = (header[1] << 16) | (header[2] << 8) | header[3]
    const dataStart = offset + 4
    if (type === 0) {
      const info = await readAt(fh, Math.min(size, 64), dataStart)
      if (info.length >= 18) {
        // sampleRate 20bit, channels 3bit, bitsPerSample 5bit, totalSamples 36bit
        const b = info.subarray(10, 18)
        const sampleRate = (b[0] << 12) | (b[1] << 4) | (b[2] >> 4)
        const totalSamples =
          (b[3] & 0x0f) * 2 ** 32 + ((b[4] << 24) >>> 0) + (b[5] << 16) + (b[6] << 8) + b[7]
        if (sampleRate > 0 && totalSamples > 0) tags.durationMs = Math.round((totalSamples / sampleRate) * 1000)
      }
    } else if (type === 4) {
      const data = await readAt(fh, Math.min(size, 512 * 1024), dataStart)
      applyVorbisComment(data, tags)
    } else if (type === 6) {
      const data = await readAt(fh, Math.min(size, HEAD_LIMIT), dataStart)
      applyFlacPicture(data, tags)
    }
    if (isLast) break
    offset = dataStart + size
  }
}

function applyVorbisComment(data: Buffer, tags: AudioTags): void {
  try {
    let cursor = 0
    const vendorLength = data.readUInt32LE(cursor)
    cursor += 4 + vendorLength
    const count = data.readUInt32LE(cursor)
    cursor += 4
    for (let i = 0; i < count && cursor + 4 <= data.length; i++) {
      const length = data.readUInt32LE(cursor)
      cursor += 4
      const entry = data.toString('utf8', cursor, cursor + length)
      cursor += length
      const eq = entry.indexOf('=')
      if (eq < 0) continue
      const key = entry.slice(0, eq).toUpperCase()
      const value = entry.slice(eq + 1).trim()
      if (!value) continue
      if (key === 'TITLE') tags.title = tags.title || value
      else if (key === 'ARTIST') tags.artist = tags.artist || value
      else if (key === 'ALBUMARTIST' || key === 'ALBUM ARTIST') tags.albumArtist = tags.albumArtist || value
      else if (key === 'ALBUM') tags.album = tags.album || value
      else if (key === 'GENRE') tags.genre = tags.genre || value
      else if (key === 'DATE' || key === 'YEAR') {
        const year = parseInt(value.slice(0, 4), 10)
        if (Number.isFinite(year) && !tags.year) tags.year = year
      } else if (key === 'TRACKNUMBER') {
        const track = parseInt(value.split('/')[0], 10)
        if (Number.isFinite(track) && !tags.track) tags.track = track
      }
    }
  } catch {
    /* ignore */
  }
}

function applyFlacPicture(data: Buffer, tags: AudioTags): void {
  try {
    if (tags.coverData) return
    let cursor = 4 // picture type
    const mimeLength = data.readUInt32BE(cursor)
    cursor += 4
    const mime = data.toString('latin1', cursor, cursor + mimeLength)
    cursor += mimeLength
    const descLength = data.readUInt32BE(cursor)
    cursor += 4 + descLength
    cursor += 16 // width/height/depth/colors
    const dataLength = data.readUInt32BE(cursor)
    cursor += 4
    if (cursor + dataLength <= data.length) {
      tags.coverData = Buffer.from(data.subarray(cursor, cursor + dataLength))
      tags.coverExt = mime.includes('png') ? '.png' : '.jpg'
    }
  } catch {
    /* ignore */
  }
}

/** MP4 / M4A：ilst 标签 + covr 封面 + mvhd 时长 */
async function readMp4Audio(fh: FileHandle, tags: AudioTags): Promise<void> {
  const size = (await fh.stat()).size
  let pos = 0
  while (pos + 8 <= size) {
    const header = await readAt(fh, 16, pos)
    if (header.length < 8) break
    let boxSize = header.readUInt32BE(0)
    const type = header.toString('latin1', 4, 8)
    let headerSize = 8
    if (boxSize === 1 && header.length >= 16) {
      boxSize = Number(header.readBigUInt64BE(8))
      headerSize = 16
    } else if (boxSize === 0) {
      boxSize = size - pos
    }
    if (boxSize < headerSize) break
    if (type === 'moov') {
      await walkMp4(fh, pos + headerSize, boxSize - headerSize, tags, 2)
      break
    }
    pos += boxSize
  }
}

async function walkMp4(fh: FileHandle, start: number, length: number, tags: AudioTags, depth: number): Promise<void> {
  let pos = start
  const end = start + length
  while (pos + 8 <= end) {
    const header = await readAt(fh, 16, pos)
    if (header.length < 8) return
    let boxSize = header.readUInt32BE(0)
    const type = header.toString('latin1', 4, 8)
    let headerSize = 8
    if (boxSize === 1 && header.length >= 16) {
      boxSize = Number(header.readBigUInt64BE(8))
      headerSize = 16
    } else if (boxSize === 0) {
      boxSize = end - pos
    }
    if (boxSize < headerSize) return
    const bodyStart = pos + headerSize
    const bodySize = boxSize - headerSize
    if (type === 'mvhd') {
      const data = await readAt(fh, Math.min(bodySize, 120), bodyStart)
      const version = data[0]
      if (version === 0 && data.length >= 20) {
        const timescale = data.readUInt32BE(12)
        const duration = data.readUInt32BE(16)
        if (timescale > 0 && duration > 0) {
          const ms = Math.round((duration / timescale) * 1000)
          if (ms > tags.durationMs) tags.durationMs = ms
        }
      } else if (version === 1 && data.length >= 32) {
        const timescale = data.readUInt32BE(20)
        const duration = Number(data.readBigUInt64BE(24))
        if (timescale > 0 && duration > 0) {
          const ms = Math.round((duration / timescale) * 1000)
          if (ms > tags.durationMs) tags.durationMs = ms
        }
      }
    } else if (type === 'ilst' && depth > 0) {
      await walkMp4(fh, bodyStart, bodySize, tags, depth - 1)
    } else if (depth > 0 && ['udta', 'meta', 'trak', 'mdia'].includes(type)) {
      // meta 有 4 字节版本/标志
      const skip = type === 'meta' ? 4 : 0
      await walkMp4(fh, bodyStart + skip, bodySize - skip, tags, depth - 1)
    } else if (depth > 0 && type === 'ilst') {
      await walkMp4(fh, bodyStart, bodySize, tags, depth - 1)
    } else if (isMp4TagBox(type)) {
      const data = await readAt(fh, Math.min(bodySize, HEAD_LIMIT), bodyStart)
      applyMp4Tag(type, data, tags)
    }
    pos += boxSize
  }
}

function isMp4TagBox(type: string): boolean {
  return ['\u00a9nam', '\u00a9ART', 'aART', '\u00a9alb', '\u00a9day', '\u00a9gen', 'trkn', 'covr', '\u00a9wrt'].includes(type)
}

function applyMp4Tag(type: string, data: Buffer, tags: AudioTags): void {
  try {
    if (type === 'covr') {
      if (tags.coverData) return
      // data box: size(4) 'data' type(4) locale(4) payload
      const idx = data.indexOf('data', 0, 'latin1')
      if (idx >= 0 && idx + 12 <= data.length) {
        const flag = data.readUInt32BE(idx + 4)
        tags.coverData = Buffer.from(data.subarray(idx + 12))
        tags.coverExt = flag === 14 ? '.png' : '.jpg'
      }
      return
    }
    const idx = data.indexOf('data', 0, 'latin1')
    const payloadStart = idx >= 0 ? idx + 12 : 0
    const payload = data.subarray(payloadStart)
    if (type === 'trkn') {
      if (payload.length >= 4) tags.track = payload.readUInt16BE(2)
      return
    }
    const text = payload.toString('utf8').replace(/\0+$/, '').trim()
    if (!text) return
    if (type === '\u00a9nam') tags.title = tags.title || text
    else if (type === '\u00a9ART' || type === '\u00a9wrt') tags.artist = tags.artist || text
    else if (type === 'aART') tags.albumArtist = tags.albumArtist || text
    else if (type === '\u00a9alb') tags.album = tags.album || text
    else if (type === '\u00a9gen') tags.genre = tags.genre || text
    else if (type === '\u00a9day') {
      const year = parseInt(text.slice(0, 4), 10)
      if (Number.isFinite(year)) tags.year = year
    }
  } catch {
    /* ignore */
  }
}

/** OGG / OPUS：读最后一个页面的 granule 得到时长 + Vorbis 注释 */
async function readOgg(fh: FileHandle, fileSize: number, tags: AudioTags): Promise<void> {
  try {
    const head = await readAt(fh, Math.min(256 * 1024, fileSize), 0)
    const commentIndex = head.indexOf('vorbis', 0, 'latin1')
    if (commentIndex >= 0) {
      const start = commentIndex + 7
      applyVorbisComment(head.subarray(start), tags)
    }
    let sampleRate = 44100
    const rateIndex = head.indexOf('vorbis', 0, 'latin1')
    if (rateIndex >= 0 && rateIndex + 30 < head.length) {
      sampleRate = head.readUInt32LE(rateIndex + 23)
      if (!Number.isFinite(sampleRate) || sampleRate <= 0) sampleRate = 44100
    }
    const tailLength = Math.min(64 * 1024, fileSize)
    const tail = await readAt(fh, tailLength, fileSize - tailLength)
    let lastGranule = 0
    for (let i = 0; i + 14 <= tail.length; i++) {
      if (tail.toString('latin1', i, i + 4) !== 'OggS') continue
      const granule = Number(tail.readBigUInt64LE(i + 6))
      if (granule > lastGranule) lastGranule = granule
    }
    if (lastGranule > 0 && sampleRate > 0) tags.durationMs = Math.round((lastGranule / sampleRate) * 1000)
  } catch {
    /* ignore */
  }
}

async function readWav(fh: FileHandle, tags: AudioTags): Promise<void> {
  const header = await readAt(fh, 64, 0)
  if (header.length < 44 || header.toString('latin1', 0, 4) !== 'RIFF') return
  let byteRate = 0
  let dataSize = 0
  let pos = 12
  for (let guard = 0; guard < 32; guard++) {
    const chunk = await readAt(fh, 8, pos)
    if (chunk.length < 8) break
    const id = chunk.toString('latin1', 0, 4)
    const size = chunk.readUInt32LE(4)
    if (id === 'fmt ') {
      const fmt = await readAt(fh, Math.min(size, 32), pos + 8)
      if (fmt.length >= 16) byteRate = fmt.readUInt32LE(8)
    } else if (id === 'data') {
      dataSize = size
      break
    }
    pos += 8 + size + (size % 2)
  }
  if (byteRate > 0 && dataSize > 0) tags.durationMs = Math.round((dataSize / byteRate) * 1000)
}

/** 读取音频标签与内嵌封面 */
export async function readAudioTags(file: string, ext: string): Promise<AudioTags> {
  const tags: AudioTags = { ...EMPTY_TAGS }
  let fh: FileHandle | null = null
  try {
    fh = await openFile(file)
    const stat = await fh.stat()
    if (ext === '.flac') {
      await readFlac(fh, tags)
    } else if (ext === '.m4a' || ext === '.mp4' || ext === '.aac') {
      await readMp4Audio(fh, tags)
    } else if (ext === '.ogg' || ext === '.oga' || ext === '.opus') {
      await readOgg(fh, stat.size, tags)
    } else if (ext === '.wav') {
      await readWav(fh, tags)
    } else if (ext === '.wma' || ext === '.ape') {
      // 少数格式暂不解析标签，只给出大小
      tags.durationMs = 0
    } else {
      // mp3 等：ID3 + 帧头
      await readId3v2(fh, tags)
      if (!tags.title || !tags.artist) await readId3v1(fh, stat.size, tags)
      tags.durationMs = await readMp3Duration(fh, stat.size)
    }
  } catch {
    /* 解析失败返回空标签 */
  } finally {
    await fh?.close().catch(() => undefined)
  }
  return tags
}

/* ============================ 视频容器 ============================ */

async function readMp4Video(fh: FileHandle): Promise<VideoInfo> {
  const info: VideoInfo = { width: 0, height: 0, durationMs: 0 }
  const size = (await fh.stat()).size
  let pos = 0
  while (pos + 8 <= size) {
    const header = await readAt(fh, 16, pos)
    if (header.length < 8) break
    let boxSize = header.readUInt32BE(0)
    const type = header.toString('latin1', 4, 8)
    let headerSize = 8
    if (boxSize === 1 && header.length >= 16) {
      boxSize = Number(header.readBigUInt64BE(8))
      headerSize = 16
    } else if (boxSize === 0) {
      boxSize = size - pos
    }
    if (boxSize < headerSize) break
    if (type === 'moov') {
      await walkMoovForVideo(fh, pos + headerSize, boxSize - headerSize, info)
      break
    }
    pos += boxSize
  }
  return info
}

async function walkMoovForVideo(fh: FileHandle, start: number, length: number, info: VideoInfo): Promise<void> {
  let pos = start
  const end = start + length
  while (pos + 8 <= end) {
    const header = await readAt(fh, 16, pos)
    if (header.length < 8) return
    let boxSize = header.readUInt32BE(0)
    const type = header.toString('latin1', 4, 8)
    let headerSize = 8
    if (boxSize === 1 && header.length >= 16) {
      boxSize = Number(header.readBigUInt64BE(8))
      headerSize = 16
    } else if (boxSize === 0) {
      boxSize = end - pos
    }
    if (boxSize < headerSize) return
    const bodyStart = pos + headerSize
    const bodySize = boxSize - headerSize
    if (type === 'mvhd') {
      const data = await readAt(fh, Math.min(bodySize, 120), bodyStart)
      const version = data[0]
      if (version === 0 && data.length >= 20) {
        const timescale = data.readUInt32BE(12)
        const duration = data.readUInt32BE(16)
        if (timescale > 0) info.durationMs = Math.round((duration / timescale) * 1000)
      } else if (version === 1 && data.length >= 32) {
        const timescale = data.readUInt32BE(20)
        const duration = Number(data.readBigUInt64BE(24))
        if (timescale > 0) info.durationMs = Math.round((duration / timescale) * 1000)
      }
    } else if (type === 'trak') {
      await walkMoovForVideo(fh, bodyStart, bodySize, info)
    } else if (type === 'tkhd') {
      const data = await readAt(fh, Math.min(bodySize, 100), bodyStart)
      const version = data[0]
      const base = version === 1 ? 88 : 76
      if (data.length >= base + 8) {
        const width = Math.round(data.readUInt32BE(base) / 65536)
        const height = Math.round(data.readUInt32BE(base + 4) / 65536)
        if (width > 0 && height > 0 && width * height > info.width * info.height) {
          info.width = width
          info.height = height
        }
      }
    } else if (['mdia', 'minf', 'stbl', 'edts'].includes(type)) {
      await walkMoovForVideo(fh, bodyStart, bodySize, info)
    }
    pos += boxSize
  }
}

/* ---- 极简 EBML（MKV / WebM） ---- */

function readVint(buffer: Buffer, offset: number): { value: number; length: number } | null {
  if (offset >= buffer.length) return null
  const first = buffer[offset]
  if (first === 0) return null
  let length = 1
  let mask = 0x80
  while (!(first & mask) && length < 8) {
    mask >>= 1
    length++
  }
  if (offset + length > buffer.length) return null
  let value = first & (mask - 1)
  for (let i = 1; i < length; i++) value = value * 256 + buffer[offset + i]
  return { value, length }
}

async function readMkvVideo(fh: FileHandle, fileSize: number): Promise<VideoInfo> {
  const info: VideoInfo = { width: 0, height: 0, durationMs: 0 }
  let timecodeScale = 1000000
  let duration = 0
  let pos = 0
  const readElement = async (position: number): Promise<{ id: number; size: number; dataStart: number } | null> => {
    const head = await readAt(fh, 32, position)
    const id = readVint(head, 0)
    if (!id) return null
    const sizeInfo = readVint(head, id.length)
    if (!sizeInfo) return null
    let size = sizeInfo.value
    const dataStart = position + id.length + sizeInfo.length
    // 未知长度（流式）当成本段剩余
    if (sizeInfo.value === Math.pow(2, 7 * sizeInfo.length) - 1) size = fileSize - dataStart
    return { id: id.value, size, dataStart }
  }
  const scanChildren = async (start: number, end: number, wanted: number[]): Promise<void> => {
    let cursor = start
    while (cursor < end) {
      const element = await readElement(cursor)
      if (!element || element.size < 0) return
      if (wanted.includes(element.id)) {
        if (element.id === 0x4489) {
          const data = await readAt(fh, Math.min(element.size, 8), element.dataStart)
          if (data.length === 4) duration = data.readFloatBE(0)
          else if (data.length === 8) duration = data.readDoubleBE(0)
        } else if (element.id === 0x2ad7b1) {
          const data = await readAt(fh, Math.min(element.size, 8), element.dataStart)
          let value = 0
          for (const byte of data) value = value * 256 + byte
          if (value > 0) timecodeScale = value
        } else if (element.id === 0x1549a966 || element.id === 0x1654ae6b) {
          await scanChildren(element.dataStart, element.dataStart + element.size, [0x4489, 0x2ad7b1, 0xae])
        } else if (element.id === 0xae) {
          await scanChildren(element.dataStart, element.dataStart + element.size, [0xe0])
        } else if (element.id === 0xe0) {
          await scanChildren(element.dataStart, element.dataStart + element.size, [0xb0, 0xba])
        } else if (element.id === 0xb0) {
          const data = await readAt(fh, Math.min(element.size, 8), element.dataStart)
          let value = 0
          for (const byte of data) value = value * 256 + byte
          info.width = value
        } else if (element.id === 0xba) {
          const data = await readAt(fh, Math.min(element.size, 8), element.dataStart)
          let value = 0
          for (const byte of data) value = value * 256 + byte
          info.height = value
        }
      }
      cursor = element.dataStart + element.size
      if (element.size === 0) break
    }
  }
  try {
    const segment = await readElement(pos)
    if (!segment) return info
    pos = segment.dataStart
    const end = Math.min(fileSize, segment.dataStart + segment.size)
    await scanChildren(pos, end, [0x1549a966, 0x1654ae6b])
    if (duration > 0) info.durationMs = Math.round((duration * timecodeScale) / 1e6)
  } catch {
    /* ignore */
  }
  return info
}

async function readAviVideo(fh: FileHandle): Promise<VideoInfo> {
  const info: VideoInfo = { width: 0, height: 0, durationMs: 0 }
  try {
    const header = await readAt(fh, 12, 0)
    if (header.toString('latin1', 0, 4) !== 'RIFF') return info
    const size = (await fh.stat()).size
    let pos = 12
    while (pos + 8 < size) {
      const chunk = await readAt(fh, 8, pos)
      if (chunk.length < 8) break
      const id = chunk.toString('latin1', 0, 4)
      const chunkSize = chunk.readUInt32LE(4)
      if (id === 'LIST') {
        pos += 12
        continue
      }
      if (id === 'avih') {
        const data = await readAt(fh, Math.min(chunkSize, 56), pos + 8)
        if (data.length >= 40) {
          const microPerFrame = data.readUInt32LE(0)
          const totalFrames = data.readUInt32LE(16)
          info.width = data.readUInt32LE(32)
          info.height = data.readUInt32LE(36)
          if (microPerFrame > 0 && totalFrames > 0) {
            info.durationMs = Math.round((microPerFrame * totalFrames) / 1000)
          }
        }
        break
      }
      pos += 8 + chunkSize + (chunkSize % 2)
    }
  } catch {
    /* ignore */
  }
  return info
}

/** 读取视频宽高与时长 */
export async function readVideoInfo(file: string, ext: string): Promise<VideoInfo> {
  const info: VideoInfo = { width: 0, height: 0, durationMs: 0 }
  let fh: FileHandle | null = null
  try {
    fh = await openFile(file)
    const size = (await fh.stat()).size
    if (['.mp4', '.m4v', '.mov', '.3gp'].includes(ext)) return await readMp4Video(fh)
    if (['.mkv', '.webm'].includes(ext)) return await readMkvVideo(fh, size)
    if (ext === '.avi') return await readAviVideo(fh)
    // 其它容器尝试按 MP4 解析（部分 .ts/.wmv 不适用，失败则返回空）
    return info
  } catch {
    return info
  } finally {
    await fh?.close().catch(() => undefined)
  }
}

/* ============================ 图片尺寸（只读文件头） ============================ */

/** 解析图片宽高：只读文件头，不做整图解码 */
export async function readImageSize(file: string, ext: string): Promise<{ width: number; height: number }> {
  const empty = { width: 0, height: 0 }
  let fh: FileHandle | null = null
  try {
    fh = await openFile(file)
    const head = await readAt(fh, 64 * 1024, 0)
    if (head.length < 24) return empty

    if (ext === '.png' && head.toString('latin1', 1, 4) === 'PNG') {
      return { width: head.readUInt32BE(16), height: head.readUInt32BE(20) }
    }
    if ((ext === '.gif' || head.toString('latin1', 0, 3) === 'GIF') && head.length >= 10) {
      return { width: head.readUInt16LE(6), height: head.readUInt16LE(8) }
    }
    if (ext === '.bmp' && head.toString('latin1', 0, 2) === 'BM' && head.length >= 26) {
      return { width: Math.abs(head.readInt32LE(18)), height: Math.abs(head.readInt32LE(22)) }
    }
    if (head.toString('latin1', 0, 4) === 'RIFF' && head.toString('latin1', 8, 12) === 'WEBP') {
      const format = head.toString('latin1', 12, 16)
      if (format === 'VP8X' && head.length >= 30) {
        const width = 1 + (head[24] | (head[25] << 8) | (head[26] << 16))
        const height = 1 + (head[27] | (head[28] << 8) | (head[29] << 16))
        return { width, height }
      }
      if (format === 'VP8 ' && head.length >= 30) {
        return { width: head.readUInt16LE(26) & 0x3fff, height: head.readUInt16LE(28) & 0x3fff }
      }
      if (format === 'VP8L' && head.length >= 25) {
        const bits = head.readUInt32LE(21)
        return { width: (bits & 0x3fff) + 1, height: ((bits >> 14) & 0x3fff) + 1 }
      }
    }
    if (head[0] === 0xff && head[1] === 0xd8) {
      // JPEG：扫描 SOF 段
      let offset = 2
      while (offset + 9 < head.length) {
        if (head[offset] !== 0xff) {
          offset++
          continue
        }
        const marker = head[offset + 1]
        if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) {
          offset += 2
          continue
        }
        const length = head.readUInt16BE(offset + 2)
        if (length < 2) break
        const isSof = marker >= 0xc0 && marker <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(marker)
        if (isSof) {
          return { height: head.readUInt16BE(offset + 5), width: head.readUInt16BE(offset + 7) }
        }
        offset += 2 + length
      }
    }
    if ((ext === '.tif' || ext === '.tiff') && head.length >= 8) {
      const le = head.toString('latin1', 0, 2) === 'II'
      const read16 = (at: number): number => (le ? head.readUInt16LE(at) : head.readUInt16BE(at))
      const read32 = (at: number): number => (le ? head.readUInt32LE(at) : head.readUInt32BE(at))
      const ifdOffset = read32(4)
      if (ifdOffset + 2 < head.length) {
        const count = read16(ifdOffset)
        let width = 0
        let height = 0
        for (let i = 0; i < count; i++) {
          const entry = ifdOffset + 2 + i * 12
          if (entry + 12 > head.length) break
          const tag = read16(entry)
          const value = read16(entry + 8)
          if (tag === 256) width = value
          if (tag === 257) height = value
        }
        return { width, height }
      }
    }
    return empty
  } catch {
    return empty
  } finally {
    await fh?.close().catch(() => undefined)
  }
}

/* ============================ ZIP（含 EPUB / CBZ / 压缩包内容判定） ============================ */

interface ZipEntry {
  name: string
  size: number
  compressedSize: number
  method: number
  localHeaderOffset: number
  isDir: boolean
}

async function readZipDirectory(fh: FileHandle): Promise<ZipEntry[]> {
  const size = (await fh.stat()).size
  const tailLength = Math.min(66 * 1024, size)
  const tail = await readAt(fh, tailLength, size - tailLength)
  let eocd = -1
  for (let i = tail.length - 22; i >= 0; i--) {
    if (tail.readUInt32LE(i) === 0x06054b50) {
      eocd = i
      break
    }
  }
  if (eocd < 0) return []
  let entryCount = tail.readUInt16LE(eocd + 10)
  let cdOffset = tail.readUInt32LE(eocd + 16)
  // Zip64
  if (cdOffset === 0xffffffff || entryCount === 0xffff) {
    for (let i = eocd - 20; i >= 0; i--) {
      if (tail.readUInt32LE(i) === 0x07064b50) {
        const zip64Offset = Number(tail.readBigUInt64LE(i + 8))
        const zip64 = await readAt(fh, 56, zip64Offset)
        if (zip64.length >= 56 && zip64.readUInt32LE(0) === 0x06064b50) {
          entryCount = Number(zip64.readBigUInt64LE(32))
          cdOffset = Number(zip64.readBigUInt64LE(48))
        }
        break
      }
    }
  }
  const entries: ZipEntry[] = []
  const cdSize = Math.min(size - cdOffset, 8 * 1024 * 1024)
  const cd = await readAt(fh, cdSize, cdOffset)
  let cursor = 0
  for (let i = 0; i < entryCount && cursor + 46 <= cd.length; i++) {
    if (cd.readUInt32LE(cursor) !== 0x02014b50) break
    const method = cd.readUInt16LE(cursor + 10)
    const compressedSize = cd.readUInt32LE(cursor + 20)
    const uncompressedSize = cd.readUInt32LE(cursor + 24)
    const nameLength = cd.readUInt16LE(cursor + 28)
    const extraLength = cd.readUInt16LE(cursor + 30)
    const commentLength = cd.readUInt16LE(cursor + 32)
    const localHeaderOffset = cd.readUInt32LE(cursor + 42)
    const name = cd.toString('utf8', cursor + 46, cursor + 46 + nameLength)
    entries.push({
      name,
      size: uncompressedSize,
      compressedSize,
      method,
      localHeaderOffset,
      isDir: name.endsWith('/')
    })
    cursor += 46 + nameLength + extraLength + commentLength
  }
  return entries
}

/** 列出压缩包内的条目（只读中央目录，不解压） */
export async function readZipEntries(file: string, limit = 4000): Promise<ZipEntryInfo[]> {
  let fh: FileHandle | null = null
  try {
    fh = await openFile(file)
    const entries = await readZipDirectory(fh)
    return entries
      .filter((e) => !e.isDir)
      .slice(0, limit)
      .map((e) => ({ name: e.name, size: e.size, isDir: e.isDir }))
  } catch {
    return []
  } finally {
    await fh?.close().catch(() => undefined)
  }
}

/** 读取压缩包里的单个文件（deflate / store） */
export async function readZipEntry(file: string, entryName: string): Promise<Buffer | null> {
  let fh: FileHandle | null = null
  try {
    fh = await openFile(file)
    const entries = await readZipDirectory(fh)
    const entry = entries.find((e) => e.name === entryName)
    if (!entry) return null
    const local = await readAt(fh, 30, entry.localHeaderOffset)
    if (local.length < 30 || local.readUInt32LE(0) !== 0x04034b50) return null
    const nameLength = local.readUInt16LE(26)
    const extraLength = local.readUInt16LE(28)
    const dataStart = entry.localHeaderOffset + 30 + nameLength + extraLength
    const raw = await readAt(fh, Math.min(entry.compressedSize, 32 * 1024 * 1024), dataStart)
    if (entry.method === 0) return raw
    if (entry.method === 8) {
      try {
        return zlib.inflateRawSync(raw)
      } catch {
        return null
      }
    }
    return null
  } catch {
    return null
  } finally {
    await fh?.close().catch(() => undefined)
  }
}

/** 从压缩包条目判断内容类型（例如"影视资源压缩包"） */
export function guessZipContent(entries: ZipEntryInfo[]): { kind: string; summary: string } {
  if (entries.length === 0) return { kind: '', summary: '' }
  const counts = { video: 0, audio: 0, image: 0, book: 0, other: 0 }
  let totalSize = 0
  for (const entry of entries) {
    totalSize += entry.size
    const ext = entry.name.slice(entry.name.lastIndexOf('.')).toLowerCase()
    if (['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.rmvb', '.ts', '.flv', '.m2ts'].includes(ext)) counts.video++
    else if (['.mp3', '.flac', '.wav', '.m4a', '.ape', '.ogg'].includes(ext)) counts.audio++
    else if (['.jpg', '.jpeg', '.png', '.webp', '.bmp'].includes(ext)) counts.image++
    else if (['.epub', '.mobi', '.azw3', '.pdf', '.txt', '.cbz'].includes(ext)) counts.book++
    else counts.other++
  }
  const total = entries.length
  const summary = `压缩包内 ${total} 个文件：视频 ${counts.video} / 音频 ${counts.audio} / 图片 ${counts.image} / 文档 ${counts.book} / 其它 ${counts.other}`
  if (counts.video > 0 && counts.video / total >= 0.4) return { kind: 'video', summary }
  if (counts.audio > 0 && counts.audio / total >= 0.4) return { kind: 'audio', summary }
  if (counts.image > 0 && counts.image / total >= 0.6) return { kind: 'image', summary }
  if (counts.book > 0 && counts.book / total >= 0.4) return { kind: 'book', summary }
  void totalSize
  return { kind: '', summary }
}

export interface EpubMeta {
  title: string
  creator: string
  coverData: Buffer | null
  coverExt: string
  /** 漫画判定证据 */
  pages: number
  imageCount: number
  imgTags: number
  textLength: number
  avgTextPerPage: number
  fixedLayout: boolean
}

/**
 * 读取 EPUB 的标题 / 作者 / 封面，并收集「是漫画还是小说」的判定证据。
 *
 * 实测参考（真实漫画 EPUB，PDF 转的图集）：
 *   82 个条目 / 73 张图 / 2 个 HTML / spine 2 / 每页约 10 个字 / 72 个 <img>
 * 而文字小说：每页动辄上千字，图片只有封面那 1~2 张。
 * 所以用「图片够多 + 每页文字极少」判定图集式漫画。
 */
export async function readEpubMeta(file: string): Promise<EpubMeta> {
  const result: EpubMeta = {
    title: '',
    creator: '',
    coverData: null,
    coverExt: '.jpg',
    pages: 0,
    imageCount: 0,
    imgTags: 0,
    textLength: 0,
    avgTextPerPage: 0,
    fixedLayout: false
  }
  try {
    const entries = await readZipEntries(file, 2000)
    const names = entries.map((entry) => entry.name)
    const container = await readZipEntry(file, 'META-INF/container.xml')
    if (!container) return result
    const rootMatch = /full-path="([^"]+)"/i.exec(container.toString('utf8'))
    if (!rootMatch) return result
    const opfPath = rootMatch[1]
    const opf = await readZipEntry(file, opfPath)
    if (!opf) return result
    const text = opf.toString('utf8')
    const title = /<dc:title[^>]*>([\s\S]*?)<\/dc:title>/i.exec(text)
    const creator = /<dc:creator[^>]*>([\s\S]*?)<\/dc:creator>/i.exec(text)
    if (title) result.title = title[1].replace(/<[^>]+>/g, '').trim()
    if (creator) result.creator = creator[1].replace(/<[^>]+>/g, '').trim()

    const baseDir = opfPath.includes('/') ? opfPath.slice(0, opfPath.lastIndexOf('/') + 1) : ''
    const resolveHref = (href: string): string =>
      decodeURIComponent(href.startsWith('/') ? href.slice(1) : `${baseDir}${href}`)

    // manifest 清单（属性顺序不固定，逐条取）
    const items: { id: string; href: string; type: string; props: string }[] = []
    for (const match of text.matchAll(/<item\b[^>]*>/gi)) {
      const tag = match[0]
      const href = /href="([^"]*)"/i.exec(tag)?.[1] ?? ''
      if (!href) continue
      items.push({
        id: /id="([^"]*)"/i.exec(tag)?.[1] ?? '',
        href,
        type: /media-type="([^"]*)"/i.exec(tag)?.[1] ?? '',
        props: /properties="([^"]*)"/i.exec(tag)?.[1] ?? ''
      })
    }
    const imageItems = items.filter((item) => item.type.startsWith('image/'))
    const archiveImages = names.filter((name) => /\.(jpe?g|png|webp|gif|bmp|avif)$/i.test(name))
    result.imageCount = imageItems.length > 0 ? imageItems.length : archiveImages.length
    result.fixedLayout = /rendition:layout[\s\S]{0,120}?pre-paginated/i.test(text)

    // spine 页数 + 抽样正文文字量
    const spineIds = Array.from(text.matchAll(/<itemref\b[^>]*idref="([^"]+)"/gi)).map((match) => match[1])
    const spineHrefs = spineIds
      .map((id) => items.find((item) => item.id === id)?.href ?? '')
      .filter(Boolean)
    const fallbackHtml = names.filter((name) => /\.x?html?$/i.test(name))
    result.pages = spineHrefs.length > 0 ? spineHrefs.length : fallbackHtml.length
    const sampleHrefs = (spineHrefs.length > 0 ? spineHrefs : fallbackHtml).slice(0, 6)
    for (const href of sampleHrefs) {
      const page = await readZipEntry(file, resolveHref(href))
      if (!page) continue
      const html = page.toString('utf8')
      result.imgTags += (html.match(/<img\b/gi) ?? []).length
      result.textLength += html
        .replace(/<script[\s\S]*?<\/script>/gi, ' ')
        .replace(/<style[\s\S]*?<\/style>/gi, ' ')
        .replace(/<[^>]+>/g, ' ')
        .replace(/&nbsp;/g, ' ')
        .replace(/\s+/g, ' ')
        .trim().length
    }
    if (sampleHrefs.length > 0) {
      result.avgTextPerPage = Math.round(result.textLength / sampleHrefs.length)
    }

    // 封面：① OPF 声明 ② meta name="cover" ③ id/href 含 cover ④ 包内 cover.* ⑤ 图集首图
    let coverHref = items.find((item) => /cover-image/i.test(item.props))?.href ?? ''
    if (!coverHref) {
      const metaCover = /<meta[^>]*name="cover"[^>]*content="([^"]+)"/i.exec(text)?.[1]
      if (metaCover) coverHref = items.find((item) => item.id === metaCover)?.href ?? ''
    }
    if (!coverHref) {
      coverHref = imageItems.find((item) => /cover/i.test(item.id) || /cover/i.test(item.href))?.href ?? ''
    }
    let coverPath = ''
    let data: Buffer | null = null
    if (coverHref) {
      coverPath = resolveHref(coverHref)
      data = await readZipEntry(file, coverPath)
      if (!data) coverPath = ''
    }
    if (!data) {
      const guess = archiveImages.find((name) => /(^|\/)cover\.[a-z0-9]+$/i.test(name))
      if (guess) {
        data = await readZipEntry(file, guess)
        coverPath = guess
      }
    }
    if (!data && result.imageCount >= 8 && result.avgTextPerPage < 300) {
      const first = [...archiveImages].sort((a, b) => a.localeCompare(b, 'zh-Hans-CN', { numeric: true }))[0]
      if (first) {
        data = await readZipEntry(file, first)
        coverPath = first
      }
    }
    if (data) {
      result.coverData = data
      result.coverExt = /\.png$/i.test(coverPath) ? '.png' : '.jpg'
    }
  } catch {
    /* ignore */
  }
  return result
}
