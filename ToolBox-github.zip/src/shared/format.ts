/** 自然排序比较（1, 2, 3, 10 而不是 1, 10, 2, 3） */
const collator = new Intl.Collator('zh-Hans-CN', { numeric: true, sensitivity: 'base' })

export function naturalCompare(a: string, b: string): number {
  const r = collator.compare(a, b)
  if (r !== 0) return r
  return a < b ? -1 : a > b ? 1 : 0
}

/**
 * 生成可直接用 SQLite 排序的自然排序键：
 * 把连续数字补零到 12 位，这样 ORDER BY 的结果与自然排序一致，分页也不会错。
 */
export function naturalKey(name: string): string {
  return name.toLowerCase().replace(/\d+/g, (digits) => digits.padStart(12, '0'))
}

export function formatSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return '-'
  if (bytes < 1024) return `${bytes} B`
  const units = ['KB', 'MB', 'GB', 'TB']
  let value = bytes / 1024
  let i = 0
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024
    i++
  }
  return `${value < 10 ? value.toFixed(2) : value.toFixed(1)} ${units[i]}`
}

function pad(n: number): string {
  return n < 10 ? `0${n}` : String(n)
}

export function formatTime(ms: number): string {
  if (!Number.isFinite(ms) || ms <= 0) return '-'
  const d = new Date(ms)
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

export function formatDate(ms: number): string {
  if (!Number.isFinite(ms) || ms <= 0) return '-'
  const d = new Date(ms)
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}

/** 把毫秒时长格式化成 1:23:45 / 3:21 */
export function formatDuration(ms: number | null | undefined): string {
  if (!ms || !Number.isFinite(ms) || ms <= 0) return ''
  const total = Math.round(ms / 1000)
  const h = Math.floor(total / 3600)
  const m = Math.floor((total % 3600) / 60)
  const s = total % 60
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`
}

/** 把 windows 路径裁剪到最多 max 个字符，保留盘符与文件名 */
export function shortenPath(p: string, max = 60): string {
  if (p.length <= max) return p
  const parts = p.split(/[\\/]/)
  const file = parts.pop() ?? ''
  let acc = parts.shift() ?? ''
  while (parts.length > 1 && acc.length + parts[0].length + file.length + 4 < max) {
    acc = `${acc}\\${parts.shift()}`
  }
  const rest = parts.length > 0 ? '\\...' : ''
  return `${acc}${rest}\\${file}`
}
