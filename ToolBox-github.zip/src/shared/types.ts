/**
 * 三端共用类型：主进程 / 预加载 / 渲染进程。
 * 不引入任何 node 或 electron 模块。
 */

/* ============================ 资源模型 ============================ */

/** 虚拟资源类型（= 左侧分类，与物理文件夹无关） */
export type ResourceKind =
  | 'movie'
  | 'tv'
  | 'anime'
  | 'music'
  | 'novel'
  | 'comic'
  | 'document'
  | 'image'
  | 'wallpaper'
  | 'installer'
  | 'archive'
  | 'software'
  | 'other'

/** 左侧视图 */
export type ViewId =
  | 'home'
  | 'all'
  | 'recent-added'
  | 'recent-used'
  | 'favorites'
  | 'duplicates'
  | 'folders'
  | 'libraries'
  | 'settings'

export type SortBy = 'name' | 'mtime' | 'size' | 'added' | 'kind' | 'opened'
export type SortOrder = 'asc' | 'desc'

export interface ResourceItem {
  id: number
  path: string
  name: string
  baseName: string
  ext: string
  kind: ResourceKind
  size: number
  mtimeMs: number
  addedMs: number
  libraryId: number
  /** 相对资源库根目录的目录（不含文件名），根为 '' */
  relDir: string
  isFavorite: boolean
  lastOpenedMs: number
  openCount: number
  /** 媒体元数据（可能为空，详情里可再懒加载） */
  title: string
  subtitle: string
  width: number
  height: number
  durationMs: number
  /** 卡片的第二行文本（由主进程按类型拼好，渲染层直接用） */
  cardLine: string
  /* ---- 作品（系列）聚合：漫画先行，后续电视剧/专辑复用 ---- */
  /** 作品标识（同一部作品的各卷共享）；空字符串表示未参与聚合 */
  seriesKey: string
  /** 作品名（从文件名解析出的卷号已剔除） */
  seriesTitle: string
  /** 卷号；0 表示未识别出卷号 */
  volume: number
}

/** 作品（系列）视图中的一项：一部漫画 / 一部剧 / 一张专辑 */
export interface SeriesItem {
  key: string
  kind: ResourceKind
  title: string
  volumeCount: number
  totalSize: number
  /** 取封面用的本地文件路径（同目录 cover 优先，其次第一卷） */
  coverPath: string
  /** 该作品的卷文件 id（用于"阅读第一卷"） */
  firstResourceId: number
  mtimeMs: number
  addedMs: number
  isFavorite: boolean
  /** 已识别出卷号的卷数，用于详情里提示解析情况 */
  numberedCount: number
}

export interface SeriesDetail {
  series: SeriesItem
  /** 卷列表（按卷号、再按文件名排序） */
  volumes: ResourceItem[]
  libraryId: number
  libraryPath: string
  relDir: string
}

export interface ResourceDetail extends ResourceItem {
  autoKind: ResourceKind
  overridden: boolean
  hash: string
  hashState: number
  bitrate: number
  album: string
  artist: string
  year: number
  /** 其它元数据（例如压缩包内容判定） */
  meta: Record<string, string | number | boolean | null>
}

export interface ResourceQuery {
  view: ViewId
  kind?: ResourceKind | null
  search?: string
  libraryId?: number | null
  /** 目录浏览：相对资源库根的目录（含库 id） */
  folder?: { libraryId: number; relDir: string } | null
  sort: SortBy
  order: SortOrder
  offset: number
  limit: number
}

export interface ResourcePage {
  total: number
  items: ResourceItem[]
}

/* ============================ Phase 3：作品元数据 ============================ */

/**
 * 元数据匹配置状态
 * none 未处理 / local 本地信息 / pending 待确认 / matched 已匹配 / failed 匹配失败 / confirmed 已确认
 */
export type MatchStatus = 'none' | 'local' | 'pending' | 'matched' | 'failed' | 'confirmed'

/** 作品（系列）级别的元数据：一部作品一行，与本地文件分离 */
export interface MetadataRecord {
  seriesKey: string
  kind: ResourceKind
  /** 显示名（中文名优先） */
  title: string
  originalTitle: string
  year: number
  overview: string
  genres: string[]
  author: string
  studio: string
  country: string
  language: string
  /** 0~10，0 表示无 */
  rating: number
  /** 数据来源：local / tmdb / musicbrainz / openlibrary / anilist */
  externalSource: string
  externalId: string
  matchStatus: MatchStatus
  /** 0~1 */
  matchConfidence: number
  /** 本地缓存相对路径（相对 data/metadata），Phase 8 落地 */
  posterPath: string
  backdropPath: string
  coverPath: string
  extra: Record<string, unknown>
  updatedAt: number
  createdAt: number
}

export interface ProviderInfo {
  id: string
  label: string
  kinds: ResourceKind[]
  requiresNetwork: boolean
  implemented: boolean
}

export interface MetadataStats {
  total: number
  byStatus: Record<string, number>
  bySource: Record<string, number>
  providers: ProviderInfo[]
}

/** 匹配中心里的一部作品（作品实体 + 元数据状态） */
export interface WorkRow {
  seriesKey: string
  kind: ResourceKind
  title: string
  volumeCount: number
  totalSize: number
  /** 作品下的代表文件（用于取封面） */
  coverPath: string
  matchStatus: MatchStatus
  externalSource: string
  year: number
  author: string
  rating: number
  hasPoster: boolean
  confidence: number
  /** 上次匹配留下的候选数量（待确认时用来挑） */
  candidateCount: number
  updatedAt: number
}

/** 存下来的候选（供人工挑选） */
export interface StoredCandidate {
  source: string
  id: string
  title: string
  originalTitle: string
  year: number
  author: string
  popularity: number
  /** Provider 需要的附加信息（例如 TMDB 的 mediaType） */
  extra?: Record<string, unknown>
}

export interface MatchingCenterData {
  stats: MetadataStats & { available: number; planned: number }
  rows: WorkRow[]
  /** 上一次批量匹配的进度（没有就是 null） */
  batch: BatchProgress | null
}

export interface BatchProgress {
  running: boolean
  total: number
  done: number
  matched: number
  pending: number
  failed: number
  skipped: number
  current: string
  startedAt: number
  finishedAt: number
  /** 用户点了取消 */
  cancelled: boolean
  lastError: string
}

export interface KindCount {
  kind: ResourceKind
  count: number
}

export interface LibraryStats {
  total: number
  kinds: KindCount[]
  favorites: number
  recentAdded: number
  recentUsed: number
  duplicates: number
  libraries: number
  folderCount: number
  totalSize: number
}

export interface StartFolder {
  name: string
  path: string
  count: number
}

/* ============================ 资源库 ============================ */

export interface Library {
  id: number
  path: string
  label: string
  enabled: boolean
  maxDepth: number
  createdAt: number
  lastScanned: number
  /** 索引里的资源数 */
  resourceCount: number
}

export interface ScanProgress {
  libraryId: number
  libraryPath: string
  /** counting | scanning | indexing | hashing | idle | paused | done | error */
  phase: string
  scanned: number
  total: number
  current: string
  counts: KindCount[]
  startedAt: number
  finishedAt: number
  error: string
}

export interface ScanOptions {
  maxDepth: number
  includeHidden: boolean
  generateThumbnails: boolean
  readMetadata: boolean
  computeHash: boolean
  hashMaxSizeMB: number
}

/* ============================ 目录浏览 ============================ */

export interface FolderNode {
  name: string
  path: string
  relDir: string
  libraryId: number
  fileCount: number
  subFolderCount: number
  totalSize: number
}

/* ============================ 媒体信息 ============================ */

export interface MediaInfo {
  path: string
  width: number
  height: number
  durationMs: number
  bitrate: number
  title: string
  artist: string
  album: string
  year: number
  track: number
  genre: string
  /** 内嵌封面提取结果（缓存文件路径） */
  coverPath: string
  /** 压缩包内容判定 */
  innerKind: string
  innerSummary: string
}

/* ============================ 配置 ============================ */

export type BackgroundMode = 'cover' | 'contain' | 'stretch' | 'tile' | 'center'
export type WallpaperStyleId = 'fill' | 'fit' | 'stretch' | 'tile' | 'center' | 'span'

export interface AppConfig {
  background: string
  overlay: number
  backgroundMode: BackgroundMode
  windowWidth: number
  windowHeight: number
  windowMaximized: boolean
  /** 旧的单根目录（1.0.1 起作为初始资源库迁移，保留兼容） */
  resourceRoot: string
  excludeDirs: string[]
  sortBy: SortBy
  sortOrder: SortOrder
  confirmExecutables: boolean
  approvedPrograms: string[]
  showFileExtensions: boolean
  wallpaperStyle: WallpaperStyleId
  lastCategory: string
  /* ---- 1.0.1 新增 ---- */
  /** 是否显示数量为 0 的分类 */
  showEmptyCategories: boolean
  /** 首页卡片列数（紧凑/宽松由 CSS 控制） */
  cardSize: 'compact' | 'normal' | 'large'
  scan: ScanOptions
  /** 上次打开的视图 */
  lastView: string
  /* ---- Phase 4：在线元数据 ---- */
  metadata: MetadataConfig
}

/**
 * 在线元数据设置。API Key 只存在本机 config.json（明文，不上传、不写日志、不写入截图）。
 */
export interface MetadataConfig {
  /**
   * TMDB API Key。
   * 只写不读：渲染层拿到的副本里这个字段永远是空字符串，
   * 是否已配置看只读的 tmdbKeySet；写入走 meta:setKey / meta:clearKey。
   */
  tmdbApiKey: string
  /** 只读：主进程回传时表示是否已配置 Key */
  tmdbKeySet?: boolean
  /** 是否允许联网匹配（默认关闭；关闭时只用本地信息） */
  online: boolean
  /** 代理地址，例如 http://127.0.0.1:7890；留空表示直连。国内访问 TMDB 通常需要它 */
  proxy: string
  /** TMDB API 根地址，可改成自建反代；默认官方地址 */
  tmdbApiBase: string
  /** TMDB 图片根地址，反代可一起改 */
  tmdbImageBase: string
  /** 一部作品的海报/背景图缓存上限（MB） */
  imageCacheMB: number
}

/* ============================ IPC 结果 ============================ */

export interface OperationResult {
  ok: boolean
  error?: string
  message?: string
  path?: string
}

export interface LibraryPickResult {
  ok: boolean
  canceled?: boolean
  error?: string
  library?: Library
  libraries?: Library[]
}

export interface AppInfo {
  version: string
  appRoot: string
  configPath: string
  dataDir: string
  packaged: boolean
  platform: string
  powershell: boolean
  electron: string
  chrome: string
  node: string
  resourceCount: number
}

export interface ToastPayload {
  type: 'ok' | 'error' | 'info'
  text: string
}

export interface BackgroundPickResult {
  ok: boolean
  canceled?: boolean
  error?: string
  config?: AppConfig
}

/* ============================ 预加载接口 ============================ */

export interface ToolboxApi {
  info(): Promise<AppInfo>
  getConfig(): Promise<AppConfig>
  setConfig(patch: Partial<AppConfig>): Promise<AppConfig>

  /** 资源库管理 */
  libraries(): Promise<Library[]>
  addLibrary(): Promise<LibraryPickResult>
  removeLibrary(id: number): Promise<OperationResult>
  setLibraryEnabled(id: number, enabled: boolean): Promise<OperationResult>
  scan(startLibraryId?: number): Promise<OperationResult>
  pauseScan(): Promise<OperationResult>
  resumeScan(): Promise<OperationResult>
  cancelScan(): Promise<OperationResult>
  scanStatus(): Promise<ScanProgress[]>

  /** 资源查询 */
  stats(): Promise<LibraryStats>
  list(query: ResourceQuery): Promise<ResourcePage>
  detail(id: number): Promise<ResourceDetail | null>
  toggleFavorite(id: number): Promise<OperationResult>
  setKind(id: number, kind: ResourceKind | null): Promise<OperationResult>
  folders(libraryId: number, relDir: string): Promise<FolderNode[]>
  folderResources(libraryId: number, relDir: string): Promise<ResourcePage>
  topFolders(): Promise<FolderNode[]>

  /** 作品（系列）聚合：漫画墙 / 卷列表 */
  series(kind: ResourceKind, libraryId?: number | null): Promise<SeriesItem[]>
  seriesDetail(key: string): Promise<SeriesDetail | null>

  /* ---- Phase 3：作品元数据 ---- */
  metaGet(seriesKey: string): Promise<MetadataRecord | null>
  /** 缩略图尺寸：card=256（网格）/ detail=1024（详情）/ icon=256（程序图标） */
  metaOverview(): Promise<MetadataStats & { available: number; planned: number }>
  metaList(status?: MatchStatus): Promise<MetadataRecord[]>
  /** 已缓存的海报绝对路径（没有就是空字符串） */
  metaPoster(seriesKey: string): Promise<string>
  /** 写入 TMDB API Key（只写不读：读回来永远是空字符串） */
  metaSetKey(key: string): Promise<{ ok: boolean; hasKey: boolean }>
  metaClearKey(): Promise<{ ok: boolean; hasKey: boolean }>
  metaMatch(seriesKey: string): Promise<{
    decision: { status: MatchStatus; confidence: number; reason: string; providerCount: number }
    record: MetadataRecord | null
  } | null>
  metaSave(seriesKey: string, patch: Partial<MetadataRecord>): Promise<MetadataRecord | null>

  /* ---- Phase 9：元数据匹配中心 ---- */
  matchingCenter(): Promise<MatchingCenterData>
  matchingCandidates(seriesKey: string): Promise<StoredCandidate[]>
  /** 人工确认某个候选 */
  matchingConfirm(seriesKey: string, candidate: StoredCandidate): Promise<MetadataRecord | null>
  /** 手动填写并确认 */
  matchingSaveManual(seriesKey: string, patch: Partial<MetadataRecord>): Promise<MetadataRecord | null>
  /** 重置为本地信息（清掉在线元数据与缓存图） */
  matchingReset(seriesKey: string): Promise<MetadataRecord | null>
  /** 判定"候选都不对"：标记失败但保留候选 */
  matchingReject(seriesKey: string): Promise<MetadataRecord | null>
  /** 批量匹配：status=all/none/local/failed/pending，kind 为空表示全部类型 */
  matchingBatchStart(options: { status: MatchStatus | 'all'; kind: ResourceKind | null; limit: number }): Promise<BatchProgress>
  matchingBatchCancel(): Promise<void>
  onMatchingBatch(callback: (progress: BatchProgress) => void): () => void

  /** 缩略图与媒体信息 */
  thumb(path: string, mtimeMs: number, kind: ResourceKind, size?: 'card' | 'detail' | 'icon'): Promise<string | null>
  icon(path: string, mtimeMs: number): Promise<string | null>

  /* ---- Phase 8：缓存管理 ---- */
  cacheStats(): Promise<{
    thumbnailFiles: number
    thumbnailMB: number
    thumbnailBySize: Record<string, { files: number; MB: number }>
    imageFiles: number
    imageMB: number
    cacheDir: string
    thumbDir: string
  }>
  cacheClear(target: 'thumbs' | 'images'): Promise<{ removed: number; freedBytes: number }>
  media(path: string, kind: ResourceKind): Promise<MediaInfo | null>

  /** 文件操作（沿用 1.0.0 的能力，改为按路径/资源 id） */
  open(idOrPath: number | string): Promise<OperationResult>
  reveal(path: string): Promise<OperationResult>
  copyPath(path: string): Promise<OperationResult>
  rename(path: string, newName: string): Promise<OperationResult>
  remove(path: string, permanent: boolean): Promise<OperationResult>

  /** Windows 桌面壁纸 */
  setWallpaper(path: string, style: WallpaperStyleId): Promise<OperationResult>
  setWallpaperFromData(dataUrl: string, style: WallpaperStyleId): Promise<OperationResult>

  /** 工具箱背景 */
  chooseBackground(): Promise<BackgroundPickResult>
  resetBackground(): Promise<AppConfig>

  mediaUrl(filePath: string): string
  onConfigChanged(cb: (config: AppConfig) => void): () => void
  onToast(cb: (payload: ToastPayload) => void): () => void
  onScanProgress(cb: (progress: ScanProgress) => void): () => void
  onIndexChanged(cb: () => void): () => void
}
