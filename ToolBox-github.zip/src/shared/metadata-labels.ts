import type { MatchStatus } from '@shared/types'

/**
 * 渲染层与主进程共用的状态文案。
 * 放在 shared 里，避免在主进程与渲染进程各写一份导致显示不一致。
 */
export const MATCH_STATUS_LABEL: Record<MatchStatus, string> = {
  none: '未处理',
  local: '本地信息',
  pending: '待确认',
  matched: '已匹配',
  failed: '匹配失败',
  confirmed: '已确认'
}

export const MATCH_STATUS_HINT: Record<MatchStatus, string> = {
  none: '还没有处理过这部作品',
  local: '内容来自本地文件（文件名解析、标签、EPUB 元数据）',
  pending: '已有候选但置信度不够，需要人工确认',
  matched: '已由在线元数据源自动匹配',
  failed: '尝试匹配但没有找到可信结果',
  confirmed: '用户确认过的匹配结果'
}
