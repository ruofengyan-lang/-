import type { ResourceKind, WallpaperStyleId } from './types'

/** 资源类型的中文名（左侧虚拟分类） */
export const KIND_LABEL: Record<ResourceKind, string> = {
  movie: '电影',
  tv: '电视剧',
  anime: '动漫',
  music: '音乐',
  novel: '小说',
  comic: '漫画',
  document: '文档',
  image: '图片',
  wallpaper: '壁纸',
  installer: '安装包',
  archive: '压缩包',
  software: '软件',
  other: '其他'
}

/** 左侧导航里类型的固定顺序 */
export const KIND_ORDER: ResourceKind[] = [
  'movie',
  'tv',
  'anime',
  'music',
  'novel',
  'comic',
  'document',
  'image',
  'wallpaper',
  'installer',
  'archive',
  'software',
  'other'
]

/** 参与「作品（系列）聚合」的类型：漫画与音乐（专辑）先行，影视后续 */
export const SERIES_KINDS: ResourceKind[] = ['comic', 'music']

/**
 * 拥有「作品实体」的类型（Phase 3）：
 * 这些类型的文件会归属到某个作品，作品元数据独立存放（metadata 表）。
 * 音乐的"作品"是**专辑**（Phase 5）：扫描阶段拿不到标签，所以在读到标签后再归组。
 */
export const WORK_KINDS: ResourceKind[] = ['comic', 'novel', 'movie', 'tv', 'anime', 'music']

/** 卡片左侧色条 / 小标签配色（保持深蓝工具箱风格，只做低饱和区分） */
export const KIND_ACCENT: Record<ResourceKind, string> = {
  movie: '#5fa8f5',
  tv: '#6fc7d8',
  anime: '#8f9ff0',
  music: '#7bd3a8',
  novel: '#e0b96a',
  comic: '#e08f6a',
  document: '#9fb6cc',
  image: '#7fc4a0',
  wallpaper: '#b58fe0',
  installer: '#f0a35f',
  archive: '#c9a05f',
  software: '#6fb2e8',
  other: '#94a7bb'
}

export const KIND_IS_MEDIA: Record<ResourceKind, boolean> = {
  movie: true,
  tv: true,
  anime: true,
  music: true,
  novel: false,
  comic: false,
  document: false,
  image: false,
  wallpaper: false,
  installer: false,
  archive: false,
  software: false,
  other: false
}

const EXT_KIND: Record<string, ResourceKind> = {}

const put = (kind: ResourceKind, exts: string[]): void => {
  for (const ext of exts) EXT_KIND[ext] = kind
}

// 视频先统一记为 movie，扫描时再用文件名/目录细化成 tv / anime
put('movie', [
  '.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.rmvb', '.rm', '.ts', '.m2ts',
  '.m4v', '.mpg', '.mpeg', '.webm', '.3gp', '.vob', '.iso.video'
])
put('music', [
  '.mp3', '.flac', '.wav', '.m4a', '.aac', '.ogg', '.oga', '.wma', '.alac', '.ape',
  '.opus', '.aiff', '.aif', '.dsf', '.mid', '.mka'
])
put('novel', ['.epub', '.mobi', '.azw', '.azw3', '.fb2', '.lit'])
put('comic', ['.cbz', '.cbr', '.cb7', '.cbt'])
put('document', [
  '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.csv', '.rtf',
  '.odt', '.ods', '.odp', '.wps', '.et', '.dps', '.md', '.txt', '.htm', '.html',
  '.json', '.xml', '.log', '.ini', '.yaml', '.yml'
])
put('image', [
  '.jpg', '.jpeg', '.png', '.webp', '.bmp', '.gif', '.tif', '.tiff', '.jfif',
  '.heic', '.avif', '.ico', '.raw', '.cr2', '.nef', '.arw', '.dng', '.psd'
])
put('installer', [
  '.exe', '.msi', '.msix', '.msixbundle', '.appx', '.appxbundle', '.msu', '.cab.install'
])
put('archive', [
  '.zip', '.7z', '.rar', '.tar', '.gz', '.tgz', '.bz2', '.xz', '.zst', '.cab',
  '.iso', '.img', '.wim', '.esd', '.lz4', '.lzh', '.arj'
])
put('software', ['.apk', '.appimage', '.deb', '.rpm', '.jar'])

/** 需要先弹确认框再运行的类型（保持原有安全策略） */
export const EXECUTABLE_EXTS = [
  '.exe', '.msi', '.msix', '.appx', '.bat', '.cmd', '.ps1', '.com', '.vbs', '.reg', '.scr', '.lnk'
]

/** 可以被设为 Windows 桌面壁纸的扩展名 */
export const WALLPAPER_EXTS = ['.jpg', '.jpeg', '.png', '.bmp', '.webp', '.jfif', '.gif', '.avif', '.tif', '.tiff']

/** Windows 壁纸填充方式 → 注册表 WallpaperStyle / TileWallpaper */
export const WALLPAPER_STYLES: { id: WallpaperStyleId; label: string; style: number; tile: 0 | 1 }[] = [
  { id: 'fill', label: '填充', style: 10, tile: 0 },
  { id: 'fit', label: '适应', style: 6, tile: 0 },
  { id: 'stretch', label: '拉伸', style: 2, tile: 0 },
  { id: 'tile', label: '平铺', style: 0, tile: 1 },
  { id: 'center', label: '居中', style: 0, tile: 0 },
  { id: 'span', label: '跨屏', style: 22, tile: 0 }
]

export function wallpaperStyleNumbers(id: WallpaperStyleId): { style: number; tile: number } {
  const found = WALLPAPER_STYLES.find((item) => item.id === id) ?? WALLPAPER_STYLES[0]
  return { style: found.style, tile: found.tile }
}

/** 视频扩展名（用于分类细化与容器解析） */
export const VIDEO_EXTS = ['.mp4', '.mkv', '.avi', '.mov', '.m4v', '.webm', '.wmv', '.flv', '.ts', '.m2ts', '.rmvb', '.rm', '.mpg', '.mpeg']

/** 音频扩展名 */
export const AUDIO_EXTS = ['.mp3', '.flac', '.m4a', '.ogg', '.oga', '.wav', '.wma', '.aac', '.ape', '.opus', '.aiff', '.dsf']

export function extOf(name: string): string {
  const idx = name.lastIndexOf('.')
  if (idx <= 0 || idx === name.length - 1) return ''
  return name.slice(idx).toLowerCase()
}

export function baseNameOf(name: string): string {
  const ext = extOf(name)
  return ext ? name.slice(0, name.length - ext.length) : name
}

/** 扩展名 → 基础类型（细化在 classifier 里做） */
export function kindOfExt(ext: string): ResourceKind {
  return EXT_KIND[ext] ?? 'other'
}

export function isVideoExt(ext: string): boolean {
  return VIDEO_EXTS.includes(ext)
}

export function isAudioExt(ext: string): boolean {
  return AUDIO_EXTS.includes(ext)
}

export function isExecutableExt(ext: string): boolean {
  return EXECUTABLE_EXTS.includes(ext)
}

export function isWallpaperExt(ext: string): boolean {
  return WALLPAPER_EXTS.includes(ext)
}
