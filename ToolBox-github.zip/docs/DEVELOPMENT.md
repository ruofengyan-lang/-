# 开发日志与架构决策

这份文档记录各阶段的实现范围、验收方式，以及**踩过的坑**——后者往往比功能本身更有参考价值。

## 0. 工程栈

| 项 | 版本 / 说明 |
| --- | --- |
| 运行时 | Electron 44（Node 24 / Chromium 152） |
| 构建 | electron-vite 5 + Vite 7 |
| 界面 | React 19 + TypeScript 7 |
| 存储 | SQLite via `node:sqlite`（`DatabaseSync`，WAL 模式） |
| 打包 | electron-builder（portable + nsis） |
| 依赖 | 仅 devDependencies —— 主进程与渲染层都被打包，运行时零外部依赖 |

`contextIsolation: true`、`sandbox: true`；渲染层只能调用 preload 通过 `contextBridge` 暴露的白名单 API。
所有文件系统与网络操作都在主进程；本地图片经自定义协议 `toolbox-media://` 读取，并校验允许根白名单。

## 1. 界面与交互重构

- 固定右侧面板改为**动态详情抽屉**：未选中任何内容时网格铺满窗口
- 单击 = 信息，双击 = 执行，右键 = 菜单；媒体用内容卡片而不是文件列表
- 首页以内容为主；影视优先海报墙

**验收**：自检用注入脚本模拟点击与双击，断言抽屉出现 / 标题正确 / 动作按钮数量 / Esc 关闭。

## 2. 漫画

- 同名 `epub` + `pdf` 合并为同一部作品的不同卷；卷号识别支持
  `第01卷` / `Vol.12` / `v03` / `【全卷】` / 末尾纯数字
- EPUB 封面提取做了五级回退（OPF cover → guide → manifest 名称匹配 → 首个图片项 → 首图）
- EPUB / ZIP 内容判定：图片占比与页数用于区分"漫画"与"小说"

**坑**：EPUB 的 OPF 里 `properties="cover-image"` 并不总是存在，仅靠 `<meta name="cover">` 会漏；
必须回到 manifest 里按名称与 media-type 找候选。

## 3. 元数据与 Provider 层

- 统一 `metadata` 表 + `MetadataProvider` 接口（`search` / `detail`）
- 状态机：`none / local / pending / matched / failed / confirmed`，优先级
  **confirmed > matched > local**，本地信息永不覆盖前两者
- 写库分两条路：Provider 补字段走「只填空」，用户编辑与重置走「整体替换」

**坑（重要）**：`saveMetadata` 的 upsert 语义是"空值不覆盖已有值"。一开始「重置为本地信息」
也走了这条路，于是**字段永远清不掉**——脏数据清了半天清不干净。后来加了 `replaceMetadata`（整体 UPDATE）。

## 4. TMDB（影视）

- 用 `session.fromPartition('toolbox-metadata').fetch` 走 Chromium 网络栈，支持代理
- API Key 只存在本机 `config.json`；渲染层只拿到 `''` 与 `tmdbKeySet: boolean`
- 15 秒超时 + 中文错误映射 + 图片下载体积上限 + 主机熔断（30 分钟 TTL）

**坑**：自检里写过"写入假 Key → 断言不泄露 → 清理"，结果一不小心让假 Key 落进了配置文件。
现在自检流程是：记录前值 → 写入 → 断言（值不出现在渲染层）→ 恢复 → 再断言。

## 5. MusicBrainz（音乐）

- 专辑 / 曲目匹配，User-Agent 必填，**每秒 1 次限流** + 503/429 退避重试
- 华语老专辑覆盖率一般，因此"待确认"是常态而不是异常

## 6/7. 小说与漫画数据源 + 散图聚合

- AniList（GraphQL POST，0.9 秒节流）/ Open Library（search.json + work 详情）
- **散图漫画目录聚合**（纯离线）：路径含 `漫画 / comic / manga` 且目录内 ≥5 张页码图时，
  整目录聚合成一部作品，卷号 = 页码，封面 = 首图；**反例**：壁纸目录里的编号图片不受影响
- 文件名清洗：去掉网文站域名与 `【全本】` 之类噪音，支持 `〔〕〖〗` 括号

**坑**：候选标题只在"主标题搜不到"时才用备用标题是不够的——很多作品的数据库条目只有
**分隔符前的主标题**（`A - B` 里的 `A`）。补上"分隔符前短标题"后，命中率才有实质变化。

## 8. 缓存与界面

- 缩略图按用途分尺寸：卡片 256 / 详情 1024 / 图标 256，各尺寸独立子目录、按需生成
- 详情页影视背景带（取本地视频首帧）+ 渐变压暗；音乐保留方形封面，不重复叠背景
- 设置里可看缓存占用（分尺寸张数）、清理、打开目录

**坑**：改缩略图尺寸时只升级了"状态版本号"，图片文件仍然是旧的。
现在升级管线版本 = 清空缓存目录 + 重置索引状态，两者必须一起做。

## 9. 匹配中心

- 状态总览（未处理 / 待确认 / 失败 / 已匹配 / 已确认 / 全部）
- 批量匹配（进度、成功 / 待确认 / 失败计数、可取消）、候选挑选（最多 8 条）、
  手动填写、重置为本地信息；候选即使匹配失败也持久化，便于事后人工挑
- 打分：标题 Dice-bigram 相似度 + 年份 + 作者，权重按**可用信号归一化**，
  ≥0.90 且与次优差 ≥0.08 才自动匹配，否则一律"待确认"

**坑（重要，两个）**：

1. **自检用的假 Provider 污染了真实库**：早期自检把假 Provider 注册进注册表，
   跑完没注销，结果全库批量匹配把 16 部作品写成了"自检作者 / 2020"。
   现在的做法：假 Provider 打 `test: true` 标记（正常匹配与批量一律排除）、
   用完立即注销、批量启动前加保险丝、自检改为在**临时作品**上跑完即删。
2. **自检静默失效**：上述自检里传了 `online: false`，而 `matchSeries` 在这时会提前返回
   "在线匹配已关闭"——自检变成了空操作，还骗过了好几个月。现在会断言
   `status === 'matched'`（`ok` 字段），并把结论写进自检报告。

## 10. 性能

- **真虚拟网格**：超过 200 项只渲染可视区域的行（+300px 预读）。列宽按 CSS 的
  `repeat(auto-fill, minmax(116px, 1fr))` 复刻计算，行高按卡片形状推算，
  文字区高度从真实卡片量一次。383 项实测：DOM 里只有 63~72 个卡片
- 列表查询 LRU 缓存（40 条），任何写操作清空缓存
- 复合索引 `(kind, sort_name)`、`(open_count, last_opened)`；扫描后
  `PRAGMA optimize` + `wal_checkpoint(TRUNCATE)`

**坑**：第一版虚拟网格用"测量已渲染卡片宽度"来算列数，形成了反馈环——
一次测到 2 列，卡片width 记成半屏宽，列数就越算越少，最后只渲染 2 个卡片。
改成直接按 CSS 规则推算列数、只测文字区高度，问题消失。

## 自检与验收方式

```powershell
pnpm typecheck                 # 类型检查
pnpm smoke                     # 无界面自检，输出 JSON 报告
node scripts/db-report.cjs     # 按类型统计缩略图 / 元数据情况
node scripts/mock-tmdb.cjs     # 本地假 TMDB 服务（验证影视链路，不依赖外网）
python scripts/make-fixture-*.py   # 生成各类测试夹具
```

`--smoke` 支持这些附加开关（可组合）：

| 开关 | 作用 |
| --- | --- |
| `--smoke-scan` | 先跑一次真实扫描（验证完整索引链路） |
| `--smoke-online` | 真实联网探测（影视 / 音乐 / 漫画） |
| `--smoke-providers` | 逐个 Provider 直连探测并列出命中样本 |
| `--smoke-batch-all` | 全库批量匹配并输出统计 |
| `--smoke-batch-kind=novel` | 只跑某一类的批量匹配 |
| `--smoke-reset-mark=SMOKE` | 按标记清理自检写入的残留数据 |
| `--shot=文件.png` | 截图（配合 `--shot-view=` / `--shot-click=` / `--shot-scroll=`） |

## 开发时的经验教训

- **不要用 PowerShell 改 JSON 文件**：`Get-Content` 默认按本地编码读，中文会变乱码；
  `Set-Content -Encoding UTF8` 在旧版还会写入 BOM——而 electron-builder 解析带 BOM 的
  `package.json` 会直接报 `Unexpected token '\ufeff'`。要么用工具按 UTF-8 无 BOM 写，要么保持文件全 ASCII。
- **改文件时不要顺手删换行**：有两次把下一行代码吞进了注释里，一次让构建失败、一次让自检脚本语法错误。
- **自检必须断言"真的跑到了"**：只断言"没报错"的自检，会在条件下静默变成空操作。
- **破坏性操作要能被恢复**：所有验证脚本都应该有 `remove` / `restore`，并在结束时恢复到原始状态。
