# 个人本地数字资源中心（ToolBox）

把散落在硬盘里的电影、音乐、小说、漫画、图片、壁纸、安装包与压缩包收进一个界面：
自动识别类型、聚合为「作品」、读取本地标签与封面，并在你愿意时联网补全元数据。

**Windows 桌面应用 · Electron + React + TypeScript + SQLite · 绿色便携 · 离线优先**

![全部资源](docs/screenshots/screenshot-all.png)

| 漫画作品墙（散图目录自动聚合） | 首页 | 设置 · 缓存管理 |
| --- | --- | --- |
| ![漫画](docs/screenshots/screenshot-comics.png) | ![首页](docs/screenshots/screenshot-home.png) | ![设置](docs/screenshots/screenshot-settings.png) |

> 截图来自仓库自带的演示资源库（`scripts/make-fixture-demo.py` 生成），不含任何个人内容。

---

## 特性

**资源管理**

- 递归扫描多个资源库目录，**增量更新**：文件没变就不重算，扫描可暂停 / 取消
- 自动分类：电影 / 电视剧 / 动漫 / 音乐 / 小说 / 漫画 / 文档 / 图片 / 壁纸 / 安装包 / 压缩包 / 软件 / 其他
  ；分类是**逻辑分类**，文件夹只作为来源；手动指定分类后重扫不会覆盖
- 内容级识别：压缩包读文件列表判定内容、EPUB 读 OPF 元数据、音视频读容器与标签
- 重复资源检测：先按大小初筛，再算 SHA-256 确认（只提示，不自动删除）

**作品聚合（不只是文件列表）**

- 影视 / 音乐 / 小说 / 漫画按「作品」聚合：同名多卷合并、同一专辑多曲聚合
- **散图漫画目录自动聚合**：目录名带 `漫画 / comic / manga` 且含 5 张以上页码图
  （`001.jpg`、`p07.webp`、`第05页.jpg`）时，整目录成为一部作品，卷号 = 页码
- 封面优先链：已缓存的在线封面 → 同目录 `cover.jpg` / `folder.jpg` → 包内首图 / 内嵌封面

**交互**

- 单击 = 右侧详情抽屉（信息 + 操作），双击 = 系统默认程序执行，右键 = 菜单
- 顶栏搜索、类型筛选、排序、「按作品 / 按文件」切换；支持键盘 Esc 关闭抽屉
- 批量续载与**真虚拟网格**：超过 200 项只渲染可视区域的行（383 项实测仅渲染约 70 个卡片）

**元数据（可选，关闭联网仍完全可用）**

| 数据源 | 覆盖 | 是否需要 Key |
| --- | --- | --- |
| [TMDB](https://www.themoviedb.org/) | 电影 / 电视剧 / 动漫 | 需要（免费注册，用户自行填写） |
| [MusicBrainz](https://musicbrainz.org/) | 音乐 | 免 Key |
| [AniList](https://anilist.co/) | 漫画 / 动画 | 免 Key |
| [Open Library](https://openlibrary.org/) | 小说 | 免 Key |

- 优先级：**用户手动确认 > 自动匹配 > 本地文件信息**，本地信息永不被自动覆盖
- 置信度不到 0.90 一律判为「待确认」交给人确认——宁可少匹配，也不写错数据
- 匹配中心：状态筛选、批量匹配（带进度 / 可取消）、候选挑选、手动填写、重置为本地信息
- 海报 / 封面下载后缓存在本地，断网也能显示

**性能与缓存**

- 缩略图按用途分尺寸缓存：卡片 256px、详情 1024px、程序图标 256px，浏览时按需生成
- 列表查询 LRU 缓存 + 写操作自动失效；`PRAGMA optimize` + WAL 截断维护
- 设置里可查看缓存占用（分尺寸张数）、一键清理、打开缓存目录

---

## 快速开始

### 直接使用（绿色版）

下载 `ToolBox.exe`，放进你的资源目录（或任意目录，首次运行会把所在目录加入资源库），双击即可。
不需要安装 Node / Python / 数据库，不改注册表，不写系统目录。

> 本仓库是**源码**。打包产物请自行执行下面的构建命令生成，或从 Releases 下载（如果提供）。

### 从源码构建

前置：Windows 10/11、[Node.js](https://nodejs.org/) ≥ 20、[pnpm](https://pnpm.io/) ≥ 9

```powershell
pnpm install
pnpm setup:electron   # 首次需要：下载 Electron 运行时（约 150MB）
pnpm dev              # 开发模式（热更新）
pnpm typecheck        # 类型检查
pnpm build            # 编译到 out\
pnpm smoke            # 无界面自检：索引 / 分类 / 缩略图 / 元数据 / 界面 DOM / 交互
pnpm pack:portable    # 绿色版  → release\ToolBox.exe
pnpm pack:setup       # 安装版  → release\ToolBox_Setup.exe
pnpm deploy:exe       # 把 exe 复制到资源目录并生成使用说明
```

国内网络下载 Electron 慢或卡在 0 字节时：

```powershell
$env:ELECTRON_MIRROR = 'https://npmmirror.com/mirrors/electron/'
```

> 注意 `pnpm pack` / `pnpm deploy` / `pnpm setup` 是 pnpm 自己的内置命令，
> 请使用上面带冒号的脚本名（`pack:portable` / `deploy:exe` / `setup:electron`）。

### 生成演示资源库（截图 / 试功能）

```powershell
python scripts/make-fixture-demo.py .demo-lib        # 生成中性的演示资源
node scripts/demo-lib.cjs add                        # 登记为演示库并暂停其它库
node scripts/demo-lib.cjs remove                     # 用完移除并恢复
```

---

## 架构

```
src/
  shared/          三端共用：类型定义、分类枚举、格式化、元数据标签
  main/            主进程（全部文件系统与网络操作都在这里）
    index.ts       窗口 / IPC / 自检 / 截图
    db.ts          SQLite（node:sqlite，WAL）索引与元数据表
    library.ts     扫描引擎（递归、增量、进度、去重）
    classifier.ts  分类器 + 作品名/卷号/作者/专辑解析 + 卡片文案
    mediainfo.ts   标签与容器解析（ID3 / FLAC / MP4 / OGG / EPUB / ZIP）
    thumbs.ts      多尺寸缩略图调度与缓存
    shell-worker.ts Windows Shell 缩略图批量 worker（PowerShell + C#）
    resources.ts   查询层（视图 / 搜索 / 收藏 / 分页）+ 查询缓存
    protocol.ts    toolbox-media:// 本地图片协议（允许根白名单）
    metadata/      元数据 Provider 层
      types.ts      Provider 接口
      registry.ts   注册表（含"仅自检"Provider 的隔离）
      normalize.ts  标题清洗、候选打分、匹配决策
      http.ts       网络出口（Chromium stack / 代理 / 超时 / 中文错误映射）
      poster.ts     封面下载与缓存（含主机熔断）
      providers/    tmdb · musicbrainz · anilist · openlibrary
      index.ts      匹配编排、批量、候选持久化
  preload/         contextBridge 暴露 window.toolbox
  renderer/        React 界面（网格 / 详情抽屉 / 作品墙 / 匹配中心 / 设置）
```

**关键设计取舍**

- `contextIsolation: true` + `sandbox: true`：渲染进程只能通过 preload 暴露的白名单 API 做事
- 所有文件系统与网络访问都在主进程；渲染层拿到的图片走自定义协议 + 允许根白名单
- 元数据写入分两条路：Provider 补字段走「只填空不覆盖」，用户编辑与重置走「整体替换」
- 自检（`pnpm smoke`）跑真实索引与真实网络探测，并把结论输出为 JSON，便于回归比对

---

## 数据与隐私

| 位置 | 内容 |
| --- | --- |
| `config\config.json` | 设置（含 API Key，明文存本机） |
| `data\index.db` | SQLite 索引（WAL） |
| `data\thumbnails\{card,detail,icon}` | 缩略图缓存 |
| `data\metadata\{posters,backdrops}` | 在线封面 / 背景图缓存 |
| `data\workers\` | Windows Shell 缩略图 worker 脚本 |

- 所有数据都在程序所在目录内；整个目录拷走就是完整备份，删掉 `data\` 会重新扫描重建
- 联网只发生在「匹配元数据 / 下载封面」时，可在设置里一键关闭（关闭后完全离线可用）
- 不自动提权、不关闭 Defender、不绕过 SmartScreen、不改注册表
- 压缩包只读文件列表，不解压；删除进回收站；重复资源不自动清理

---

## 已知限制

- **在线元数据受网络环境影响**：本机实测 MusicBrainz 与 AniList 可直连，
  TMDB 与 Open Library 视网络情况可能不可达（设置里可填代理）
- **中文网文覆盖差**：Open Library 基本不收录中文网络小说，同名不同人的情况也常见，
  因此置信度不足时只标「待确认」
- `.cbr` / `.rar` 漫画目前只识别为压缩包（内页封面提取未实现）；未做 `.mobi` / `.azw3`
- 同一部作品分散在多个目录时不会跨目录合卷
- 只在 Windows 上测试（依赖 Windows Shell 缩略图与回收站 API）

---

## 开发日志

架构决策、踩过的坑与各阶段验收记录见 [docs/DEVELOPMENT.md](docs/DEVELOPMENT.md)。

## 许可

[MIT](LICENSE) © YX Studio
